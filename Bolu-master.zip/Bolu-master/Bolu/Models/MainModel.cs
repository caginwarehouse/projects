﻿using Bolu.Data;

namespace Bolu.Models
{
    public class MainModel
    {
        public SysDataContext db { get; set; }
        public List<supermarket> supermarkets { get; set; }
        public List<station_group> station_groups { get; set; }
        public List<station> stations { get; set; }
        public List<material> materials { get; set; }
        public List<request> requests { get; set; }


        public MainModel(SysDataContext _db)
        {
            db = _db;
        }

        //Supermarket
        public List<supermarket> GetSupermarket()
        {
            return db.supermarket.ToList();
        }
        public List<supermarket> GetSupermarket(int id)
        {
            return db.supermarket.Where(a => a.supermarket_id == id).ToList();
        }

        //Station_Group
        public List<station_group> GetStationGroup()
        {
            return db.station_group.ToList();
        }
        public List<station_group> GetStationGroup(int id)
        {
            return db.station_group.Where(a => a.station_group_id == id).ToList();
        }

        //Station
        public List<station> GetStation()
        {
            return db.station.ToList();
        }
        public List<station> GetStationWithStationGroupId(int id)
        {
            var list = db.station.Where(a => a.station_group_id == id).ToList();
            return list;
        }
        public List<station> GetStation(int id)
        {
            return db.station.Where(a => a.station_id == id).ToList();
        }

        //Material
        public List<material> GetMaterial()
        {
            return db.material.ToList();
        }
        public List<material> GetMaterilWithStationId(int id)
        {
            var list = db.material.Where(a => a.station_id == id).ToList();
            return list;
        }
        public List<material> GetMaterial(int id)
        {
            return db.material.Where(a => a.material_id == id).ToList();
        }
        //Request
        public List<request> GetRequest()
        {
            return db.request.ToList();
        }
        public List<request> GetRequestedMaterial(List<material> materials)
        {
            List<request> list = new List<request>();
            foreach(var item in materials)
            {
                var request = db.request.Where(a => a.requested_material_id == item.material_id).OrderByDescending(a => a.request_time).FirstOrDefault();
                if(request == null)
                {
                    request temp_request = new request();
                    temp_request.requested_material_id = item.material_id;
                    temp_request.requested_material_name = item.material_name + "temp_requst";
                    temp_request.request_time = DateTime.MinValue;
                    temp_request.manuel_request_status = true;
                    temp_request.request_status = true;
                    temp_request.response_time = DateTime.MaxValue;
                    temp_request.station_group_id = item.station_group_id;
                    temp_request.station_group_name = item.station_group_name;
                    temp_request.station_id = item.station_id;
                    temp_request.station_name = item.station_name;
                    temp_request.supermarket_id = item.supermarket_id;
                    temp_request.supermarket_name = item.supermarket_name;
                    db.Add(temp_request);
                    db.SaveChanges();
                    list.Add(temp_request);
                }
                else
                    list.Add(request);
            }
            return list;
        }
        public List<request> EditRequest()
        {
            return db.request.Where(a=>a.request_status == false && a.manuel_request_status == false).ToList();
        }
        public List<request> GetRequestWithSupermarketId(int id)
        {
            var list = db.request.Where(a => a.supermarket_id == id && a.request_status == false && a.manuel_request_status == false).ToList();
            return list;
        }
    }
}
