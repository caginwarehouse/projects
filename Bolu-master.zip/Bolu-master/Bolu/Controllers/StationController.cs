﻿using Bolu.Data;
using Bolu.Models;
using Microsoft.AspNetCore.Mvc;

namespace Bolu.Controllers
{
    public class StationController : Controller
    {
        public SysDataContext _db;
        public StationController(SysDataContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            MainModel model = new MainModel(_db);
            model.stations = model.GetStation();
            return View(model);
        }
        public IActionResult AddStation()
        {
            MainModel model = new MainModel(_db);
            model.station_groups = model.GetStationGroup();
            return View(model);
        }
        public IActionResult SaveStation(station formData)
        {
            var item = _db.station_group.Where(a => a.station_group_id == formData.station_group_id).FirstOrDefault();

            if (formData.station_id > 0)
            {
                station station = _db.station.Where(w => w.station_id == formData.station_id).First();
                station.station_name = formData.station_name.Trim();
                station.station_symbolic_point_id = formData.station_symbolic_point_id;
                station.station_group_id = formData.station_group_id;
                //station.station_group_name = formData.station_group_name;

                _db.SaveChanges();
            }
            else
            {
                _db.station.Add(new station()
                {
                    station_name = formData.station_name.Trim(),
                    station_symbolic_point_id = formData.station_symbolic_point_id,
                    station_group_id = formData.station_group_id,
                    station_group_name = item.station_group_name.Trim(),
                });

                _db.SaveChanges();
            }

            return Redirect("Index");
        }
        public IActionResult EditStation(int id)
        {
            MainModel model = new MainModel(_db);
            model.stations = model.GetStation(id);
            model.station_groups = model.GetStationGroup();
            return View(model);
        }
        public IActionResult DeleteStation(int id)
        {
            var station = _db.station.Where(w => w.station_id == id).FirstOrDefault();
            _db.station.Remove(station);
            _db.SaveChanges();
            return RedirectToAction("Index", "Station");
        }
    }
}
