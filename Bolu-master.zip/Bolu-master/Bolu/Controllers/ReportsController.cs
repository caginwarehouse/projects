﻿using Microsoft.AspNetCore.Mvc;

namespace Bolu.Controllers
{
    public class ReportsController : Controller
    {
        public IActionResult CancelledRequests()
        {
            return View();
        }

        public IActionResult RequestFulfillment()
        {
            return View();
        }
        public IActionResult SkuRequests()
        {
            return View();
        }
    }
}
