﻿using Bolu.Data;
using Bolu.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace Bolu.Controllers
{
    public class HomeController : Controller
    {
        public SysDataContext _db;
        private readonly ILogger<HomeController> _logger;

        public HomeController(SysDataContext db, ILogger<HomeController> logger)
        {
            _logger = logger;
            _db = db;
        }

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult ChooseStationGroup()
        {
            MainModel model = new MainModel(_db);
            model.station_groups = model.GetStationGroup();
            return View(model);
        }
        public IActionResult ChooseStation(int id)
        {
            MainModel model = new MainModel(_db);
            model.stations = model.GetStationWithStationGroupId(id);
            return View(model);
        }
        public IActionResult ChooseMaterial(int id)
        {
            MainModel model = new MainModel(_db);
            model.materials = model.GetMaterilWithStationId(id);
            model.requests = model.GetRequestedMaterial(model.materials);
            return View(model);
        }
        public IActionResult ChooseSupermarket()
        {
            MainModel model = new MainModel(_db);
            model.supermarkets = model.GetSupermarket();
            return View(model);
        }
        public IActionResult Settings()
        {
            return View();
        }
		public IActionResult Reports()
		{
			return View();
		}




		[ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}