﻿using Bolu.Data;
using Bolu.Models;
using Microsoft.AspNetCore.Mvc;

namespace Bolu.Controllers
{
    public class StationGroupController : Controller
    {
        public SysDataContext _db;
        public StationGroupController(SysDataContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            MainModel model = new MainModel(_db);
            model.station_groups = model.GetStationGroup();
            model.supermarkets = model.GetSupermarket();
            return View(model);
        }
        public IActionResult AddStationGroup()
        {
            MainModel model = new MainModel(_db);
            model.supermarkets = model.GetSupermarket();
            return View(model);
        }
        public IActionResult SaveStationGroup(station_group formData)
        {
            if (formData.station_group_id > 0)
            {
                station_group station_group = _db.station_group.Where(w => w.station_group_id == formData.station_group_id).First();
                station_group.station_group_name = formData.station_group_name.Trim();
                //station_group.supermarket_id = formData.supermarket_id;

                _db.SaveChanges();
            }
            else
            {
                _db.station_group.Add(new station_group()
                {
                    station_group_name = formData.station_group_name.Trim(),
                    supermarket_id = formData.supermarket_id,
                });

                _db.SaveChanges();
            }

            return Redirect("Index");
        }
        public IActionResult EditStationGroup(int id)
        {
            MainModel model = new MainModel(_db);
            model.station_groups = model.GetStationGroup(id);
            model.supermarkets = model.GetSupermarket();
            return View(model);
        }
        public IActionResult DeleteStationGroup(int id)
        {
            var stationgroup = _db.station_group.Where(w => w.station_group_id == id).FirstOrDefault();
            _db.station_group.Remove(stationgroup);
            _db.SaveChanges();
            return RedirectToAction("Index", "StationGroup");
        }
    }
}
