﻿using Bolu.Data;
using Bolu.Models;
using Microsoft.AspNetCore.Mvc;

namespace Bolu.Controllers
{
    public class SupermarketController : Controller
    {
        public SysDataContext _db;
        public SupermarketController(SysDataContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            MainModel model = new MainModel(_db);
            model.supermarkets = model.GetSupermarket();
            return View(model);
        }
        public IActionResult AddSupermarket()
        {
            return View();
        }
        public IActionResult SaveSupermarket(supermarket formData)
        {
            if (formData.supermarket_id > 0)
            {
                supermarket supermarket = _db.supermarket.Where(w => w.supermarket_id == formData.supermarket_id).First();
                supermarket.supermarket_name = formData.supermarket_name.Trim();
                supermarket.supermarket_symbolic_point = formData.supermarket_symbolic_point;

                _db.SaveChanges();
            }
            else
            {
                _db.supermarket.Add(new supermarket()
                {
                    supermarket_name = formData.supermarket_name.Trim(),
                    supermarket_symbolic_point = formData.supermarket_symbolic_point,
                });

                _db.SaveChanges();
            }

            return Redirect("Index");
        }
        public IActionResult EditSupermarket(int id)
        {
            MainModel model = new MainModel(_db);
            model.supermarkets = model.GetSupermarket(id);
            return View(model);
        }
        public IActionResult DeleteSupermarket(int id)
        {
            var supermarket = _db.supermarket.Where(w => w.supermarket_id == id).FirstOrDefault();
            _db.supermarket.Remove(supermarket);
            _db.SaveChanges();
            return RedirectToAction("Index", "Supermarket");
        }
    }
}
