﻿using Bolu.Data;
using Bolu.Models;
using Microsoft.AspNetCore.Mvc;

namespace Bolu.Controllers
{
    public class MaterialController : Controller
    {
        public SysDataContext _db;
        public MaterialController(SysDataContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            MainModel model = new MainModel(_db);
            model.materials = model.GetMaterial();
            return View(model);
        }
        public IActionResult AddMaterial()
        {
            MainModel model = new MainModel(_db);
            model.materials = model.GetMaterial();
            model.supermarkets = model.GetSupermarket();
            model.station_groups = model.GetStationGroup();
            model.stations = model.GetStation();
            return View(model);
        }
        public IActionResult SaveMaterial(material formData)
        {
            var item_station_group = _db.station_group.Where(a => a.station_group_id == formData.station_group_id).FirstOrDefault();
            var item_station = _db.station.Where(a => a.station_id == formData.station_id).FirstOrDefault();
            var item_supermarket = _db.supermarket.Where(a => a.supermarket_id == formData.supermarket_id).FirstOrDefault();

            if (formData.material_id > 0)
            {
                material material = _db.material.Where(w => w.material_id == formData.material_id).First();
                material.material_name = formData.material_name.Trim();
                //station.station_group_name = formData.station_group_name;

                _db.SaveChanges();
            }
            else
            {
                _db.material.Add(new material()
                {
                    material_name = formData.material_name.Trim(),
                    supermarket_id = item_supermarket.supermarket_id,
                    supermarket_name = item_supermarket.supermarket_name.Trim(),
                    station_group_id = item_station_group.station_group_id,
                    station_group_name = item_station_group.station_group_name.Trim(),
                    station_id = item_station.station_id,
                    station_name = item_station.station_name.Trim(),
                });

                _db.SaveChanges();
            }

            return Redirect("Index");
        }
        public IActionResult EditMaterial(int id)
        {
            MainModel model = new MainModel(_db);
            model.materials = model.GetMaterial(id);
            return View(model);
        }
        public IActionResult DeleteMaterial(int id)
        {
            var material = _db.material.Where(w => w.material_id == id).FirstOrDefault();
            _db.material.Remove(material);
            _db.SaveChanges();
            return RedirectToAction("Index", "Material");
        }
    }
}
