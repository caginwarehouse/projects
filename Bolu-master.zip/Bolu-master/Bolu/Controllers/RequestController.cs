﻿using Bolu.Data;
using Bolu.Models;
using Microsoft.AspNetCore.Mvc;
using System.Net.Sockets;

namespace Bolu.Controllers
{
    public class RequestController : Controller
    {
        public SysDataContext _db;

        [Serializable]
        public class MesFrame
        {
            public UInt16 Id;
            public UInt16 SenderId;
            public UInt16 ReceiverId;
            public Byte MessageType;
            public Int16 DataLength;
        }
        [Serializable]
        public class AGVStatusResponse
        {
            public UInt16 Id;
            public UInt16 SenderId;
            public UInt16 ReceiverId;
            public Byte MessageType;
            public Int16 DataLength;
            public UInt16 MachineId;
            public double X;
            public double Y;
            public double H;
            public Int16 Level;
            public byte PositionConfidence;
            public double SpeedNavigationPoint;
            public byte State;
            public double BatteryLevel;
            public sbyte AutoOrManual;
            public byte PositionInitialized;
            public Int32 LastSymbolPoint;
            public byte MachineAtLastSymbolPoint;
            public Int32 TargetSymbolPoint;
            public byte MachineAtTarget;
            public byte Operational;
            public byte InProduction;
            public byte LoadStatus;
            public double Batteryvoltage;
            public byte ChargingStatus;
        }
        //[Serializable]
        //public class ProductionOrderCompleted
        //{
        //    public UInt16 Id;
        //    public UInt16 SenderId;
        //    public UInt16 ReceiverId;
        //    public Byte MessageType;
        //    public Int16 DataLength;
        //    public UInt16 MachineId;
        //    public UInt16 NameStringLength;
        //    public string Name;
        //    public UInt32 ID;
        //}
        [Serializable]
        public class InputValuesResponse
        {
            public UInt16 MachineId;
            public Int16 DigitalInputlength;
            public byte DigitalInputs;
            public Int16 IntegerInputLength;
            public int IntegerInputs;
            public UInt16 FloatInputLength;
            public float FloatInPuts;
        }
        public class LastAgv
        {
            public int MachineId;
            public int LastSymbolPoint;
            public int MachineAtLastSymbolPoint;
        }

        public AGVStatusResponse Mes310(byte[] data)
        {
            if (data == null)
                return default(AGVStatusResponse);
            else
            {
                MesFrame frame = new MesFrame
                {
                    Id = BitConverter.ToUInt16(data, 0),
                    SenderId = BitConverter.ToUInt16(data, 2),
                    ReceiverId = BitConverter.ToUInt16(data, 4),
                    MessageType = data[6],
                    DataLength = BitConverter.ToInt16(data, 7),
                };
                AGVStatusResponse response = new AGVStatusResponse
                {
                    Id = BitConverter.ToUInt16(data, 0),
                    SenderId = BitConverter.ToUInt16(data, 2),
                    ReceiverId = BitConverter.ToUInt16(data, 4),
                    MessageType = data[6],
                    DataLength = BitConverter.ToInt16(data, 7),
                    MachineId = BitConverter.ToUInt16(data, 9),
                    X = BitConverter.ToDouble(data, 11),
                    Y = BitConverter.ToDouble(data, 19),
                    H = BitConverter.ToDouble(data, 27),
                    Level = BitConverter.ToInt16(data, 35),
                    PositionConfidence = data[37],
                    SpeedNavigationPoint = BitConverter.ToDouble(data, 38),
                    State = data[46],
                    BatteryLevel = BitConverter.ToDouble(data, 47),
                    AutoOrManual = (sbyte)data[55],
                    PositionInitialized = data[56],
                    LastSymbolPoint = BitConverter.ToInt32(data, 57),
                    MachineAtLastSymbolPoint = data[61],
                    TargetSymbolPoint = BitConverter.ToInt32(data, 62),
                    MachineAtTarget = data[66],
                    Operational = data[67],
                    InProduction = data[68],
                    LoadStatus = data[69],
                    Batteryvoltage = BitConverter.ToDouble(data, 70),
                    ChargingStatus = data[78]
                };
                return response;
            }

        }
        //public ProductionOrderCompleted Mes314(byte[] data)
        //{
        //    if (data == null)
        //        return default(ProductionOrderCompleted);
        //    else
        //    {
        //        MesFrame frame = new MesFrame
        //        {
        //            Id = BitConverter.ToUInt16(data, 0),
        //            SenderId = BitConverter.ToUInt16(data, 2),
        //            ReceiverId = BitConverter.ToUInt16(data, 4),
        //            MessageType = data[6],
        //            DataLength = BitConverter.ToInt16(data, 7),
        //        };
        //        ProductionOrderCompleted response = new ProductionOrderCompleted
        //        {
        //            Id = BitConverter.ToUInt16(data, 0),
        //            SenderId = BitConverter.ToUInt16(data, 2),
        //            ReceiverId = BitConverter.ToUInt16(data, 4),
        //            MessageType = data[6],
        //            DataLength = BitConverter.ToInt16(data, 7),
        //            MachineId = BitConverter.ToUInt16(data, 9),
        //            NameStringLength = BitConverter.ToUInt16(data, 11),
        //            ID = BitConverter.ToUInt16(data, 15)
        //        };
        //        return response;
        //    }

        //}
        public RequestController(SysDataContext db)
        {
            _db = db;
        }
        public IActionResult Index(int id)
        {
            MainModel model = new MainModel(_db);
            model.requests = model.GetRequestWithSupermarketId(id);
            return View(model);
        }
        public IActionResult EditRequest()
        {
            MainModel model = new MainModel(_db);
            model.requests = model.EditRequest();
            return View(model);
        }
        public IActionResult DeleteRequest(int id)
        {
            var request = _db.request.Where(w => w.request_id== id).FirstOrDefault();
            request.manuel_request_status = true;
            _db.SaveChanges();
            return RedirectToAction("EditRequest", "Request");

        }

        public void Add_Request(int material_id)
        {
            var material = _db.material.Where(a => a.material_id == material_id).FirstOrDefault();
            request rq = new request
            {
                requested_material_id = material_id,
                requested_material_name = material.material_name,
                supermarket_name = material.supermarket_name,
                supermarket_id = material.supermarket_id,
                station_group_name = material.station_group_name,
                station_group_id = material.station_group_id,
                station_id = material.station_id,
                station_name = material.station_name,
                request_time = DateTime.Now,
                request_status = false,
                manuel_request_status = false,
            };
            _db.request.Add(rq);
            _db.SaveChanges();
        }
        public void Send_Material(String server, int requestId)
        {
            try
            {
                // gelen request 
                var request = _db.request.FirstOrDefault(a => a.request_id == requestId);
                request.response_time = DateTime.Now;
                _db.SaveChanges();
                var station = _db.station.FirstOrDefault(a => a.station_id == request.station_id);
                var supermarket = _db.supermarket.FirstOrDefault(a => a.supermarket_id == request.supermarket_id);
                //byte symbolicPoint = (byte)station.station_symbolic_point_id;
                byte[] symbolicPoint = BitConverter.GetBytes(station.station_symbolic_point_id);
                int currentAgv = 0;
                Int32 port = 8015;
                TcpClient client = new TcpClient(server, port);
                Byte[] data = new Byte[1580];
                NetworkStream stream = client.GetStream();
                Int32 byteCount = stream.Read(data, 0, 1580);
                Thread.Sleep(1000);
                int cycle = 0;
                int cycle2 = 0;
                while (currentAgv == 0 || cycle < 20)
                {
                    cycle++;
                    if (cycle > 1)
                    {
                        client = new TcpClient(server, port);
                        byteCount = stream.Read(data, 0, 1580);
                    }

                    while (!client.Connected || data[79] != 54)
                    {
                        cycle2++;
                        client = new TcpClient(server, port);
                        byteCount = stream.Read(data, 0, 1580);
                        if (cycle2 % 5 == 0)
                            Thread.Sleep(1000);
                    }
                    AGVStatusResponse response = Mes310(data);
                    List<LastAgv> agv = new List<LastAgv>();
                    List<int> machineId = new List<int>();
                    int i = 0;
                    while (response.Id == 310 && !machineId.Contains(response.MachineId))
                    {
                        LastAgv agv1 = new LastAgv();
                        agv1.MachineId = response.MachineId;
                        agv1.LastSymbolPoint = response.LastSymbolPoint;
                        agv1.MachineAtLastSymbolPoint = response.MachineAtLastSymbolPoint;
                        machineId.Add(agv1.MachineId);
                        if (agv1.LastSymbolPoint == supermarket.supermarket_symbolic_point && agv1.MachineAtLastSymbolPoint == 1)
                        {
                            currentAgv = agv1.MachineId;
                            request.request_status = true;
                            _db.SaveChanges();
                        }
                        agv.Add(agv1);
                        i += 79;
                        response = Mes310(data.Skip(i).ToArray());
                    }
                    if (currentAgv != 0)
                        cycle = 21;
                }
                Random rnd = new Random();
                Byte orderId = Convert.ToByte(currentAgv + rnd.Next(100));
                //Byte[] sendToPoint = { 19, 0, 233, 3, 232, 3, 1, 13, 0, Convert.ToByte(currentAgv), 0, orderId, 0, 0, 0, symbolicPoint[0],symbolicPoint[1], 0, 0, 0, 4, 0 };
                //stream.Write(sendToPoint, 0, sendToPoint.Length);
                Thread.Sleep(1000);
                stream.Close();
                client.Close();
            }
            catch (ArgumentNullException e)
            {
                Console.WriteLine("ArgumentNullException: {0}", e);
            }
        }
    }
}
