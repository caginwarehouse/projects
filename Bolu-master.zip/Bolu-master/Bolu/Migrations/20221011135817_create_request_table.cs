﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Bolu.Migrations
{
    public partial class create_request_table : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "request",
                columns: table => new
                {
                    request_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    requested_material_name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    requested_material_id = table.Column<int>(type: "int", nullable: false),
                    supermarket_id = table.Column<int>(type: "int", nullable: false),
                    supermarket_name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    station_group_id = table.Column<int>(type: "int", nullable: false),
                    station_group_name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    station_id = table.Column<int>(type: "int", nullable: false),
                    station_name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    request_time = table.Column<DateTime>(type: "datetime2", nullable: false),
                    request_status = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_request", x => x.request_id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "request");
        }
    }
}
