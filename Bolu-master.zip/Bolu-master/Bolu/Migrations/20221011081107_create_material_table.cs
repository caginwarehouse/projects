﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Bolu.Migrations
{
    public partial class create_material_table : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "material",
                columns: table => new
                {
                    material_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    material_name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    supermarket_id = table.Column<int>(type: "int", nullable: false),
                    supermarket_name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    station_group_id = table.Column<int>(type: "int", nullable: false),
                    station_group_name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    station_id = table.Column<int>(type: "int", nullable: false),
                    station_name = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_material", x => x.material_id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "material");
        }
    }
}
