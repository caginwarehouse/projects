﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Bolu.Migrations
{
    public partial class add_manuel_request_status_and_response_time_to_request_table : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "manuel_request_status",
                table: "request",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<DateTime>(
                name: "response_time",
                table: "request",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "manuel_request_status",
                table: "request");

            migrationBuilder.DropColumn(
                name: "response_time",
                table: "request");
        }
    }
}
