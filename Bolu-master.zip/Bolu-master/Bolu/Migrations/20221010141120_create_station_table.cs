﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Bolu.Migrations
{
    public partial class create_station_table : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "station",
                columns: table => new
                {
                    station_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    station_name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    station_symbolic_point_id = table.Column<int>(type: "int", nullable: false),
                    station_group_id = table.Column<int>(type: "int", nullable: false),
                    station_group_name = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_station", x => x.station_id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "station");
        }
    }
}
