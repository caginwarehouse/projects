﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Bolu.Migrations
{
    public partial class create_supermarket_table : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "supermarket",
                columns: table => new
                {
                    supermarket_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    supermarket_name = table.Column<string>(type: "nvarchar(100)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_supermarket", x => x.supermarket_id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "supermarket");
        }
    }
}
