﻿using System.ComponentModel.DataAnnotations;

namespace Bolu.Data
{
    public class initialcreate
    {
        [Key]
        public int id { get; set; }
        public string? name { get; set; }
    }
}
