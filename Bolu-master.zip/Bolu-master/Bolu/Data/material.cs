﻿using System.ComponentModel.DataAnnotations;

namespace Bolu.Data
{
    public class material
    {
        [Key]
        public int material_id { get; set; }
        public string material_name { get; set; }
        public int supermarket_id { get; set; }
        public string supermarket_name { get; set; }
        public int station_group_id { get; set; }
        public string station_group_name { get; set; }
        public int station_id { get; set; }
        public string station_name { get; set; }
    }
}
