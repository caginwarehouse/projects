﻿using System.ComponentModel.DataAnnotations;

namespace Bolu.Data
{
    public class station
    {
        [Key]
        public int station_id { get; set; }
        public string station_name { get; set; }
        public int station_symbolic_point_id { get; set; }
        public int station_group_id { get; set; }
        public string station_group_name { get; set; }
    }
}
