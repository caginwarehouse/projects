﻿using System.ComponentModel.DataAnnotations;

namespace Bolu.Data
{
    public class request
    {
        [Key]
        public int request_id { get; set; }
        public string requested_material_name { get; set; }
        public int requested_material_id { get; set; }
        public int supermarket_id { get; set; }
        public string supermarket_name { get; set; }
        public int station_group_id { get; set; }
        public string station_group_name { get; set; }
        public int station_id { get; set; }
        public string station_name { get; set; }
        public DateTime request_time { get; set; }
        public DateTime response_time { get; set; }
        public bool request_status { get; set; }
        public bool manuel_request_status { get; set; }

    }
}
