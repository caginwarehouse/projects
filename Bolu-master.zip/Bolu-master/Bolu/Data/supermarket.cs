﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Bolu.Data
{
    public class supermarket
    {
        [Key]
        public int supermarket_id { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string supermarket_name { get; set; }
        public int supermarket_symbolic_point { get; set; }
    }
}
