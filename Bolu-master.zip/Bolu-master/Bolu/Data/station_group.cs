﻿using System.ComponentModel.DataAnnotations;

namespace Bolu.Data
{
    public class station_group
    {
        [Key]
        public int station_group_id { get; set; }
        public string station_group_name { get; set; }
        public int supermarket_id { get; set; }
    }
}
