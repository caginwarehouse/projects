﻿using Microsoft.EntityFrameworkCore;

namespace Bolu.Data
{
    public class SysDataContext : DbContext
    {
        public SysDataContext(DbContextOptions<SysDataContext> options) : base(options)
        {

        }
        public DbSet<initialcreate> initialcreate { get; set; }
        public DbSet<supermarket> supermarket { get; set; }
        public DbSet<station_group> station_group { get; set; }
        public DbSet<station> station { get; set; }
        public DbSet<material> material { get; set; }
        public DbSet<request> request { get; set; }
    }
}


