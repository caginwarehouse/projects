using System;
using System.Collections.Concurrent;
using System.ComponentModel;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text.Json;
using System.Threading;
using Microsoft.EntityFrameworkCore;
using Server_TE;
using Server_TE.Db;

namespace Server_TE
{
    public partial class Form1 : Form
    {
        TcpClient client;
        private BackgroundWorker worker;
        private BackgroundWorker logicWorker;
        private bool workerClosed = false;
        private bool closeFlag = false;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.Timer opcWatchDogTimer;
        private dbContext db;
        private BlockingCollection<AGVStatus> buffer = new BlockingCollection<AGVStatus>();
        private List<int> Supermarkets = [1, 11, 3, 4, 5];
        private static Dictionary<ushort, int> trackInfo = new Dictionary<ushort, int>();
        public event EventHandler AGVDataReady;

        static Dictionary<UInt16, stop_info> stop_tracking = new Dictionary<UInt16, stop_info>();
        static Dictionary<UInt16, move_info> move_tracking = new Dictionary<UInt16, move_info>();
        static Dictionary<UInt16, state_info> state_tracking = new Dictionary<UInt16, state_info>();
        public Form1()
        {
            InitializeComponent();

            // BackgroundWorker'� olu�turun
            worker = new BackgroundWorker();
            worker.WorkerSupportsCancellation = true;
            worker.DoWork += Worker_DoWork;
            worker.RunWorkerCompleted += Worker_RunWorkerCompleted; // �ndirme tamamland���nda tetiklenecek i�lev

            logicWorker = new BackgroundWorker();
            logicWorker.WorkerSupportsCancellation = true;
            logicWorker.DoWork += Logic_Worker_DoWork; // Arka plan i�i i�in i�lev


            timer = new System.Windows.Forms.Timer();
            timer.Interval = 5000; // 5 saniye
            timer.Tick += Timer_Tick;

            opcWatchDogTimer = new System.Windows.Forms.Timer();
            opcWatchDogTimer.Interval = 60000; // 5 saniye
            opcWatchDogTimer.Tick += opcWatchDogTimer_Tick;
            opcWatchDogTimer.Start();

            db = new dbContext();

        }

     

        private void Logic_Worker_DoWork(object sender, DoWorkEventArgs e)
        {
            trackInfo.Clear();

            this.Invoke(new Action(() =>
            {
                logicLabel.Text = "Running";
                logicLabel.ForeColor = Color.Green;
            }));
            while (true)
            {
                try
                {
                    if (buffer.Count > 0)
                    {
                        if (buffer.TryTake(out AGVStatus agvStatus, 100)) // 100 milisaniye bekle
                        {
                            if (!trackInfo.ContainsKey(agvStatus.MachineId))
                            {
                                if (Supermarkets.Contains(agvStatus.LastSymbolPoint) & agvStatus.MachineAtLastSymbolPoint != 1 && agvStatus.MachineAtTarget != 1 && agvStatus.TargetSymbolPoint > 0)
                                {
                                    DateTime tempDt = DateTime.Now;
                                    LiveTrack liveTrack = new LiveTrack
                                    {
                                        AgvId = agvStatus.MachineId,
                                        AssignedTime = tempDt,
                                        SupermarketId = agvStatus.LastSymbolPoint,
                                        StationId = agvStatus.TargetSymbolPoint,
                                        CurrentSpeed = agvStatus.SpeedNavigationPoint,
                                        CurrentCoordinateX = agvStatus.X,
                                        CurrentCoordinateY = agvStatus.Y,
                                        SumSpeed = agvStatus.SpeedNavigationPoint,
                                        Tick = 1,
                                    };
                                    db.LiveTracks.Add(liveTrack);
                                    db.SaveChanges();
                                    trackInfo.Add(agvStatus.MachineId, liveTrack.Id);
                                }
                            }
                            else
                            {
                                var liveTrackUpdate = db.LiveTracks.FirstOrDefault(u => u.Id == trackInfo[agvStatus.MachineId]);
                                if (liveTrackUpdate != null)
                                {
                                    if (agvStatus.LastSymbolPoint == liveTrackUpdate.StationId || Supermarkets.Contains(agvStatus.TargetSymbolPoint))
                                    {
                                        //_logger.LogInformation("Takibe siliniyor DB Id->" + liveTrackUpdate.Id);
                                        trackInfo.Remove(agvStatus.MachineId);
                                        db.LiveTracks.Remove(liveTrackUpdate);
                                    }
                                    else
                                    {
                                        //_logger.LogInformation("Takip g�ncelleniyor DB Id->" + liveTrackUpdate.Id);
                                        liveTrackUpdate.CurrentSpeed = agvStatus.SpeedNavigationPoint;
                                        liveTrackUpdate.CurrentCoordinateX = agvStatus.X;
                                        liveTrackUpdate.CurrentCoordinateY = agvStatus.Y;
                                        liveTrackUpdate.SumSpeed += agvStatus.SpeedNavigationPoint;
                                        liveTrackUpdate.Tick++;
                                    }
                                    db.SaveChanges();
                                }
                                else
                                {
                                    trackInfo.Remove(agvStatus.MachineId);
                                    // Handle the case where the LiveTrack is not found
                                    this.Invoke(new Action(() =>
                                    {
                                        richTextBox1.AppendText($"LiveTrack not found for machineId: {agvStatus.MachineId} - {DateTime.Now.ToString()} {Environment.NewLine}");
                                    }));
                                }
                            }


                            //mes move,stop, and state tracking section

                            if (agvStatus.SpeedNavigationPoint.CompareTo(0.08) > 0 || agvStatus.SpeedNavigationPoint.CompareTo(-0.08) < 0)
                            {
                                //stop save
                                if (stop_tracking.ContainsKey(agvStatus.MachineId))
                                {
                                    db.AgvStops.Add(new AgvStop
                                    {
                                        StopMachineId = agvStatus.MachineId,
                                        StopBeginTime = stop_tracking[agvStatus.MachineId].track_begin,
                                        StopEndTime = DateTime.Now,
                                        StopX = stop_tracking[agvStatus.MachineId].pos_x,
                                        StopY = stop_tracking[agvStatus.MachineId].pos_y,
                                        StopIsError = stop_tracking[agvStatus.MachineId].is_error_stop,
                                    });
                                    db.SaveChanges();
                                    stop_tracking.Remove(agvStatus.MachineId);
                                }
                                //move record start or update
                                if (!move_tracking.ContainsKey(agvStatus.MachineId))
                                {
                                    move_tracking.Add(agvStatus.MachineId, new move_info
                                    {
                                        track_begin = DateTime.Now,
                                        cycle_tick = 1,
                                        cycle_sum_speed = agvStatus.SpeedNavigationPoint,
                                        begin_pos_x = agvStatus.X,
                                        begin_pos_y = agvStatus.Y,
                                        on_Task = false,
                                    });
                                }
                                else
                                {
                                    move_tracking[agvStatus.MachineId].cycle_tick++;
                                    move_tracking[agvStatus.MachineId].cycle_sum_speed += agvStatus.SpeedNavigationPoint;
                                }
                            }
                            else
                            {
                                //stop record start or update
                                if (!stop_tracking.ContainsKey(agvStatus.MachineId))
                                {
                                    stop_tracking.Add(agvStatus.MachineId, new stop_info
                                    {
                                        pos_x = agvStatus.X,
                                        pos_y = agvStatus.Y,
                                        track_begin = DateTime.Now,
                                        is_error_stop = agvStatus.Operational == 0 ? true : false,
                                    });
                                }

                                //move record save
                                if (move_tracking.ContainsKey(agvStatus.MachineId))
                                {
                                    double avg_speed = Math.Round(move_tracking[agvStatus.MachineId].cycle_sum_speed / move_tracking[agvStatus.MachineId].cycle_tick, 2);
                                    db.AgvMoves.Add(new AgvMove
                                    {
                                        MoveMachineId = agvStatus.MachineId,
                                        MoveAvgSpeed = avg_speed,
                                        MoveBeginTime = move_tracking[agvStatus.MachineId].track_begin,
                                        MoveEndTime = DateTime.Now,
                                        MoveOnTask = move_tracking[agvStatus.MachineId].on_Task,
                                        MoveStartX = move_tracking[agvStatus.MachineId].begin_pos_x,
                                        MoveStartY = move_tracking[agvStatus.MachineId].begin_pos_y,
                                        MoveEndX = agvStatus.X,
                                        MoveEndY = agvStatus.Y,
                                    });
                                    db.SaveChanges();
                                    move_tracking.Remove(agvStatus.MachineId);
                                }
                            }

                            //State tracking
                            if (state_tracking.ContainsKey(agvStatus.MachineId))
                            {
                                //state change and record
                                if (state_tracking[agvStatus.MachineId].state != agvStatus.State)
                                {
                                    db.AgvStates.Add(new AgvState
                                    {
                                        StateMachineId = agvStatus.MachineId,
                                        StateBeginTime = state_tracking[agvStatus.MachineId].track_begin,
                                        StateEndTime = DateTime.Now,
                                        StateCode = state_tracking[agvStatus.MachineId].state,
                                        StateX = agvStatus.X,
                                        StateY = agvStatus.Y,
                                        StateTargetPoint = agvStatus.TargetSymbolPoint,
                                        StateLastPoint = agvStatus.LastSymbolPoint
                                    });
                                    db.SaveChanges();
                                    state_tracking.Remove(agvStatus.MachineId);

                                }
                            }
                            else if (agvStatus.State != 2 && agvStatus.State != 3 && agvStatus.State != 16 && agvStatus.State != 0) // state start without auto, standby, manuel
                            {
                                state_tracking.Add(agvStatus.MachineId, new state_info
                                {
                                    state = agvStatus.State,
                                    track_begin = DateTime.Now
                                });
                            }
                        }
                    }
                }
                catch (Exception ex2)
                {
                    this.Invoke(new Action(() =>
                    {
                        richTextBox1.AppendText("Db Save Error -> " + ex2.ToString() + DateTime.Now.ToString() + Environment.NewLine);
                    }));
                }

                if (logicWorker.CancellationPending)
                {
                    e.Cancel = true;
                    return;
                }
            }
        }

        private void Worker_DoWork(object sender, DoWorkEventArgs e)
        {
            this.Invoke(new Action(() =>
            {
                mesWorkerLabel.Text = "Running";
                mesWorkerLabel.ForeColor = Color.Green;
            }));
            client = new TcpClient();
            DeleteAllLiveTracks();

            client.ReceiveBufferSize = 1048576;
            client.ReceiveTimeout = 10000;
            const int SenderId = 1040;
            int buffer_pointer = 0;
            int read_count = 0;
            int available_amount = 0;
            int message_id = 0;
            int remainBufferPointer = 0;
            int message_length = 0;
            byte[] receiveBuffer = new byte[client.ReceiveBufferSize];
            byte[] remainReceiveBuffer = new byte[client.ReceiveBufferSize];

            int bufferCounter = 0;

            this.Invoke(new Action(() =>
            {
                richTextBox1.AppendText("TCP Connecting..." + Environment.NewLine);
            }));

            try
            {
                client.Connect("10.106.10.119", 8015); //Ankara
                this.Invoke(new Action(() =>
                {
                    richTextBox1.AppendText("Connected! " + DateTime.Now.ToString() + Environment.NewLine);
                }));
            }
            catch (SocketException ex)
            {
                this.Invoke(new Action(() =>
                {
                    richTextBox1.AppendText("Connection Fault! " + DateTime.Now.ToString() + Environment.NewLine);
                }));

                return;
            }
            NetworkStream stream = client.GetStream();
            while (true)
            {
                try
                {
                    while (client.Available < 300)
                    {
                        System.Threading.Thread.Sleep(1000);

                        bufferCounter++;
                        

                        this.Invoke(new Action(() =>
                        {
                            richTextBox1.AppendText("There is no byte to receive! " + DateTime.Now.ToString() + Environment.NewLine);
                        }));
                        if (bufferCounter > 15)
                        {
                            e.Cancel = true;
                            return; // D�ng�den ��k�n
                        }
                        // �ptal token'�n� kontrol edin
                        if (worker.CancellationPending)
                        {
                            e.Cancel = true;
                            return; // D�ng�den ��k�n
                        }
                    }

                    available_amount = client.Available;
                    this.Invoke(new Action(() =>
                    {
                        //richTextBox1.AppendText("Readed " + available_amount.ToString() + " Bytes!" + Environment.NewLine);
                    }));
                    read_count = stream.Read(receiveBuffer, 0, available_amount);
                    buffer_pointer = 0;
                    if (remainBufferPointer > 0)
                    {
                        Buffer.BlockCopy(receiveBuffer, 0, remainReceiveBuffer, remainBufferPointer, read_count);
                        Buffer.BlockCopy(remainReceiveBuffer, 0, receiveBuffer, 0, read_count + remainBufferPointer);
                        read_count += remainBufferPointer;
                        remainBufferPointer = 0;
                    }
                    // Chunk process
                    while ((read_count - buffer_pointer) > 0)
                    {
                        if ((read_count - buffer_pointer) < 9) // check frame existence
                        {
                            remainBufferPointer = (read_count - buffer_pointer);
                            Buffer.BlockCopy(receiveBuffer, buffer_pointer, remainReceiveBuffer, 0, remainBufferPointer);
                            buffer_pointer = read_count;
                            break;
                        }

                        if (BitConverter.ToUInt16(receiveBuffer, buffer_pointer + 7) > (read_count - buffer_pointer - 9)) //message exist check
                        {
                            remainBufferPointer = (read_count - buffer_pointer);
                            Buffer.BlockCopy(receiveBuffer, buffer_pointer, remainReceiveBuffer, 0, remainBufferPointer);
                            buffer_pointer = read_count;
                            break;
                        }
                        message_id = BitConverter.ToUInt16(receiveBuffer, buffer_pointer);
                        message_length = (BitConverter.ToUInt16(receiveBuffer, buffer_pointer + 7)); //take message length before pass frame

                        buffer_pointer += 9; // PASS FRAME

                        //MESSAGE PARSING SECTION
                        switch (message_id)
                        {
                            case 310:
                                //Parsing Section


                                AGVStatus agvStatus = new AGVStatus
                                {
                                    MachineId = BitConverter.ToUInt16(receiveBuffer, buffer_pointer),
                                    X = BitConverter.ToDouble(receiveBuffer, buffer_pointer + 2),
                                    Y = BitConverter.ToDouble(receiveBuffer, buffer_pointer + 10),
                                    H = BitConverter.ToDouble(receiveBuffer, buffer_pointer + 18),
                                    Level = BitConverter.ToInt16(receiveBuffer, buffer_pointer + 26),
                                    PositionConfidence = receiveBuffer[buffer_pointer + 28],
                                    SpeedNavigationPoint = BitConverter.ToDouble(receiveBuffer, buffer_pointer + 29),
                                    State = receiveBuffer[buffer_pointer + 37],
                                    BatteryLevel = BitConverter.ToDouble(receiveBuffer, buffer_pointer + 38),
                                    AutoOrManual = (sbyte)receiveBuffer[buffer_pointer + 46],
                                    PositionInitialized = receiveBuffer[buffer_pointer + 47],
                                    LastSymbolPoint = BitConverter.ToInt32(receiveBuffer, buffer_pointer + 48),
                                    MachineAtLastSymbolPoint = receiveBuffer[buffer_pointer + 52],
                                    TargetSymbolPoint = BitConverter.ToInt32(receiveBuffer, buffer_pointer + 53),
                                    MachineAtTarget = receiveBuffer[buffer_pointer + 57],
                                    Operational = receiveBuffer[buffer_pointer + 58],
                                    InProduction = receiveBuffer[buffer_pointer + 59],
                                    LoadStatus = receiveBuffer[buffer_pointer + 60],
                                    Batteryvoltage = BitConverter.ToDouble(receiveBuffer, buffer_pointer + 61),
                                    ChargingStatus = receiveBuffer[buffer_pointer + 69]
                                };
                                buffer.TryAdd(agvStatus);
                                this.Invoke(new Action(() =>
                                {
                                    mesBufferByteCount.Text = $"{buffer.Count} Message";
                                    //richTextBox2.AppendText(agvStatus.MachineId.ToString() + " -> " + agvStatus.LastSymbolPoint.ToString() + agvStatus.LastSymbolPoint.ToString()  + Environment.NewLine);
                                }));
                                break;
                            case 200:
                                if (receiveBuffer[buffer_pointer] > 0)
                                    if (BitConverter.ToUInt16(receiveBuffer, buffer_pointer + 1) == 51)
                                        Console.WriteLine("Navithor 51 Msg Error->{0:D}" + receiveBuffer[buffer_pointer]);
                                break;
                            case 203:
                                Byte[] HeartBeatFrame = new byte[13];
                                Byte[] _MsgId = BitConverter.GetBytes((UInt16)204); Buffer.BlockCopy(_MsgId, 0, HeartBeatFrame, 0, 2);
                                Byte[] _SenderId = BitConverter.GetBytes((UInt16)SenderId); Buffer.BlockCopy(_SenderId, 0, HeartBeatFrame, 2, 2);
                                Byte[] _ReceiverId = BitConverter.GetBytes((UInt16)1000); Buffer.BlockCopy(_ReceiverId, 0, HeartBeatFrame, 4, 2);
                                HeartBeatFrame[6] = 0x00;
                                Byte[] _DataLength = BitConverter.GetBytes((UInt16)0); Buffer.BlockCopy(_DataLength, 0, HeartBeatFrame, 7, 2);
                                stream.Write(HeartBeatFrame, 0, HeartBeatFrame.Length);
                                break;
                            default:
                                Console.WriteLine("Passed {0:D} Message!" + message_id);
                                break;
                        }
                        buffer_pointer += message_length; // pass to other message
                        System.Threading.Thread.Sleep(100);
                        if (worker.CancellationPending)
                        {
                            e.Cancel = true;
                            return; // D�ng�den ��k�n
                        }
                    }

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                    this.Invoke(new Action(() =>
                    {
                        richTextBox1.AppendText(ex.ToString() + DateTime.Now.ToString() + Environment.NewLine);
                    }));
                    break;
                }
            }
        }

        private void Worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            // �ndirme tamamland���nda UI'yi g�ncelleyin
            this.Invoke(new Action(() =>
            {
                mesWorkerLabel.Text = "Stopped";
                mesWorkerLabel.ForeColor = Color.Red;
            }));
            client.Close();
            client.Dispose();
            workerClosed = true;
            DeleteAllLiveTracks();
            this.Invoke(new Action(() =>
            {
                logicLabel.Text = "Stopped";
                logicLabel.ForeColor = Color.Red;
            }));
            logicWorker.CancelAsync();
            try
            {
                buffer.Dispose();
                buffer = new BlockingCollection<AGVStatus>();
            }
            catch (Exception ex) { }
            if (!closeFlag)
            {
                timer.Start();
            }
        }

        private void opcWatchDogTimer_Tick(object sender, EventArgs e)
        {
            string serviceName = "OPCService";
            System.ServiceProcess.ServiceController? serviceController = new System.ServiceProcess.ServiceController(serviceName);
            TimeSpan timeoutTime = TimeSpan.FromSeconds(45);

            if (serviceController != null)
            {
                if (serviceController.Status == System.ServiceProcess.ServiceControllerStatus.Stopped)
                {
                    opcWacthDogLabel.Text = "Service Stopped";
                    opcWacthDogLabel.ForeColor = Color.Red;
                }
                else if (serviceController.Status == System.ServiceProcess.ServiceControllerStatus.Running)
                {
                    opcWacthDogLabel.Text = "Service Running";
                    opcWacthDogLabel.ForeColor = Color.Green;
                }

                if (serviceController.Status == System.ServiceProcess.ServiceControllerStatus.Stopped)
                {
                    serviceController.Start();
                    serviceController.WaitForStatus(System.ServiceProcess.ServiceControllerStatus.Running, timeoutTime);
                    if (serviceController.Status != System.ServiceProcess.ServiceControllerStatus.Running)
                    {
                        opcWatchDogTimer.Stop();
                    }
                }
            }
            
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            worker.RunWorkerAsync();
            workerClosed = false;
            logicWorker.RunWorkerAsync();
            timer.Stop(); // Timer'� durdur
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            worker.RunWorkerAsync();
            logicWorker.RunWorkerAsync();
        }



        private void button2_Click(object sender, EventArgs e)
        {
            if (worker.IsBusy)
            {
                this.Invoke(new Action(() =>
                {
                    mesWorkerLabel.Text = "Stopping";
                    mesWorkerLabel.ForeColor = Color.Red;
                }));
                worker.CancelAsync();
                while (!workerClosed)
                {
                    // Bekleme i�lemi
                    Application.DoEvents(); // Di�er UI olaylar�n� i�leme koyun
                }

            }
        }

        private void mesWorkRestartButton_Click(object sender, EventArgs e)
        {

        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
        }
        private void DeleteAllLiveTracks()
        {
            // T�m LiveTrack kay�tlar�n� sil
            db.LiveTracks.RemoveRange(db.LiveTracks.ToList());
            // De�i�iklikleri kaydet
            db.SaveChanges();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (worker.IsBusy)
            {
                mesWorkerLabel.Text = "Stopping";
                mesWorkerLabel.ForeColor = Color.Red;
                closeFlag = true;
                worker.CancelAsync();
                while (!workerClosed)
                {
                    // Bekleme i�lemi
                    Application.DoEvents(); // Di�er UI olaylar�n� i�leme koyun
                }
            }

            if (logicWorker.IsBusy)
            {
                logicLabel.Text = "Stopping";
                logicLabel.ForeColor = Color.Red;
                logicWorker.CancelAsync();
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }
}
