﻿using System;
using System.Collections.Generic;

namespace Server_TE.Db;

public partial class EnvWay
{
    public int WayDbId { get; set; }

    public int WayId { get; set; }

    public double WayX { get; set; }

    public double WayY { get; set; }

    public int WayLength { get; set; }
}
