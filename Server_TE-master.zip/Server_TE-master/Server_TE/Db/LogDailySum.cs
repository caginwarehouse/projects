﻿using System;
using System.Collections.Generic;

namespace Server_TE.Db;

public partial class LogDailySum
{
    public int DailySumId { get; set; }

    public double DailySumSpeed { get; set; }

    public int DailySumFaalAgv { get; set; }

    public int DailySumUtilRate { get; set; }

    public DateTime DailySumDate { get; set; }
}
