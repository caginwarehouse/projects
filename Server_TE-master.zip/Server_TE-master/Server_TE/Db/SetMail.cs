﻿using System;
using System.Collections.Generic;

namespace Server_TE.Db;

public partial class SetMail
{
    public int MailId { get; set; }

    public string MailAddress { get; set; } = null!;

    public bool MailDaily { get; set; }

    public bool MailWeekly { get; set; }
}
