﻿using System;
using System.Collections.Generic;

namespace Server_TE.Db;

public partial class SetPlant
{
    public int PlantSetId { get; set; }

    public int PlantSetShiftMinute { get; set; }

    public int PlantSetShift1BeginHour { get; set; }

    public int PlantSetShift1EndHour { get; set; }

    public int PlantSetShift2BeginHour { get; set; }

    public int PlantSetShift2EndHour { get; set; }

    public int PlantSetShift3BeginHour { get; set; }

    public int PlantSetShift3EndHour { get; set; }
}
