﻿using System;
using System.Collections.Generic;

namespace Server_TE.Db;

public partial class LogRecord
{
    public int RecordId { get; set; }

    public string RecordString { get; set; } = null!;

    public int RecordValue { get; set; }
}
