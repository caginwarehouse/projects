﻿using System;
using System.Collections.Generic;

namespace Server_TE.Db;

public partial class AgvMove
{
    public long MoveId { get; set; }

    public int MoveMachineId { get; set; }

    public double MoveAvgSpeed { get; set; }

    public DateTime MoveBeginTime { get; set; }

    public DateTime MoveEndTime { get; set; }

    public bool MoveOnTask { get; set; }

    public double MoveStartX { get; set; }

    public double MoveStartY { get; set; }

    public double MoveEndX { get; set; }

    public double MoveEndY { get; set; }
}
