﻿using System;
using System.Collections.Generic;

namespace Server_TE.Db;

public partial class LogMove
{
    public long LogagvmoveId { get; set; }

    public int LogagvmoveAgvId { get; set; }

    public double LogagvmoveAvgSpeed { get; set; }

    public int LogagvmoveDurMin { get; set; }

    public DateOnly LogagvmoveDatetime { get; set; }
}
