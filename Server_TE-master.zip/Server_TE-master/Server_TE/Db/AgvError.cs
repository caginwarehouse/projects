﻿using System;
using System.Collections.Generic;

namespace Server_TE.Db;

public partial class AgvError
{
    public int ErrorDbId { get; set; }

    public int ErrorMachineId { get; set; }

    public int ErrorId { get; set; }

    public double ErrorX { get; set; }

    public double ErrorY { get; set; }

    public DateTime ErrorBeginTime { get; set; }

    public DateTime ErrorEndTime { get; set; }
}
