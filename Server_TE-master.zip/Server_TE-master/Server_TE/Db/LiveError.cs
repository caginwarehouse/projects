﻿using System;
using System.Collections.Generic;

namespace Server_TE.Db;

public partial class LiveError
{
    public int LiveErrorDbId { get; set; }

    public int LiveErrorMachineId { get; set; }

    public int LiveErrorId { get; set; }

    public double LiveErrorPosX { get; set; }

    public double LiveErrorPosY { get; set; }

    public DateTime LiveErrorBeginTime { get; set; }
}
