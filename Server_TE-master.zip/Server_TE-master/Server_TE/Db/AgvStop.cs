﻿using System;
using System.Collections.Generic;

namespace Server_TE.Db;

public partial class AgvStop
{
    public long StopId { get; set; }

    public int StopMachineId { get; set; }

    public double StopX { get; set; }

    public double StopY { get; set; }

    public DateTime StopBeginTime { get; set; }

    public DateTime StopEndTime { get; set; }

    public bool StopIsError { get; set; }
}
