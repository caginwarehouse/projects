﻿using System;
using System.Collections.Generic;

namespace Server_TE.Db;

public partial class AgvState
{
    public int StateId { get; set; }

    public int StateMachineId { get; set; }

    public int StateCode { get; set; }

    public DateTime StateBeginTime { get; set; }

    public DateTime StateEndTime { get; set; }

    public double StateX { get; set; }

    public double StateY { get; set; }

    public int StateTargetPoint { get; set; }

    public int StateLastPoint { get; set; }
}
