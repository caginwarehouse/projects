﻿using System;
using System.Collections.Generic;

namespace Server_TE.Db;

public partial class AgvCharge
{
    public int ChargeId { get; set; }

    public int ChargeMachineId { get; set; }

    public DateTime ChargeBeginTime { get; set; }

    public DateTime ChargeEndTime { get; set; }
}
