﻿using System;
using System.Collections.Generic;

namespace Server_TE.Db;

public partial class LiveTrack
{
    public int Id { get; set; }

    public int? AgvId { get; set; }

    public int? SupermarketId { get; set; }

    public int? StationId { get; set; }

    public DateTime? AssignedTime { get; set; }

    public double? CurrentSpeed { get; set; }

    public double? CurrentCoordinateX { get; set; }

    public double? CurrentCoordinateY { get; set; }

    public double? SumSpeed { get; set; }

    public int? Tick { get; set; }
}
