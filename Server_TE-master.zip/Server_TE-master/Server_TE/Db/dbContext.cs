﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace Server_TE.Db;

public partial class dbContext : DbContext
{
    public dbContext()
    {
    }

    public dbContext(DbContextOptions<dbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<AgvCharge> AgvCharges { get; set; }

    public virtual DbSet<AgvError> AgvErrors { get; set; }

    public virtual DbSet<AgvInfo> AgvInfos { get; set; }

    public virtual DbSet<AgvMove> AgvMoves { get; set; }

    public virtual DbSet<AgvState> AgvStates { get; set; }

    public virtual DbSet<AgvStop> AgvStops { get; set; }

    public virtual DbSet<EnvPoint> EnvPoints { get; set; }

    public virtual DbSet<EnvWay> EnvWays { get; set; }

    public virtual DbSet<EnvZone> EnvZones { get; set; }

    public virtual DbSet<ErrorDefination> ErrorDefinations { get; set; }

    public virtual DbSet<LiveError> LiveErrors { get; set; }

    public virtual DbSet<LiveTrack> LiveTracks { get; set; }

    public virtual DbSet<LogDailySum> LogDailySums { get; set; }

    public virtual DbSet<LogDelivery> LogDeliveries { get; set; }

    public virtual DbSet<LogMove> LogMoves { get; set; }

    public virtual DbSet<LogRecord> LogRecords { get; set; }

    public virtual DbSet<SetMail> SetMails { get; set; }

    public virtual DbSet<SetPlant> SetPlants { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=ANKSQLMRKDB1;Database=BMIAGVReports;User Id=agvbmiuser;Password=Z\"Zv)-PeMy6WH[%;Encrypt=False");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.UseCollation("Turkish_100_CI_AS");

        modelBuilder.Entity<AgvCharge>(entity =>
        {
            entity.HasKey(e => e.ChargeId).HasName("PK_charges");

            entity.ToTable("agvCharge");

            entity.Property(e => e.ChargeId).HasColumnName("charge_id");
            entity.Property(e => e.ChargeBeginTime).HasColumnName("charge_begin_time");
            entity.Property(e => e.ChargeEndTime).HasColumnName("charge_end_time");
            entity.Property(e => e.ChargeMachineId).HasColumnName("charge_machine_id");
        });

        modelBuilder.Entity<AgvError>(entity =>
        {
            entity.HasKey(e => e.ErrorDbId);

            entity.ToTable("agvError");

            entity.Property(e => e.ErrorDbId).HasColumnName("error_db_id");
            entity.Property(e => e.ErrorBeginTime).HasColumnName("error_begin_time");
            entity.Property(e => e.ErrorEndTime).HasColumnName("error_end_time");
            entity.Property(e => e.ErrorId).HasColumnName("error_id");
            entity.Property(e => e.ErrorMachineId).HasColumnName("error_machine_id");
            entity.Property(e => e.ErrorX).HasColumnName("error_x");
            entity.Property(e => e.ErrorY).HasColumnName("error_y");
        });

        modelBuilder.Entity<AgvInfo>(entity =>
        {
            entity.HasKey(e => e.AgvId);

            entity.ToTable("agvInfo");

            entity.Property(e => e.AgvId)
                .ValueGeneratedNever()
                .HasColumnName("agv_id");
            entity.Property(e => e.AgvCode)
                .HasMaxLength(4)
                .UseCollation("Latin1_General_CI_AS")
                .HasColumnName("agv_code");
            entity.Property(e => e.AgvFloor).HasColumnName("agv_floor");
            entity.Property(e => e.AgvGroupName)
                .HasMaxLength(100)
                .UseCollation("Latin1_General_CI_AS")
                .HasColumnName("agv_group_name");
            entity.Property(e => e.AgvName)
                .HasMaxLength(100)
                .UseCollation("Latin1_General_CI_AS")
                .HasColumnName("agv_name");
        });

        modelBuilder.Entity<AgvMove>(entity =>
        {
            entity.HasKey(e => e.MoveId).HasName("PK_moves");

            entity.ToTable("agvMove");

            entity.Property(e => e.MoveId).HasColumnName("move_id");
            entity.Property(e => e.MoveAvgSpeed).HasColumnName("move_avg_speed");
            entity.Property(e => e.MoveBeginTime).HasColumnName("move_begin_time");
            entity.Property(e => e.MoveEndTime).HasColumnName("move_end_time");
            entity.Property(e => e.MoveEndX).HasColumnName("move_end_x");
            entity.Property(e => e.MoveEndY).HasColumnName("move_end_y");
            entity.Property(e => e.MoveMachineId).HasColumnName("move_machine_id");
            entity.Property(e => e.MoveOnTask).HasColumnName("move_on_task");
            entity.Property(e => e.MoveStartX).HasColumnName("move_start_x");
            entity.Property(e => e.MoveStartY).HasColumnName("move_start_y");
        });

        modelBuilder.Entity<AgvState>(entity =>
        {
            entity.HasKey(e => e.StateId);

            entity.ToTable("agvState");

            entity.Property(e => e.StateId).HasColumnName("state_id");
            entity.Property(e => e.StateBeginTime).HasColumnName("state_begin_time");
            entity.Property(e => e.StateCode).HasColumnName("state_code");
            entity.Property(e => e.StateEndTime).HasColumnName("state_end_time");
            entity.Property(e => e.StateLastPoint).HasColumnName("state_last_point");
            entity.Property(e => e.StateMachineId).HasColumnName("state_machine_id");
            entity.Property(e => e.StateTargetPoint).HasColumnName("state_target_point");
            entity.Property(e => e.StateX).HasColumnName("state_x");
            entity.Property(e => e.StateY).HasColumnName("state_y");
        });

        modelBuilder.Entity<AgvStop>(entity =>
        {
            entity.HasKey(e => e.StopId);

            entity.ToTable("agvStop");

            entity.Property(e => e.StopId).HasColumnName("stop_id");
            entity.Property(e => e.StopBeginTime).HasColumnName("stop_begin_time");
            entity.Property(e => e.StopEndTime).HasColumnName("stop_end_time");
            entity.Property(e => e.StopIsError).HasColumnName("stop_is_error");
            entity.Property(e => e.StopMachineId).HasColumnName("stop_machine_id");
            entity.Property(e => e.StopX).HasColumnName("stop_x");
            entity.Property(e => e.StopY).HasColumnName("stop_y");
        });

        modelBuilder.Entity<EnvPoint>(entity =>
        {
            entity.HasKey(e => e.PointDbId).HasName("PK_symbolicPoints");

            entity.ToTable("envPoints");

            entity.Property(e => e.PointDbId).HasColumnName("point_db_id");
            entity.Property(e => e.PointId).HasColumnName("point_id");
            entity.Property(e => e.PointName)
                .HasMaxLength(100)
                .IsUnicode(false)
                .UseCollation("Latin1_General_CI_AS")
                .HasColumnName("point_name");
            entity.Property(e => e.PointX).HasColumnName("point_x");
            entity.Property(e => e.PointY).HasColumnName("point_y");
        });

        modelBuilder.Entity<EnvWay>(entity =>
        {
            entity.HasKey(e => e.WayDbId).HasName("PK_wayPoints");

            entity.ToTable("envWays");

            entity.Property(e => e.WayDbId).HasColumnName("way_db_id");
            entity.Property(e => e.WayId).HasColumnName("way_id");
            entity.Property(e => e.WayLength).HasColumnName("way_length");
            entity.Property(e => e.WayX).HasColumnName("way_x");
            entity.Property(e => e.WayY).HasColumnName("way_y");
        });

        modelBuilder.Entity<EnvZone>(entity =>
        {
            entity.HasKey(e => e.ZoneDbId).HasName("PK_virtualZones");

            entity.ToTable("envZones");

            entity.Property(e => e.ZoneDbId).HasColumnName("zone_db_id");
            entity.Property(e => e.ZoneId).HasColumnName("zone_id");
            entity.Property(e => e.ZoneLength).HasColumnName("zone_length");
            entity.Property(e => e.ZoneName)
                .HasMaxLength(200)
                .UseCollation("Latin1_General_CI_AS")
                .HasColumnName("zone_name");
            entity.Property(e => e.ZonePointId).HasColumnName("zone_point_id");
            entity.Property(e => e.ZonePointX).HasColumnName("zone_point_x");
            entity.Property(e => e.ZonePointY).HasColumnName("zone_point_y");
            entity.Property(e => e.ZoneTypeId).HasColumnName("zone_type_id");
        });

        modelBuilder.Entity<ErrorDefination>(entity =>
        {
            entity.HasKey(e => e.ErrorId);

            entity.ToTable("errorDefinations");

            entity.Property(e => e.ErrorId)
                .ValueGeneratedNever()
                .HasColumnName("error_id");
            entity.Property(e => e.ErrorColor).HasColumnName("error_color");
            entity.Property(e => e.ErrorGroup)
                .HasMaxLength(50)
                .IsUnicode(false)
                .UseCollation("Latin1_General_CI_AS")
                .HasColumnName("error_group");
            entity.Property(e => e.ErrorLogThreshold).HasColumnName("error_log_threshold");
            entity.Property(e => e.ErrorString)
                .HasMaxLength(500)
                .IsUnicode(false)
                .UseCollation("Latin1_General_CI_AS")
                .HasColumnName("error_string");
        });

        modelBuilder.Entity<LiveError>(entity =>
        {
            entity.HasKey(e => e.LiveErrorDbId);

            entity.ToTable("liveError");

            entity.Property(e => e.LiveErrorDbId).HasColumnName("live_error_db_id");
            entity.Property(e => e.LiveErrorBeginTime).HasColumnName("live_error_begin_time");
            entity.Property(e => e.LiveErrorId).HasColumnName("live_error_id");
            entity.Property(e => e.LiveErrorMachineId).HasColumnName("live_error_machine_id");
            entity.Property(e => e.LiveErrorPosX).HasColumnName("live_error_pos_x");
            entity.Property(e => e.LiveErrorPosY).HasColumnName("live_error_pos_y");
        });

        modelBuilder.Entity<LiveTrack>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("liveTrack_PK");

            entity.ToTable("liveTrack");

            entity.Property(e => e.AssignedTime).HasColumnType("datetime");
        });

        modelBuilder.Entity<LogDailySum>(entity =>
        {
            entity.HasKey(e => e.DailySumId);

            entity.ToTable("logDailySum");

            entity.Property(e => e.DailySumId).HasColumnName("daily_sum_id");
            entity.Property(e => e.DailySumDate).HasColumnName("daily_sum_date");
            entity.Property(e => e.DailySumFaalAgv).HasColumnName("daily_sum_faal_agv");
            entity.Property(e => e.DailySumSpeed).HasColumnName("daily_sum_speed");
            entity.Property(e => e.DailySumUtilRate).HasColumnName("daily_sum_util_rate");
        });

        modelBuilder.Entity<LogDelivery>(entity =>
        {
            entity.HasKey(e => e.DeliveryId).HasName("PK_runDelivery");

            entity.ToTable("logDelivery");

            entity.Property(e => e.DeliveryId).HasColumnName("delivery_id");
            entity.Property(e => e.DeliveryBeginTime).HasColumnName("delivery_begin_time");
            entity.Property(e => e.DeliveryEndTime).HasColumnName("delivery_end_time");
            entity.Property(e => e.DeliveryHoldTime).HasColumnName("delivery_hold_time");
            entity.Property(e => e.DeliveryMachineId).HasColumnName("delivery_machine_id");
            entity.Property(e => e.DeliveryStationId).HasColumnName("delivery_station_id");
            entity.Property(e => e.DeliverySupermarket)
                .HasMaxLength(250)
                .UseCollation("Latin1_General_CI_AS")
                .HasColumnName("delivery_supermarket");
        });

        modelBuilder.Entity<LogMove>(entity =>
        {
            entity.HasKey(e => e.LogagvmoveId);

            entity.ToTable("logMove");

            entity.Property(e => e.LogagvmoveId).HasColumnName("logagvmove_id");
            entity.Property(e => e.LogagvmoveAgvId).HasColumnName("logagvmove_agv_id");
            entity.Property(e => e.LogagvmoveAvgSpeed).HasColumnName("logagvmove_avg_speed");
            entity.Property(e => e.LogagvmoveDatetime).HasColumnName("logagvmove_datetime");
            entity.Property(e => e.LogagvmoveDurMin).HasColumnName("logagvmove_dur_min");
        });

        modelBuilder.Entity<LogRecord>(entity =>
        {
            entity.HasKey(e => e.RecordId);

            entity.ToTable("logRecord");

            entity.Property(e => e.RecordId).HasColumnName("record_id");
            entity.Property(e => e.RecordString)
                .HasMaxLength(200)
                .UseCollation("Latin1_General_CI_AS")
                .HasColumnName("record_string");
            entity.Property(e => e.RecordValue).HasColumnName("record_value");
        });

        modelBuilder.Entity<SetMail>(entity =>
        {
            entity.HasKey(e => e.MailId);

            entity.ToTable("setMail");

            entity.Property(e => e.MailId).HasColumnName("mail_id");
            entity.Property(e => e.MailAddress)
                .HasMaxLength(200)
                .UseCollation("Latin1_General_CI_AS")
                .HasColumnName("mail_address");
            entity.Property(e => e.MailDaily).HasColumnName("mail_daily");
            entity.Property(e => e.MailWeekly).HasColumnName("mail_weekly");
        });

        modelBuilder.Entity<SetPlant>(entity =>
        {
            entity.HasKey(e => e.PlantSetId);

            entity.ToTable("setPlant");

            entity.Property(e => e.PlantSetId).HasColumnName("plant_set_id");
            entity.Property(e => e.PlantSetShift1BeginHour).HasColumnName("plant_set_shift1_begin_hour");
            entity.Property(e => e.PlantSetShift1EndHour).HasColumnName("plant_set_shift1_end_hour");
            entity.Property(e => e.PlantSetShift2BeginHour).HasColumnName("plant_set_shift2_begin_hour");
            entity.Property(e => e.PlantSetShift2EndHour).HasColumnName("plant_set_shift2_end_hour");
            entity.Property(e => e.PlantSetShift3BeginHour).HasColumnName("plant_set_shift3_begin_hour");
            entity.Property(e => e.PlantSetShift3EndHour).HasColumnName("plant_set_shift3_end_hour");
            entity.Property(e => e.PlantSetShiftMinute).HasColumnName("plant_set_shift_minute");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
