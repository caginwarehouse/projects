﻿using System;
using System.Collections.Generic;

namespace Server_TE.Db;

public partial class EnvPoint
{
    public int PointDbId { get; set; }

    public int PointId { get; set; }

    public double PointX { get; set; }

    public double PointY { get; set; }

    public string PointName { get; set; } = null!;
}
