﻿using System;
using System.Collections.Generic;

namespace Server_TE.Db;

public partial class LogDelivery
{
    public int DeliveryId { get; set; }

    public int DeliveryMachineId { get; set; }

    public string DeliverySupermarket { get; set; } = null!;

    public int DeliveryStationId { get; set; }

    public DateTime DeliveryBeginTime { get; set; }

    public DateTime DeliveryEndTime { get; set; }

    public DateTime? DeliveryHoldTime { get; set; }
}
