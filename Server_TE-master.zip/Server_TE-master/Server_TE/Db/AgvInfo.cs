﻿using System;
using System.Collections.Generic;

namespace Server_TE.Db;

public partial class AgvInfo
{
    public int AgvId { get; set; }

    public string AgvName { get; set; } = null!;

    public string AgvGroupName { get; set; } = null!;

    public string AgvCode { get; set; } = null!;

    public short AgvFloor { get; set; }
}
