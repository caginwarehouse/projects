﻿using System;
using System.Collections.Generic;

namespace Server_TE.Db;

public partial class EnvZone
{
    public int ZoneDbId { get; set; }

    public int ZoneTypeId { get; set; }

    public int ZoneId { get; set; }

    public int ZonePointId { get; set; }

    public double ZonePointX { get; set; }

    public double ZonePointY { get; set; }

    public int ZoneLength { get; set; }

    public string ZoneName { get; set; } = null!;
}
