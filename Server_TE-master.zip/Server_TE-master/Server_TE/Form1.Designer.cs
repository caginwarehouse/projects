﻿namespace Server_TE
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            panel1 = new Panel();
            label5 = new Label();
            pictureBox4 = new PictureBox();
            panel2 = new Panel();
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            opcWacthDogLabel = new Label();
            label7 = new Label();
            pictureBox9 = new PictureBox();
            label6 = new Label();
            pictureBox8 = new PictureBox();
            pictureBox7 = new PictureBox();
            pictureBox6 = new PictureBox();
            pictureBox5 = new PictureBox();
            logicLabel = new Label();
            label3 = new Label();
            pictureBox3 = new PictureBox();
            mesBufferByteCount = new Label();
            label4 = new Label();
            pictureBox2 = new PictureBox();
            mesWorkerButton = new Button();
            mesWorkerLabel = new Label();
            label2 = new Label();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            tabPage2 = new TabPage();
            richTextBox1 = new RichTextBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            panel2.SuspendLayout();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            tabPage2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ActiveCaptionText;
            panel1.Controls.Add(label5);
            panel1.Controls.Add(pictureBox4);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(782, 125);
            panel1.TabIndex = 0;
            panel1.Paint += panel1_Paint;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 22.2F, FontStyle.Regular, GraphicsUnit.Point, 162);
            label5.ForeColor = SystemColors.ControlLightLight;
            label5.Location = new Point(93, 24);
            label5.Name = "label5";
            label5.Size = new Size(124, 50);
            label5.TabIndex = 1;
            label5.Text = "Server";
            // 
            // pictureBox4
            // 
            pictureBox4.BackgroundImage = Properties.Resources.TE_Logo;
            pictureBox4.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox4.Location = new Point(27, 12);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(60, 62);
            pictureBox4.TabIndex = 0;
            pictureBox4.TabStop = false;
            // 
            // panel2
            // 
            panel2.BackColor = Color.White;
            panel2.Controls.Add(tabControl1);
            panel2.Dock = DockStyle.Fill;
            panel2.Location = new Point(0, 125);
            panel2.Name = "panel2";
            panel2.Size = new Size(782, 428);
            panel2.TabIndex = 1;
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Dock = DockStyle.Fill;
            tabControl1.Location = new Point(0, 0);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(782, 428);
            tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            tabPage1.BackColor = Color.White;
            tabPage1.Controls.Add(opcWacthDogLabel);
            tabPage1.Controls.Add(label7);
            tabPage1.Controls.Add(pictureBox9);
            tabPage1.Controls.Add(label6);
            tabPage1.Controls.Add(pictureBox8);
            tabPage1.Controls.Add(pictureBox7);
            tabPage1.Controls.Add(pictureBox6);
            tabPage1.Controls.Add(pictureBox5);
            tabPage1.Controls.Add(logicLabel);
            tabPage1.Controls.Add(label3);
            tabPage1.Controls.Add(pictureBox3);
            tabPage1.Controls.Add(mesBufferByteCount);
            tabPage1.Controls.Add(label4);
            tabPage1.Controls.Add(pictureBox2);
            tabPage1.Controls.Add(mesWorkerButton);
            tabPage1.Controls.Add(mesWorkerLabel);
            tabPage1.Controls.Add(label2);
            tabPage1.Controls.Add(label1);
            tabPage1.Controls.Add(pictureBox1);
            tabPage1.Location = new Point(4, 29);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(774, 395);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Home";
            // 
            // opcWacthDogLabel
            // 
            opcWacthDogLabel.AutoSize = true;
            opcWacthDogLabel.Location = new Point(23, 353);
            opcWacthDogLabel.Name = "opcWacthDogLabel";
            opcWacthDogLabel.Size = new Size(120, 20);
            opcWacthDogLabel.TabIndex = 20;
            opcWacthDogLabel.Text = "status Checking...";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(23, 333);
            label7.Name = "label7";
            label7.Size = new Size(104, 20);
            label7.TabIndex = 19;
            label7.Text = "opcWatchDog";
            label7.Click += label7_Click;
            // 
            // pictureBox9
            // 
            pictureBox9.BackgroundImage = Properties.Resources.icons8_ethernet_hub_100;
            pictureBox9.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox9.Location = new Point(23, 229);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(100, 101);
            pictureBox9.TabIndex = 18;
            pictureBox9.TabStop = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(565, 137);
            label6.Name = "label6";
            label6.Size = new Size(115, 20);
            label6.TabIndex = 17;
            label6.Text = "BMIAGVReports";
            label6.Click += label6_Click;
            // 
            // pictureBox8
            // 
            pictureBox8.BackgroundImage = Properties.Resources.icons8_database_50;
            pictureBox8.BackgroundImageLayout = ImageLayout.Center;
            pictureBox8.Location = new Point(565, 72);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(66, 62);
            pictureBox8.TabIndex = 16;
            pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            pictureBox7.BackgroundImage = Properties.Resources.icons8_line_48__1_;
            pictureBox7.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox7.Location = new Point(471, 109);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(88, 25);
            pictureBox7.TabIndex = 15;
            pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.BackgroundImage = Properties.Resources.icons8_line_48__1_;
            pictureBox6.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox6.Location = new Point(306, 112);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(88, 25);
            pictureBox6.TabIndex = 14;
            pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.BackgroundImage = Properties.Resources.icons8_line_48__1_;
            pictureBox5.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox5.Location = new Point(129, 112);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(102, 25);
            pictureBox5.TabIndex = 13;
            pictureBox5.TabStop = false;
            // 
            // logicLabel
            // 
            logicLabel.AutoSize = true;
            logicLabel.Location = new Point(400, 160);
            logicLabel.Name = "logicLabel";
            logicLabel.Size = new Size(53, 20);
            logicLabel.TabIndex = 12;
            logicLabel.Text = "_status";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(400, 137);
            label3.Name = "label3";
            label3.Size = new Size(45, 20);
            label3.TabIndex = 11;
            label3.Text = "Logic";
            // 
            // pictureBox3
            // 
            pictureBox3.BackgroundImage = Properties.Resources.icons8_logic_64;
            pictureBox3.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox3.Location = new Point(400, 72);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(65, 62);
            pictureBox3.TabIndex = 10;
            pictureBox3.TabStop = false;
            // 
            // mesBufferByteCount
            // 
            mesBufferByteCount.AutoSize = true;
            mesBufferByteCount.Location = new Point(237, 161);
            mesBufferByteCount.Name = "mesBufferByteCount";
            mesBufferByteCount.Size = new Size(79, 20);
            mesBufferByteCount.TabIndex = 9;
            mesBufferByteCount.Text = "0 Message";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(237, 140);
            label4.Name = "label4";
            label4.Size = new Size(49, 20);
            label4.TabIndex = 7;
            label4.Text = "Buffer";
            // 
            // pictureBox2
            // 
            pictureBox2.BackgroundImage = Properties.Resources.icons8_line_48__2_;
            pictureBox2.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox2.Location = new Point(237, 72);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(63, 65);
            pictureBox2.TabIndex = 6;
            pictureBox2.TabStop = false;
            // 
            // mesWorkerButton
            // 
            mesWorkerButton.Location = new Point(23, 183);
            mesWorkerButton.Name = "mesWorkerButton";
            mesWorkerButton.Size = new Size(100, 40);
            mesWorkerButton.TabIndex = 5;
            mesWorkerButton.Text = "Restart";
            mesWorkerButton.UseVisualStyleBackColor = true;
            mesWorkerButton.Click += button2_Click;
            // 
            // mesWorkerLabel
            // 
            mesWorkerLabel.AutoSize = true;
            mesWorkerLabel.Location = new Point(23, 160);
            mesWorkerLabel.Name = "mesWorkerLabel";
            mesWorkerLabel.Size = new Size(53, 20);
            mesWorkerLabel.TabIndex = 3;
            mesWorkerLabel.Text = "_status";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(23, 140);
            label2.Name = "label2";
            label2.Size = new Size(83, 20);
            label2.TabIndex = 2;
            label2.Text = "mesWorker";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(23, 13);
            label1.Name = "label1";
            label1.Size = new Size(76, 20);
            label1.TabIndex = 1;
            label1.Text = "port: 8015";
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = Properties.Resources.icons8_ethernet_hub_100;
            pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox1.Location = new Point(23, 36);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(100, 101);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(richTextBox1);
            tabPage2.Location = new Point(4, 29);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(774, 395);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Worker Console";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // richTextBox1
            // 
            richTextBox1.Dock = DockStyle.Fill;
            richTextBox1.Location = new Point(3, 3);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(768, 389);
            richTextBox1.TabIndex = 0;
            richTextBox1.Text = "";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(782, 553);
            Controls.Add(panel2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            Text = "TE Server";
            FormClosing += Form1_FormClosing;
            FormClosed += Form1_FormClosed;
            Load += Form1_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            panel2.ResumeLayout(false);
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            tabPage2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private RichTextBox richTextBox1;
        private Label mesWorkerLabel;
        private Label label2;
        private Label label1;
        private PictureBox pictureBox1;
        private Button mesWorkerButton;
        private Label mesBufferByteCount;
        private Label label4;
        private PictureBox pictureBox2;
        private Label logicLabel;
        private Label label3;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private PictureBox pictureBox5;
        private PictureBox pictureBox6;
        private Label label5;
        private PictureBox pictureBox8;
        private PictureBox pictureBox7;
        private Label label6;
        private Label label7;
        private PictureBox pictureBox9;
        private Label opcWacthDogLabel;
    }
}
