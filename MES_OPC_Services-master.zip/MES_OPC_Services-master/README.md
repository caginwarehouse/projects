# MES_OPC_Services
Arcelik last services
