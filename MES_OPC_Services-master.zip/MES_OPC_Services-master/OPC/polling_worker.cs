using AnkaraOPCServicePolling.Db;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Primitives;
using Newtonsoft.Json.Linq;
using Opc.Ua;
using Opc.Ua.Client;
using Opc.Ua.Server;
using System.Diagnostics;

namespace AnkaraOPCServicePolling
{

    [Serializable]
    public class ErrorStamp
    {
        public int machineId { get; set; }
        public int errorId { get; set; }
        public string posX { get; set; }
        public string posY { get; set; }
        public DateTime stopBeginTime { get; set; }
    }

    public class Worker : BackgroundService
    {
        
        private readonly ILogger<Worker> _logger;
        private readonly IHostApplicationLifetime _hostApplicationLifetime;

        private static Opc.Ua.Client.Session session;
        public static dbContext db = new dbContext();
        public static Dictionary<int, List<NodeId>> errorNodeIds = new Dictionary<int, List<NodeId>>();
        public static Dictionary<uint, ErrorStamp> trackingAgvErrors = new Dictionary<uint, ErrorStamp>();
        public static Dictionary<uint, LiveError> liveErrors = new Dictionary<uint, LiveError>();
        public static List<NodeId> nodeIds = new List<NodeId>();
        public Worker(ILogger<Worker> logger)
        {
            _logger = logger;
        }

        public static void WriteToFile(string message)
        {
            string path = AppDomain.CurrentDomain.BaseDirectory + "\\Logs";
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            string filepath = AppDomain.CurrentDomain.BaseDirectory + "\\Logs\\ServiceLog_" + DateTime.Now.Date.ToShortDateString().Replace('/', '_') + ".txt";
            if (!File.Exists(filepath))
            {
                // Create a file to write to.   
                using (StreamWriter sw = File.CreateText(filepath))
                {
                    sw.WriteLine(message);
                }
            }
            else
            {
                using (StreamWriter sw = File.AppendText(filepath))
                {
                    sw.WriteLine(message);
                }
            }
        }

        public static void BrowseNode(NodeId nodeID)
        {
            WriteToFile("Browsing node: " + nodeID.ToString());
            ReferenceDescriptionCollection references;
            Byte[] continuationPoint;

            session.Browse(null, null, nodeID, 0u, BrowseDirection.Forward, ReferenceTypeIds.HierarchicalReferences, true, (uint)NodeClass.Object, out continuationPoint, out references);

            foreach (var rd in references)
            {
                if (rd.NodeId.ToString().Contains("Errors/"))
                {

                    string[] words = rd.NodeId.ToString().Split(Convert.ToChar("/"));
                    int agvId = Convert.ToInt32(words[1].Substring(3));
                    if (!errorNodeIds.ContainsKey(agvId))
                    {
                        errorNodeIds[agvId] = new List<NodeId>();
                    }
                    NodeId nodeId = new NodeId(rd.NodeId.ToString() + "/Id");
                    errorNodeIds[agvId].Add(nodeId);


                    WriteToFile("DisplayName: " + rd.DisplayName);
                    WriteToFile("BrowseName: " + rd.BrowseName);
                    WriteToFile("NodeId: " + rd.NodeId);
                    WriteToFile("NodeClass: " + rd.NodeClass);
                    WriteToFile("TypeDefinition: " + rd.TypeDefinition);
                    WriteToFile("-------------------------------------------------");
                }
                if (rd.NodeClass == NodeClass.Object || rd.NodeClass == NodeClass.Variable)
                {
                    BrowseNode(ExpandedNodeId.ToNodeId(rd.NodeId, session.NamespaceUris));
                }
            }


        }




        public static void readValuesFunc()
        {
            
           
            session.ReadValues(nodeIds, out DataValueCollection dataValues, out var errors);
            int startIndex = 0;
            foreach (int item in errorNodeIds.Keys)
            {
                int errorIndex = 1;

                List<DataValue> dataValuesForAGV = dataValues.GetRange(startIndex, 20);
                List<DataValue> positions = dataValues.GetRange(startIndex+20, 2);
                int machineId = Convert.ToInt32(item.ToString());
                foreach (DataValue dataValue in dataValuesForAGV)
                {
                    uint codePair = Convert.ToUInt32(machineId + errorIndex.ToString());
                    int errorId = (int)dataValue.Value;

                    if (!trackingAgvErrors.ContainsKey(codePair) && errorId != 0)
                    {
                        trackingAgvErrors.Add(codePair, new ErrorStamp
                        {
                            machineId = machineId,
                            errorId = errorId,
                            posX = positions[0].Value.ToString(),
                            posY = positions[1].Value.ToString(),
                            stopBeginTime = dataValue.ServerTimestamp.AddHours(3)
                        });

                        LiveError liveError = new LiveError
                        {
                            LiveErrorId = errorId,
                            LiveErrorMachineId = machineId,
                            LiveErrorPosX = Convert.ToDouble(trackingAgvErrors[codePair].posX),
                            LiveErrorPosY = Convert.ToDouble(trackingAgvErrors[codePair].posY),
                            LiveErrorBeginTime = dataValue.ServerTimestamp.AddHours(3),
                        };
                        db.LiveErrors.Add(liveError);
                        db.SaveChanges();
                        liveErrors.Add(codePair, liveError);
                    }
                    else if (trackingAgvErrors.ContainsKey(codePair) && errorId == 0)
                    {
                        if((DateTime.Now - trackingAgvErrors[codePair].stopBeginTime).TotalMinutes > 1)
                        {
                            AgvError errorStop = new AgvError()
                            {
                                ErrorMachineId = machineId,
                                ErrorId = trackingAgvErrors[codePair].errorId,
                                ErrorX = Convert.ToDouble(trackingAgvErrors[codePair].posX),
                                ErrorY = Convert.ToDouble(trackingAgvErrors[codePair].posY),
                                ErrorBeginTime = trackingAgvErrors[codePair].stopBeginTime,
                                ErrorEndTime = dataValue.ServerTimestamp.AddHours(3),
                            };
                            db.AgvErrors.Add(errorStop);
                        }
                        trackingAgvErrors.Remove(codePair);
                        db.LiveErrors.Remove(liveErrors[codePair]);
                        liveErrors.Remove(codePair);
                    }
                    errorIndex++;
                }
                startIndex += 22;
            }
            db.SaveChanges();
        }




        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            WriteToFile("Starting OPC UA console client...");
            _logger.LogInformation("Starting OPC UA console client...");
            var appConfig = new ApplicationConfiguration()
            {
                ApplicationName = "AnkaraOPCService",
                ApplicationUri = Utils.Format("urn:{0}:ConsoleClient", System.Net.Dns.GetHostName()),
                ApplicationType = ApplicationType.Client,
                SecurityConfiguration = new SecurityConfiguration
                {
                    ApplicationCertificate = new CertificateIdentifier
                    {
                        StoreType = @"Directory",
                        StorePath = @"%CommonApplicationData%\OPC Foundation\CertificateStores\MachineDefault",
                        SubjectName = Utils.Format("CN={0}, DC={1}", "ConsoleClient", System.Net.Dns.GetHostName())
                    },
                    TrustedPeerCertificates = new CertificateTrustList
                    {
                        StoreType = @"Directory",
                        StorePath = @"%CommonApplicationData%\OPC Foundation\CertificateStores\UA Applications",
                    },
                    RejectedCertificateStore = new CertificateTrustList
                    {
                        StoreType = @"Directory",
                        StorePath = @"%CommonApplicationData%\OPC Foundation\CertificateStores\RejectedCertificates",
                    },
                    AutoAcceptUntrustedCertificates = true
                },
                TransportQuotas = new TransportQuotas { OperationTimeout = 15000 },
                ClientConfiguration = new ClientConfiguration { DefaultSessionTimeout = 60000 }
            };

            appConfig.Validate(ApplicationType.Client).GetAwaiter().GetResult();
            if (appConfig.SecurityConfiguration.AutoAcceptUntrustedCertificates)
            {
                appConfig.CertificateValidator.CertificateValidation += (s, e) => { e.Accept = (e.Error.StatusCode == StatusCodes.BadCertificateUntrusted); };
            }

            //var endpointConfiguration = EndpointConfiguration.Create(appConfig);

            string endpointURL = "opc.tcp://10.106.10.119:4840";
            var selectedEndpoint = CoreClientUtils.SelectEndpoint(endpointURL, true, 15000);
            if (selectedEndpoint == null)
            {
                WriteToFile("Could not find an endpoint for specified URL: " + endpointURL);
                return;
            }

            var userIdentity = new UserIdentity(new AnonymousIdentityToken());
            session = Opc.Ua.Client.Session.Create(appConfig, new ConfiguredEndpoint(null, selectedEndpoint), false, "", 60000, userIdentity, null).GetAwaiter().GetResult();
            BrowseNode("ns=2;s=AGVs");

            foreach (int item in errorNodeIds.Keys)
            {
                NodeId nodeId_X = new NodeId("ns=2;s=" + "AGVs/AGV" + item.ToString() + "/State/PositionX");
                NodeId nodeId_Y = new NodeId("ns=2;s=" + "AGVs/AGV" + item.ToString() + "/State/PositionY");

                errorNodeIds[item].Add(nodeId_X);
                errorNodeIds[item].Add(nodeId_Y);
            }
            foreach (var item in errorNodeIds.Values)
            {
                nodeIds.AddRange(item);
            }
            while (!stoppingToken.IsCancellationRequested)
            {
                readValuesFunc();
                await Task.Delay(60000, stoppingToken);
            }
        }

        public override Task StopAsync(CancellationToken cancellationToken)
        {
            WriteToFile("Service is stopped at " + DateTime.Now);
            try
            {
                session.Close();
                if (!session.Connected)
                {
                    WriteToFile("Subscriptions cleaned successfully " + DateTime.Now.ToString());
                }
                else
                {
                    WriteToFile("Subscriptions could not be cleaned " + DateTime.Now.ToString());
                }
            }
            catch (Exception e)
            {
                WriteToFile(e.Message);
            }

            List<LiveError> dailyErrors = new List<LiveError>();
            dailyErrors = db.LiveErrors.ToList();
            db.LiveErrors.RemoveRange(dailyErrors);
            db.SaveChanges();
            WriteToFile("Daily Error table cleaned " + DateTime.Now.ToString());
            return base.StopAsync(cancellationToken);
        }

        public override Task StartAsync(CancellationToken cancellationToken)
        {
            WriteToFile("Service is started at " + DateTime.Now);
            List<LiveError> dailyErrors = new List<LiveError>();
            dailyErrors = db.LiveErrors.ToList();
            if (dailyErrors.Count > 0)
            {
                db.LiveErrors.RemoveRange(dailyErrors);
                db.SaveChanges();
            }
            WriteToFile("Daily Error table cleaned " + DateTime.Now.ToString());
            return base.StartAsync(cancellationToken);
        }
    }
}
