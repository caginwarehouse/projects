using AnkaraOPCService.Db;
using Opc.Ua;
using Opc.Ua.Client;

namespace AnkaraOPCService
{
    [Serializable]
    public class ErrorStamp
    {
        public UInt32 machineId { get; set; }
        public int errorId { get; set; }
        public string posX { get; set; }
        public string posY { get; set; }
        public DateTime stopBeginTime { get; set; }
    }
    public class Worker : BackgroundService
    {
        private readonly ILogger<Worker> _logger;
        private readonly IHostApplicationLifetime _hostApplicationLifetime;

        private static Opc.Ua.Client.Session session;
        public static Mutex mutex = new Mutex();
        public static dbContext db = new dbContext();
        public static Opc.Ua.Client.Subscription subscription;
        public static List<Opc.Ua.Client.MonitoredItem> monitoredItems = new List<Opc.Ua.Client.MonitoredItem>();
        public static Dictionary<uint, ErrorStamp> trackingAgvErrors = new Dictionary<uint, ErrorStamp>();
        public static Dictionary<uint, LiveError> liveErrors = new Dictionary<uint, LiveError>();
        public Worker(ILogger<Worker> logger)
        {
            _logger = logger;
        }
        public static void WriteToFile(string message)
        {
            string path = AppDomain.CurrentDomain.BaseDirectory + "\\Logs";
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            string filepath = AppDomain.CurrentDomain.BaseDirectory + "\\Logs\\ServiceLog_" + DateTime.Now.Date.ToShortDateString().Replace('/', '_') + ".txt";
            if (!File.Exists(filepath))
            {
                // Create a file to write to.   
                using (StreamWriter sw = File.CreateText(filepath))
                {
                    sw.WriteLine(message);
                }
            }
            else
            {
                using (StreamWriter sw = File.AppendText(filepath))
                {
                    sw.WriteLine(message);
                }
            }
        }

        public static void BrowseNode(NodeId nodeID)
        {
            WriteToFile("Browsing node: " + nodeID.ToString());
            ReferenceDescriptionCollection references;
            Byte[] continuationPoint;

            session.Browse(null, null, nodeID, 0u, BrowseDirection.Forward, ReferenceTypeIds.HierarchicalReferences, true, (uint)NodeClass.Object, out continuationPoint, out references);


            foreach (var rd in references)
            {
                if (rd.NodeId.ToString().Contains("Errors/"))
                {
                    WriteToFile("DisplayName: " + rd.DisplayName);
                    WriteToFile("BrowseName: " + rd.BrowseName);
                    WriteToFile("NodeId: " + rd.NodeId);
                    WriteToFile("NodeClass: " + rd.NodeClass);
                    WriteToFile("TypeDefinition: " + rd.TypeDefinition);
                    WriteToFile("-------------------------------------------------");

                    string NodeIdstr = rd.NodeId.ToString() + "/Id";
                    string[] words = rd.NodeId.ToString().Split(Convert.ToChar("/"));
                    string displayName = words[1].Substring(3) + "." + words[3].Substring(5);
                    Opc.Ua.Client.MonitoredItem monitoredItem = new Opc.Ua.Client.MonitoredItem();

                    //StartNodeId: The NodeId of the Node to monitor.
                    monitoredItem.StartNodeId = NodeIdstr;
                    //DisplayName: An optional display name for the MonitoredItem, which can be used for identification or user-friendly labelling.
                    monitoredItem.DisplayName = displayName;
                    //AttributeId: A client-specific handle that you can associate with the MonitoredItem. This handle is returned with the notification events for the MonitoredItem.
                    monitoredItem.AttributeId = Attributes.Value;
                    //MonitoringMode: Indicates whether the MonitoredItem is sampling or reporting.
                    //monitoredItem.MonitoringMode = MonitoringMode.Reporting;
                    //QueueSize: The maximum number of notifications to store in the queue for the MonitoredItem.
                    monitoredItem.QueueSize = 100;
                    //DiscardOldest: A boolean parameter that specifies whether the queue should discard the oldest or newest notification when the queue is full.
                    monitoredItem.DiscardOldest = true;
                    monitoredItem.Notification += handlerFunction;
                    monitoredItems.Add(monitoredItem);
                }
                if (rd.NodeClass == NodeClass.Object || rd.NodeClass == NodeClass.Variable)
                {
                    BrowseNode(ExpandedNodeId.ToNodeId(rd.NodeId, session.NamespaceUris));
                }
            }
        }

        public static async void handlerFunction(Opc.Ua.Client.MonitoredItem monitoredItem, MonitoredItemNotificationEventArgs args)
        {
            
            mutex.WaitOne();
            int errorId = 0;
            MonitoredItemNotification opcNotification = args.NotificationValue as MonitoredItemNotification;
            if(opcNotification == null)
            {
                mutex.ReleaseMutex();
                return;
            }

            errorId = (int)opcNotification.Value.Value;
            string[] words = monitoredItem.DisplayName.Split('.');
            string codePairstr = words[0] + words[1]; 
            uint codePair = Convert.ToUInt32(codePairstr);

            ///////no comms error handling
            if(errorId == 100001)
            {
                List<LiveError> liveErrorsList = db.LiveErrors.Where(x => x.LiveErrorMachineId == Convert.ToUInt32(words[0])).ToList();
                db.RemoveRange(liveErrorsList);
                db.SaveChanges();
                List<uint> temp_ErrorAgvPairList = new List<uint>();
                foreach (KeyValuePair<uint, ErrorStamp> item in trackingAgvErrors)
                {
                    if(item.Value.machineId == Convert.ToUInt32(words[0]))
                    {
                        temp_ErrorAgvPairList.Add(codePair);
                    }
                }
                foreach (uint item in temp_ErrorAgvPairList)
                {
                    trackingAgvErrors.Remove(item);
                }
                mutex.ReleaseMutex();
                return;
            }

            if(!trackingAgvErrors.ContainsKey(codePair) && errorId != 0 && errorId != 102002)
            {
                List<NodeId> nodeIds = new List<NodeId>
                {
                    new NodeId("ns=2;s=" + "AGVs/AGV" + words[0] + "/State/PositionX"),
                    new NodeId("ns=2;s=" + "AGVs/AGV" + words[0] + "/State/PositionY")
                };
                session.ReadValues(nodeIds, out DataValueCollection dataValues, out var errors);
                if(errors.Count > 0)
                {
                    trackingAgvErrors.Add(codePair, new ErrorStamp
                    {
                        machineId = Convert.ToUInt32(words[0]),
                        errorId = errorId,
                        posX = dataValues[0].Value.ToString(),
                        posY = dataValues[1].Value.ToString(),
                        stopBeginTime = DateTime.Now
                    });

                    LiveError liveError = new LiveError
                    {
                        LiveErrorId = errorId,
                        LiveErrorMachineId = Convert.ToInt32(words[0]),
                        LiveErrorPosX = Convert.ToDouble(trackingAgvErrors[codePair].posX),
                        LiveErrorPosY = Convert.ToDouble(trackingAgvErrors[codePair].posY),
                        LiveErrorBeginTime = DateTime.Now
                    };
                    db.LiveErrors.Add(liveError);
                    db.SaveChanges();
                    liveErrors.Add(codePair, liveError);
                } else if(trackingAgvErrors.ContainsKey(codePair) && errorId == 0 && errorId != 102002)
                {
                    if((DateTime.Now - trackingAgvErrors[codePair].stopBeginTime).TotalMinutes > 1)
                    {
                        AgvError errorStop = new AgvError()
                        {
                            ErrorMachineId = (int)Convert.ToUInt32(words[0]),
                            ErrorId = trackingAgvErrors[codePair].errorId,
                            ErrorX = Convert.ToDouble(trackingAgvErrors[codePair].posX),
                            ErrorY = Convert.ToDouble(trackingAgvErrors[codePair].posY),
                            ErrorBeginTime = trackingAgvErrors[codePair].stopBeginTime,
                            ErrorEndTime = DateTime.Now,
                        };
                        db.AgvErrors.Add(errorStop);
                    }
                    trackingAgvErrors.Remove(codePair);
                    db.LiveErrors.Remove(liveErrors[codePair]);
                    liveErrors.Remove(codePair);
                    db.SaveChanges();
                }
                mutex.ReleaseMutex();
            }
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            /////Execute
            ///
            WriteToFile("Starting OPC UA console client...");
            _logger.LogInformation("Starting OPC UA console client...");
            //Application configuration
            var appConfig = new ApplicationConfiguration()
            {
                ApplicationName = "AnkaraOPCService",
                ApplicationUri = Utils.Format("urn:{0}:ConsoleClient", System.Net.Dns.GetHostName()),
                ApplicationType = ApplicationType.Client,
                SecurityConfiguration = new SecurityConfiguration
                {
                    ApplicationCertificate = new CertificateIdentifier
                    {
                        StoreType = @"Directory",
                        StorePath = @"%CommonApplicationData%\OPC Foundation\CertificateStores\MachineDefault",
                        SubjectName = Utils.Format("CN={0}, DC={1}", "ConsoleClient", System.Net.Dns.GetHostName())
                    },
                    TrustedPeerCertificates = new CertificateTrustList
                    {
                        StoreType = @"Directory",
                        StorePath = @"%CommonApplicationData%\OPC Foundation\CertificateStores\UA Applications",
                    },
                    RejectedCertificateStore = new CertificateTrustList
                    {
                        StoreType = @"Directory",
                        StorePath = @"%CommonApplicationData%\OPC Foundation\CertificateStores\RejectedCertificates",
                    },
                    AutoAcceptUntrustedCertificates = true
                },
                TransportQuotas = new TransportQuotas { OperationTimeout = 15000 },
                ClientConfiguration = new ClientConfiguration { DefaultSessionTimeout = 60000 }
            };

            appConfig.Validate(ApplicationType.Client).GetAwaiter().GetResult();
            if(appConfig.SecurityConfiguration.AutoAcceptUntrustedCertificates)
            {
                appConfig.CertificateValidator.CertificateValidation += (s, e) => { e.Accept = (e.Error.StatusCode == StatusCodes.BadCertificateUntrusted); };
            }

            //var endpointConfiguration = EndpointConfiguration.Create(appConfig);

            string endpointURL = "opc.tcp://10.106.10.119:4840";
            var selectedEndpoint = CoreClientUtils.SelectEndpoint(endpointURL, true, 15000);
            if(selectedEndpoint == null)
            {
                WriteToFile("Could not find an endpoint for specified URL: " + endpointURL);
                return;
            }
            
            var userIdentity = new UserIdentity(new AnonymousIdentityToken());
            session =  Opc.Ua.Client.Session.Create(appConfig, new ConfiguredEndpoint(null, selectedEndpoint), false, "", 60000, userIdentity, null).GetAwaiter().GetResult();

            //Create subscription
            subscription = new Opc.Ua.Client.Subscription(session.DefaultSubscription) { PublishingInterval = 1000 };
            session.AddSubscription(subscription);
            subscription.Create();
            //Create monitored item
            BrowseNode("ns=2;s=AGVs");
            subscription.AddItems(monitoredItems);
            subscription.ApplyChanges();
            
            WriteToFile("Monitoring... " + DateTime.Now.ToString());

            while (!stoppingToken.IsCancellationRequested)
            {
                await Task.Delay(1000, stoppingToken);
            }
            
            WriteToFile("Session and Subscription closed " + DateTime.Now.ToString());

        }

        public override Task StopAsync(CancellationToken cancellationToken)
        {
            WriteToFile("Service is stopped at " + DateTime.Now);
            try
            {
                session.Close();
                if(!session.Connected)
                {
                    WriteToFile("Subscriptions cleaned successfully " + DateTime.Now.ToString());
                } else
                {
                    WriteToFile("Subscriptions could not be cleaned " + DateTime.Now.ToString());
                }
            } catch(Exception e)
            {
                WriteToFile(e.Message);
            }
            
            List<LiveError> dailyErrors = new List<LiveError>();
            dailyErrors = db.LiveErrors.ToList();
            db.LiveErrors.RemoveRange(dailyErrors);
            db.SaveChanges();
            WriteToFile("Daily Error table cleaned " + DateTime.Now.ToString());
            return base.StopAsync(cancellationToken);
        }

        public override Task StartAsync(CancellationToken cancellationToken)
        {
            WriteToFile("Service is started at " + DateTime.Now);
            List<LiveError> dailyErrors = new List<LiveError>();
            dailyErrors = db.LiveErrors.ToList();
            if(dailyErrors.Count > 0)
            {
                db.LiveErrors.RemoveRange(dailyErrors);
                db.SaveChanges();
            }
            WriteToFile("Daily Error table cleaned " + DateTime.Now.ToString());
            return base.StartAsync(cancellationToken);
        }
    }
}
