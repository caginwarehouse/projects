using AnkaraMESService.Db;
using Microsoft.Extensions.Logging;
using System.Diagnostics;
using System.Net.Sockets;

namespace AnkaraMESService
{
    public class Worker : BackgroundService
    {
        private readonly ILogger<Worker> _logger;
        private readonly IHostApplicationLifetime _hostApplicationLifetime;

        static Dictionary<UInt16, stop_info> stop_tracking = new Dictionary<UInt16, stop_info>();
        static Dictionary<UInt16, move_info> move_tracking = new Dictionary<UInt16, move_info>();
        static Dictionary<UInt16, state_info> state_tracking = new Dictionary<UInt16, state_info>();
        static Dictionary<UInt16, charge_info> charge_tracking = new Dictionary<UInt16, charge_info>();
        
        static Stopwatch stopwatch = new Stopwatch();

        public Worker(ILogger<Worker> logger)
        {
            _logger = logger;
        }

        public static void WriteToFile(string Message)
        {
            string path = AppDomain.CurrentDomain.BaseDirectory + "\\Logs";
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            string filepath = AppDomain.CurrentDomain.BaseDirectory + "\\Logs\\ServiceLog_" + DateTime.Now.ToString("dd_MM_yyyy");
            if (!File.Exists(filepath))
            {
                using (StreamWriter sw = File.CreateText(filepath))
                {
                    sw.WriteLine(Message);
                }
            }
            else
            {
                using (StreamWriter sw = File.AppendText(filepath))
                {
                    sw.WriteLine(Message);
                }
            }
        }

        static void tryConnect(ref TcpClient tcpClient)
        {
            try
            {
                tcpClient.Connect("10.106.10.119", 8015); //Ankara
            }
            catch (SocketException ex)
            {
                WriteToFile("Error : Connection Fail. Ex:");
                WriteToFile(ex.ToString());
            }
            finally
            {
                if (!tcpClient.Connected)
                {
                    tcpClient.Close();
                    Thread.Sleep(5000);
                    tryConnect(ref tcpClient); //recursion
                }
                WriteToFile("Connected!");
            }
        }

        public static void Task_310(byte[] receiveBuffer, int buffer_pointer, ref dbContext db) //
        {

            //Parsing Section
            AGVStatus agvStatus = new AGVStatus();
            agvStatus.MachineId = BitConverter.ToUInt16(receiveBuffer, buffer_pointer);
            agvStatus.X = BitConverter.ToDouble(receiveBuffer, buffer_pointer + 2);
            agvStatus.Y = BitConverter.ToDouble(receiveBuffer, buffer_pointer + 10);
            agvStatus.H = BitConverter.ToDouble(receiveBuffer, buffer_pointer + 18);
            agvStatus.Level = BitConverter.ToInt16(receiveBuffer, buffer_pointer + 26);
            agvStatus.PositionConfidence = receiveBuffer[buffer_pointer + 28];
            agvStatus.SpeedNavigationPoint = BitConverter.ToDouble(receiveBuffer, buffer_pointer + 29);
            agvStatus.State = receiveBuffer[buffer_pointer + 37];
            agvStatus.BatteryLevel = BitConverter.ToDouble(receiveBuffer, buffer_pointer + 38);
            agvStatus.AutoOrManual = (sbyte)receiveBuffer[buffer_pointer + 46];
            agvStatus.PositionInitialized = receiveBuffer[buffer_pointer + 47];
            agvStatus.LastSymbolPoint = BitConverter.ToInt32(receiveBuffer, buffer_pointer + 48);
            agvStatus.MachineAtLastSymbolPoint = receiveBuffer[buffer_pointer + 52];
            agvStatus.TargetSymbolPoint = BitConverter.ToInt32(receiveBuffer, buffer_pointer + 53);
            agvStatus.MachineAtTarget = receiveBuffer[buffer_pointer + 57];
            agvStatus.Operational = receiveBuffer[buffer_pointer + 58];
            agvStatus.InProduction = receiveBuffer[buffer_pointer + 59];
            agvStatus.LoadStatus = receiveBuffer[buffer_pointer + 60];
            agvStatus.Batteryvoltage = BitConverter.ToDouble(receiveBuffer, buffer_pointer + 61);
            agvStatus.ChargingStatus = receiveBuffer[buffer_pointer + 69];

            if (agvStatus.X != 0 && agvStatus.Y != 0)
            {
                if (agvStatus.SpeedNavigationPoint.CompareTo(0.08) > 0 || agvStatus.SpeedNavigationPoint.CompareTo(-0.08) < 0)
                {
                    //stop save
                    if (stop_tracking.ContainsKey(agvStatus.MachineId))
                    {
                        db.AgvStops.Add(new AgvStop
                        {
                            StopMachineId = agvStatus.MachineId,
                            StopBeginTime = stop_tracking[agvStatus.MachineId].track_begin,
                            StopEndTime = DateTime.Now,
                            StopX = stop_tracking[agvStatus.MachineId].pos_x,
                            StopY = stop_tracking[agvStatus.MachineId].pos_y,
                            StopIsError = stop_tracking[agvStatus.MachineId].is_error_stop,
                        });
                        db.SaveChanges();
                        stop_tracking.Remove(agvStatus.MachineId);
                    }

                    //move record start or update
                    if (!move_tracking.ContainsKey(agvStatus.MachineId))
                    {
                        move_tracking.Add(agvStatus.MachineId, new move_info
                        {
                            track_begin = DateTime.Now,
                            cycle_tick = 1,
                            cycle_sum_speed = agvStatus.SpeedNavigationPoint,
                            begin_pos_x = agvStatus.X,
                            begin_pos_y = agvStatus.Y,
                            on_Task = false,
                        });
                    }
                    else
                    {
                        move_tracking[agvStatus.MachineId].cycle_tick++;
                        move_tracking[agvStatus.MachineId].cycle_sum_speed += agvStatus.SpeedNavigationPoint;
                    }
                } else
                {
                    //stop record start or update
                    if (!stop_tracking.ContainsKey(agvStatus.MachineId))
                    {
                        stop_tracking.Add(agvStatus.MachineId, new stop_info
                        {
                            pos_x = agvStatus.X,
                            pos_y = agvStatus.Y,
                            track_begin = DateTime.Now,
                            is_error_stop = agvStatus.Operational == 0 ? true : false,
                        });
                    }

                    //move record save
                    if (move_tracking.ContainsKey(agvStatus.MachineId))
                    {
                        double avg_speed = Math.Round(move_tracking[agvStatus.MachineId].cycle_sum_speed / move_tracking[agvStatus.MachineId].cycle_tick, 2);
                        db.AgvMoves.Add(new AgvMove
                        {
                            MoveMachineId = agvStatus.MachineId,
                            MoveAvgSpeed = avg_speed,
                            MoveBeginTime = move_tracking[agvStatus.MachineId].track_begin,
                            MoveEndTime = DateTime.Now,
                            MoveOnTask = move_tracking[agvStatus.MachineId].on_Task,
                            MoveStartX = move_tracking[agvStatus.MachineId].begin_pos_x,
                            MoveStartY = move_tracking[agvStatus.MachineId].begin_pos_y,
                            MoveEndX = agvStatus.X,
                            MoveEndY = agvStatus.Y,
                        });
                        db.SaveChanges();
                        move_tracking.Remove(agvStatus.MachineId);
                    }
                }
                
                //State tracking
                if (state_tracking.ContainsKey(agvStatus.MachineId))
                {
                    //state change and record
                    if (state_tracking[agvStatus.MachineId].state != agvStatus.State)
                    {
                        db.AgvStates.Add(new AgvState
                        {
                            StateMachineId = agvStatus.MachineId,
                            StateBeginTime = state_tracking[agvStatus.MachineId].track_begin,
                            StateEndTime = DateTime.Now,
                            StateCode = state_tracking[agvStatus.MachineId].state,
                            StateX = agvStatus.X,
                            StateY = agvStatus.Y,
                            StateTargetPoint = agvStatus.TargetSymbolPoint,
                            StateLastPoint = agvStatus.LastSymbolPoint
                        });
                        db.SaveChanges();
                        state_tracking.Remove(agvStatus.MachineId);

                    }
                }
                else if (agvStatus.State != 2 && agvStatus.State != 3 && agvStatus.State != 16 && agvStatus.State != 0) // state start without auto, standby, manuel
                {
                    state_tracking.Add(agvStatus.MachineId, new state_info
                    {
                        state = agvStatus.State,
                        track_begin = DateTime.Now
                    });
                }

                //charge tracking
                if (charge_tracking.ContainsKey(agvStatus.MachineId))
                {
                    //state change and record
                    if (agvStatus.ChargingStatus == 0)
                    {
                        db.AgvCharges.Add(new AgvCharge
                        {
                            ChargeMachineId = agvStatus.MachineId,
                            ChargeBeginTime = charge_tracking[agvStatus.MachineId].beginTime,
                            ChargeEndTime = DateTime.Now,
                        });
                        db.SaveChanges();
                        charge_tracking.Remove(agvStatus.MachineId);

                    }
                }
                else if (agvStatus.ChargingStatus == 2) // charging start
                {
                    charge_tracking.Add(agvStatus.MachineId, new charge_info
                    {
                        beginTime = DateTime.Now
                    });
                }
            }
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            //TCP Client Connection Section
            TcpClient client = new TcpClient();
            client.ReceiveBufferSize = 1048576;
            WriteToFile("TCP Connecting....");
            tryConnect(ref client);
            NetworkStream stream = client.GetStream();
            client.ReceiveTimeout = 10000;
            const int SenderId = 1040;

            
            string logName = "MES_Service_App";
            string sourceName = "MES_Service_Source";


            if (!EventLog.SourceExists(sourceName))
            {
                EventLog.CreateEventSource(sourceName, logName);
            }

            int buffer_pointer = 0;
            int read_count = 0;
            int available_amount = 0;
            int message_id = 0;
            int remainBufferPointer = 0;
            int message_length = 0;

            byte[] receiveBuffer = new byte[client.ReceiveBufferSize];
            byte[] remainReceiveBuffer = new byte[client.ReceiveBufferSize];

            dbContext db = new dbContext();

            while (!stoppingToken.IsCancellationRequested)
            {
                while (client.Available < 300)
                {
                    System.Threading.Thread.Sleep(1000);
                    if (client.Available == 0)
                    {
                        if (!client.Connected)
                        {
                            client.Close();
                            WriteToFile("Warning : Connection Problem. Trying connect again!");
                            tryConnect(ref client);
                            continue;
                        }
                        WriteToFile("Warning : Navithor didn't send anything within 1 second! " + DateTime.Now.ToString());


                        if (stopwatch.IsRunning == false)
                        {
                            stopwatch.Start();
                        }
                        else
                        {
                            if (stopwatch.Elapsed.TotalMinutes > 2)
                            {
                                stopwatch.Stop();
                                stopwatch.Reset();

                                client.Close();

                                _logger.LogInformation("Service stopped at: {time}", DateTimeOffset.Now);

                                int eventId = 1001;

                                using (EventLog eventLog = new EventLog())
                                {
                                    eventLog.Source = sourceName;
                                    eventLog.WriteEntry("Connection Refresh", EventLogEntryType.Information, eventId);
                                }
                                _hostApplicationLifetime.StopApplication();
                            }
                        }

                    }
                }

                if (stopwatch.IsRunning)
                {
                    stopwatch.Stop();
                    stopwatch.Reset();
                }
                available_amount = client.Available;
                //WriteToFile("Readed {0:D} Bytes.", available_amount);
                read_count = stream.Read(receiveBuffer, 0, available_amount);
                buffer_pointer = 0;
                if (remainBufferPointer > 0)
                {
                    // add receiveBuffer to end of the remainReceiveBuffer 
                    Buffer.BlockCopy(receiveBuffer, 0, remainReceiveBuffer, remainBufferPointer, read_count);
                    // move all data from remainReceiveBuffer to receiveBuffer
                    Buffer.BlockCopy(remainReceiveBuffer, 0, receiveBuffer, 0, read_count + remainBufferPointer);
                    // clear remain buffer pointer
                    read_count += remainBufferPointer;
                    remainBufferPointer = 0;
                }

                // Chunk process
                while ((read_count - buffer_pointer) > 0)
                {
                    if ((read_count - buffer_pointer) < 9) // check frame existence
                    {
                        remainBufferPointer = (read_count - buffer_pointer);
                        Buffer.BlockCopy(receiveBuffer, buffer_pointer, remainReceiveBuffer, 0, remainBufferPointer);
                        buffer_pointer = read_count;
                        break;
                    }

                    if (BitConverter.ToUInt16(receiveBuffer, buffer_pointer + 7) > (read_count - buffer_pointer - 9)) //message exist check
                    {
                        remainBufferPointer = (read_count - buffer_pointer);
                        Buffer.BlockCopy(receiveBuffer, buffer_pointer, remainReceiveBuffer, 0, remainBufferPointer);
                        buffer_pointer = read_count;
                        break;
                    }

                    message_id = BitConverter.ToUInt16(receiveBuffer, buffer_pointer);
                    message_length = (BitConverter.ToUInt16(receiveBuffer, buffer_pointer + 7)); //take message length before pass frame

                    buffer_pointer += 9; // PASS FRAME

                    //MESSAGE PARSING SECTION
                    switch (message_id)
                    {
                        case 310:
                            Task_310(receiveBuffer, buffer_pointer, ref db); //
                            break;
                        case 200:
                            if (receiveBuffer[buffer_pointer] > 0)
                                if (BitConverter.ToUInt16(receiveBuffer, buffer_pointer + 1) == 51)
                                    WriteToFile("Navithor 51 Msg Error->{0:D}" + receiveBuffer[buffer_pointer]);
                            break;
                        case 203:
                            Byte[] HeartBeatFrame = new byte[13];
                            Byte[] _MsgId = BitConverter.GetBytes((UInt16)204); Buffer.BlockCopy(_MsgId, 0, HeartBeatFrame, 0, 2);
                            Byte[] _SenderId = BitConverter.GetBytes((UInt16)SenderId); Buffer.BlockCopy(_SenderId, 0, HeartBeatFrame, 2, 2);
                            Byte[] _ReceiverId = BitConverter.GetBytes((UInt16)1000); Buffer.BlockCopy(_ReceiverId, 0, HeartBeatFrame, 4, 2);
                            HeartBeatFrame[6] = 0x00;
                            Byte[] _DataLength = BitConverter.GetBytes((UInt16)0); Buffer.BlockCopy(_DataLength, 0, HeartBeatFrame, 7, 2);
                            stream.Write(HeartBeatFrame, 0, HeartBeatFrame.Length);
                            break;
                        default:
                            //WriteToFile("Passed {0:D} Message!", message_id);
                            break;
                    }

                    buffer_pointer += message_length; // pass to other message
                }


                //WriteToFile("Worker running at: " + DateTime.Now.ToString());
                //await Task.Delay(1000, stoppingToken);
            }
        }

        public override Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Worker stopped at: {time}", DateTimeOffset.Now);
            WriteToFile("Worker stopped at: " + DateTime.Now.ToString());

            dbContext db = new dbContext();
            if(stop_tracking.Count > 0)
            {
                foreach(var item in stop_tracking)
                {
                    db.AgvStops.Add(new AgvStop
                    {
                        StopMachineId = item.Key,
                        StopBeginTime = item.Value.track_begin,
                        StopEndTime = DateTime.Now,
                        StopX = item.Value.pos_x,
                        StopY = item.Value.pos_y,
                        StopIsError = item.Value.is_error_stop,
                    });
                    db.SaveChanges();
                }
            }

            return base.StopAsync(cancellationToken);
        }
        public override Task StartAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Worker started at: {time}", DateTimeOffset.Now);
            WriteToFile("Worker started at: " + DateTime.Now.ToString());

            return base.StartAsync(cancellationToken);  
        }
    }
}
