﻿using Reports.Db;

namespace Reports.Models
{
    public class CycleTimeModel
    {
        public List<string> Agv_Types { get; set; } = new List<string>();
        public List<string> first_dates { get; set; } = new List<string>();
        public string first_optimum_speed { get; set; } = new string("0");
        public string first_av_sum_speed { get; set; } = new string("0");
        public string first_av_sum_time { get; set; } = new string("0");
        public List<string> first_Agv_Speeds { get; set; } = new List<string>();
        public List<string> first_Station_Types { get; set; } = new List<string>();
        public List<string> first_Station_Group_Types { get; set; } = new List<string>();
        public List<string> first_Station_Times { get; set; } = new List<string>();
        public List<string> second_dates { get; set; } = new List<string>();
        public string second_optimum_speed { get; set; } = new string("0");
        public string second_av_sum_speed { get; set; } = new string("0");
        public string second_av_sum_time { get; set; } = new string("0");
        public List<string> second_Agv_Speeds { get; set; } = new List<string>();
        public List<string> second_Station_Types { get; set; } = new List<string>();
        public List<string> second_Station_Group_Types { get; set; } = new List<string>();
        public List<string> second_Station_Times { get; set; } = new List<string>();

        public List<Delivery> deliveries { get; set; } = new List<Delivery>();
    }
}
