﻿using Reports.Db;

namespace Reports.Models
{
    public class errorDetail
    {
        public int ErrorId { get; set; }
        public int ErrorCount { get; set; }
        public string ErrorMessage { get; set; } = string.Empty;
        public string ErrorGroup { get; set; } = string.Empty;
        public double ErrorDuration { get; set; } 
    }
    public class StationReportModel
    {
        public Dictionary<string, List<errorDetail>> errorsInZones { get; set; } = new Dictionary<string, List<errorDetail>>();

        public List<ErrorDefination> definations { get; set; } 
        public List<StationGroup> stationGroups { get; set; } 
        public List<Station> Stations { get; set; } 
    }
}
