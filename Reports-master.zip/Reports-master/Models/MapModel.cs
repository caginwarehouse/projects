﻿using Reports.Db;
using System.Drawing;

namespace Reports.Models
{




    public class ErrorMapSpecial
    {
        public int MachineId { get; set; }

        public int ErrorId { get; set; }
        public string ErrorString { get; set; } = null!;

        public double PosX { get; set; }

        public double PosY { get; set; }

        public DateTime TrackBeginTime { get; set; }
        public DateTime TrackEndTime { get; set; }
        public double TrackDuration { get; set; }
        public string ErrorColor { get; set; } = "#2596be";
    }

    public class errorList
    {
        public int ErrorId { get; set; }
        public string ErrorString { get; set; }
        public uint ErrorCount { get; set; }
        public double ErrorTotalDuration { get; set; }
    }

    public class MapModel
    {
        public List<ErrorMapSpecial> errorMapSpecials { get; set; } = new List<ErrorMapSpecial>();
        public List<SymbolicPoint> SymbolicPoints { get; set; }
        public List<Polygon> Polygons { get; set; }
        public List<WayPoint> WayPoints { get; set; }
        public List<errorList> errorList { get; set; } = new List<errorList>();
    }
}
