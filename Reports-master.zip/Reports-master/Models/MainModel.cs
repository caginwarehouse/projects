﻿using Microsoft.AspNetCore.Mvc;
using Reports.Db;
using System.Collections.Generic;

namespace Reports.Models
{
    
    public class MainModel
    {
        public dbContext db;
        

        public List<ErrorDefination> ErrorDefinations { get; set; }
        public List<Error> Errors { get; set; }
        public List<SymbolicPoint> SymbolicPoints { get; set; }
        public List<WayPoint> WayPoints { get; set; }
        public List<Agvinfo> Agvinfos { get; set; }
        public List<Delivery> Deliveries { get; set; }
        public List<Agvgroup> Agvgroups { get; set; }
        public List<Station> Stations { get; set; }
        public List<StationGroup> StationGroups { get; set; }
        public List<Supermarket> Supermarkets { get; set; }
        public List<Polygon> Polygons { get; set; }


        public MainModel(dbContext _db)
        {
            db = _db;
        }

        public List<Polygon> GetPolygons()
        {
            return db.Polygons.ToList();
        }

        public List<WayPoint> GetWayPoint()
        {
            return db.WayPoints.ToList();
        }


        public List<Station> GetStation()
        {
            return db.Stations.ToList();
        }

        public List<StationGroup> GetStationGroup()
        {
            return db.StationGroups.ToList();
        }

        public List<Supermarket> GetSupermarket()
        {
            return db.Supermarkets.ToList();
        }

        public List<Agvgroup> GetAgvgroups()
        {
            return db.Agvgroups.ToList();
        }

        public List<ErrorDefination> GetErrorDefinations()
        {
            return db.ErrorDefinations.ToList();
        }
        public List<Agvinfo> GetAgvinfos()
        {
            return db.Agvinfos.ToList();
        }

        public List<SymbolicPoint> GetSymbolicPoint()
        {
            return db.SymbolicPoints.ToList();
        }

        public List<Error> GetError()
        {
            return db.Errors.ToList();
        }

        public ErrorDefination GetErrorDefinationsWithId(int id)
        {
            return db.ErrorDefinations.Where(k => k.ErrorId == id).FirstOrDefault();
        }

    }
}
