﻿namespace Reports.Models
{
    public class SupermarketModel
    {
        public List<string> superMarkets { get; set; } = new List<string>();
        public List<string> Dates { get; set; } = new List<string>();
        public List<string[]> firstWaitingTimeLine { get; set; } = new List<string[]>();
        public List<string[]> firstCountTimeLine { get; set; } = new List<string[]>();
        public List<string> firstWaiting { get; set; } = new List<string>();
        public List<string> Count { get; set; } = new List<string>();
    }
}
