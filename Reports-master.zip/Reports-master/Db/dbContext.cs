﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace Reports.Db;

public partial class dbContext : DbContext
{
    public dbContext()
    {
    }

    public dbContext(DbContextOptions<dbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Agvgroup> Agvgroups { get; set; }

    public virtual DbSet<Agvinfo> Agvinfos { get; set; }

    public virtual DbSet<Error> Errors { get; set; }

    public virtual DbSet<ErrorDefination> ErrorDefinations { get; set; }

    public virtual DbSet<Polygon> Polygons { get; set; }

    public virtual DbSet<Station> Stations { get; set; }

    public virtual DbSet<StationGroup> StationGroups { get; set; }

    public virtual DbSet<StopTrack> StopTracks { get; set; }

    public virtual DbSet<Supermarket> Supermarkets { get; set; }

    public virtual DbSet<SymbolicPoint> SymbolicPoints { get; set; }

    public virtual DbSet<WayPoint> WayPoints { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=localhost;Database=bolu;Trusted_Connection=True;Encrypt=False");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Agvgroup>(entity =>
        {
            entity.ToTable("agvgroup");

            entity.Property(e => e.AgvGroupId).HasColumnName("agv_group_id");
            entity.Property(e => e.AgvGroupName)
                .HasMaxLength(100)
                .HasColumnName("agv_group_name");
        });

        modelBuilder.Entity<Agvinfo>(entity =>
        {
            entity.HasKey(e => e.AgvId);

            entity.ToTable("agvinfo");

            entity.Property(e => e.AgvId)
                .ValueGeneratedNever()
                .HasColumnName("agv_id");
            entity.Property(e => e.AgvAvalibility)
                .IsRequired()
                .HasDefaultValue(true)
                .HasColumnName("agv_avalibility");
            entity.Property(e => e.AgvCode)
                .HasMaxLength(4)
                .HasColumnName("agv_code");
            entity.Property(e => e.AgvGroupName)
                .HasMaxLength(100)
                .HasColumnName("agv_group_name");
            entity.Property(e => e.AgvName)
                .HasMaxLength(100)
                .HasColumnName("agv_name");
        });

        modelBuilder.Entity<Error>(entity =>
        {
            entity.HasKey(e => e.ErrorDbId);

            entity.ToTable("errors");

            entity.Property(e => e.ErrorDbId).HasColumnName("error_db_id");
            entity.Property(e => e.ErrorId).HasColumnName("error_id");
            entity.Property(e => e.MachineId).HasColumnName("machine_id");
            entity.Property(e => e.PosX).HasColumnName("pos_x");
            entity.Property(e => e.PosY).HasColumnName("pos_y");
            entity.Property(e => e.TrackBeginTime).HasColumnName("track_begin_time");
            entity.Property(e => e.TrackEndTime).HasColumnName("track_end_time");
        });

        modelBuilder.Entity<ErrorDefination>(entity =>
        {
            entity.HasKey(e => e.ErrorId).HasName("PK_error_definations");

            entity.ToTable("errorDefinations");

            entity.Property(e => e.ErrorId)
                .ValueGeneratedNever()
                .HasColumnName("error_id");
            entity.Property(e => e.ErrorColor)
                .HasDefaultValueSql("(0xFFFFFFFF)")
                .HasColumnName("error_color");
            entity.Property(e => e.ErrorGroup)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("error_group");
            entity.Property(e => e.ErrorLogThreshold).HasColumnName("error_log_threshold");
            entity.Property(e => e.ErrorString)
                .HasMaxLength(500)
                .IsUnicode(false)
                .HasColumnName("error_string");
        });

        modelBuilder.Entity<Polygon>(entity =>
        {
            entity.HasKey(e => e.PolygonDbId);

            entity.ToTable("polygon");

            entity.Property(e => e.PolygonDbId).HasColumnName("polygonDbId");
            entity.Property(e => e.PolygonLength).HasColumnName("polygonLength");
            entity.Property(e => e.PolygonName)
                .HasMaxLength(100)
                .HasColumnName("polygonName");
            entity.Property(e => e.PolygonPointId).HasColumnName("polygonPointId");
            entity.Property(e => e.PolygonPointX)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("polygonPointX");
            entity.Property(e => e.PolygonPointY)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("polygonPointY");
            entity.Property(e => e.PolygonTypeId).HasColumnName("polygonTypeId");
            entity.Property(e => e.PolygonZoneId).HasColumnName("polygonZoneId");
        });

        modelBuilder.Entity<Station>(entity =>
        {
            entity.ToTable("station");

            entity.Property(e => e.StationId).HasColumnName("station_id");
            entity.Property(e => e.StationGroupId).HasColumnName("station_group_id");
            entity.Property(e => e.StationGroupName)
                .HasMaxLength(100)
                .HasColumnName("station_group_name");
            entity.Property(e => e.StationName)
                .HasMaxLength(100)
                .HasColumnName("station_name");
            entity.Property(e => e.StationSymbolicPointId).HasColumnName("station_symbolic_point_id");
        });

        modelBuilder.Entity<StationGroup>(entity =>
        {
            entity.ToTable("station_group");

            entity.Property(e => e.StationGroupId).HasColumnName("station_group_id");
            entity.Property(e => e.StationGroupName)
                .HasMaxLength(100)
                .HasColumnName("station_group_name");
            entity.Property(e => e.SupermarketId).HasColumnName("supermarket_id");
        });

        modelBuilder.Entity<StopTrack>(entity =>
        {
            entity.HasKey(e => e.StopPointId);

            entity.ToTable("stopTrack");

            entity.Property(e => e.StopPointId).HasColumnName("stopPointId");
            entity.Property(e => e.StopBeforeSpeed).HasColumnName("stopBeforeSpeed");
            entity.Property(e => e.StopBeginTime).HasColumnName("stopBeginTime");
            entity.Property(e => e.StopDuration).HasColumnName("stopDuration");
            entity.Property(e => e.StopLastPoint).HasColumnName("stopLastPoint");
            entity.Property(e => e.StopMachineId).HasColumnName("stopMachineId");
            entity.Property(e => e.StopPointX).HasColumnName("stopPointX");
            entity.Property(e => e.StopPointY).HasColumnName("stopPointY");
            entity.Property(e => e.StopTargetPoint).HasColumnName("stopTargetPoint");
        });

        modelBuilder.Entity<Supermarket>(entity =>
        {
            entity.ToTable("supermarket");

            entity.Property(e => e.SupermarketId).HasColumnName("supermarket_id");
            entity.Property(e => e.SupermarketName)
                .HasMaxLength(100)
                .HasColumnName("supermarket_name");
            entity.Property(e => e.SupermarketSymbolicPoint).HasColumnName("supermarket_symbolic_point");
            entity.Property(e => e.SupermarketSymbolicPrePoint).HasColumnName("supermarket_symbolic_pre_point");
        });

        modelBuilder.Entity<SymbolicPoint>(entity =>
        {
            entity.HasKey(e => e.SymbolicPointDbId);

            entity.ToTable("symbolicPoints");

            entity.Property(e => e.SymbolicPointDbId).HasColumnName("symbolicPointDbId");
            entity.Property(e => e.SymbolicPointId).HasColumnName("symbolicPointId");
            entity.Property(e => e.SymbolicPointName)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("symbolicPointName");
            entity.Property(e => e.SymbolicPointX).HasColumnName("symbolicPointX");
            entity.Property(e => e.SymbolicPointY).HasColumnName("symbolicPointY");
        });

        modelBuilder.Entity<WayPoint>(entity =>
        {
            entity.HasKey(e => e.WayPointDbId);

            entity.ToTable("wayPoints");

            entity.Property(e => e.WayPointDbId).HasColumnName("wayPointDbId");
            entity.Property(e => e.WayPointId).HasColumnName("wayPointId");
            entity.Property(e => e.WayPointLength).HasColumnName("wayPointLength");
            entity.Property(e => e.WayPointX).HasColumnName("wayPointX");
            entity.Property(e => e.WayPointY).HasColumnName("wayPointY");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
