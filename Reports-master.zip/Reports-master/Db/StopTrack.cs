﻿using System;
using System.Collections.Generic;

namespace Reports.Db;

public partial class StopTrack
{
    public int StopPointId { get; set; }

    public double StopPointX { get; set; }

    public double StopPointY { get; set; }

    public DateTime StopBeginTime { get; set; }

    public long StopDuration { get; set; }

    public int StopTargetPoint { get; set; }

    public int StopLastPoint { get; set; }

    public int? StopMachineId { get; set; }

    public double? StopBeforeSpeed { get; set; }
}
