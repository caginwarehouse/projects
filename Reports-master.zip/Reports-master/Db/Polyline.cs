﻿using System;
using System.Collections.Generic;

namespace Reports.Db;

public partial class Polyline
{
    public int PolylineDbId { get; set; }

    public byte PolylinePointId { get; set; }

    public string PolylinePointX { get; set; } = null!;

    public string PolylinePointY { get; set; } = null!;

    public byte PolylineLength { get; set; }

    public string PolylineName { get; set; } = null!;
}
