﻿using System;
using System.Collections.Generic;

namespace Reports.Db;

public partial class Agvgroup
{
    public int AgvGroupId { get; set; }

    public string AgvGroupName { get; set; } = null!;
}
