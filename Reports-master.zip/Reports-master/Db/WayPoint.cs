﻿using System;
using System.Collections.Generic;

namespace Reports.Db;

public partial class WayPoint
{
    public int WayPointDbId { get; set; }

    public int WayPointId { get; set; }

    public double WayPointX { get; set; }

    public double WayPointY { get; set; }

    public int WayPointLength { get; set; }
}
