﻿using System;
using System.Collections.Generic;

namespace Reports.Db;

public partial class SymbolicPoint
{
    public int SymbolicPointDbId { get; set; }

    public int SymbolicPointId { get; set; }

    public double SymbolicPointX { get; set; }

    public double SymbolicPointY { get; set; }

    public string? SymbolicPointName { get; set; }
}
