﻿using System;
using System.Collections.Generic;

namespace Reports.Db;

public partial class ErrorDefination
{
    public int ErrorId { get; set; }

    public string ErrorString { get; set; } = null!;

    public int ErrorLogThreshold { get; set; }

    public int ErrorColor { get; set; }

    public string ErrorGroup { get; set; } = null!;
}
