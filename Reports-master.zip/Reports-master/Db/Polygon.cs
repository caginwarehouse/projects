﻿using System;
using System.Collections.Generic;

namespace Reports.Db;

public partial class Polygon
{
    public int PolygonDbId { get; set; }

    public byte PolygonTypeId { get; set; }

    public byte PolygonZoneId { get; set; }

    public byte PolygonPointId { get; set; }

    public string PolygonPointX { get; set; } = null!;

    public string PolygonPointY { get; set; } = null!;

    public byte PolygonLength { get; set; }

    public string PolygonName { get; set; }
}
