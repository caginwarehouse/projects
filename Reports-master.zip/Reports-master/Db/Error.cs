﻿using System;
using System.Collections.Generic;

namespace Reports.Db;

public partial class Error
{
    public int ErrorDbId { get; set; }

    public int MachineId { get; set; }

    public int ErrorId { get; set; }

    public double PosX { get; set; }

    public double PosY { get; set; }

    public DateTime TrackBeginTime { get; set; }

    public DateTime TrackEndTime { get; set; }
}
