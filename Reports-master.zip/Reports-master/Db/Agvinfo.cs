﻿using System;
using System.Collections.Generic;

namespace Reports.Db;

public partial class Agvinfo
{
    public int AgvId { get; set; }

    public string AgvName { get; set; } = null!;

    public string AgvGroupName { get; set; } = null!;

    public string AgvCode { get; set; } = null!;

    public bool AgvAvalibility { get; set; }
}
