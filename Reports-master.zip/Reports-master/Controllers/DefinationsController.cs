﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.SqlServer.Server;
using Reports.Db;
using Reports.Models;
using System.Globalization;
using System.Xml.Linq;

namespace Reports.Controllers
{
    public class DefinationsController : Controller
    {
        public dbContext _db;
        public DefinationsController(dbContext db)
        {
            _db = db;
        }

        public IActionResult AgvGroup(Agvgroup formData)
        {
            MainModel returnModel = new MainModel(_db);
            if (formData.AgvGroupName != null)
            {
                Agvgroup agvgroup = _db.Agvgroups.Where(k => k.AgvGroupId == formData.AgvGroupId).FirstOrDefault();
                if (agvgroup != null)
                {
                    if (formData.AgvGroupName == "delete")
                    {
                        _db.Agvgroups.Remove(agvgroup);
                    }
                    else
                    {
                        agvgroup.AgvGroupName = formData.AgvGroupName;
                    }
                }
                else
                {
                    Agvgroup newAgvGroup = new Agvgroup { AgvGroupName = formData.AgvGroupName };
                    _db.Agvgroups.Add(newAgvGroup);
                }
                _db.SaveChanges();
            }
            returnModel.Agvgroups = returnModel.GetAgvgroups();
            return View(returnModel);
        }
       
        public IActionResult Errors(ErrorDefination formData)
        {
            MainModel mainModel = new MainModel(_db);
            if (formData.ErrorId > 0)
            {
                ErrorDefination errorDefination = new ErrorDefination();
                errorDefination = mainModel.GetErrorDefinationsWithId(formData.ErrorId);

                if (errorDefination != null)
                {

                    ErrorDefination error = _db.ErrorDefinations.Where(w => w.ErrorId == formData.ErrorId).First();

                    if (formData.ErrorString != "delete")
                    {
                        error.ErrorString = formData.ErrorString.Trim();
                        error.ErrorGroup = formData.ErrorGroup;
                        error.ErrorLogThreshold = formData.ErrorLogThreshold;
                        error.ErrorColor = formData.ErrorColor;
                    }
                    else
                        _db.ErrorDefinations.Remove(error);
                }
                else
                {
                    _db.ErrorDefinations.Add(new ErrorDefination
                    {
                        ErrorId = formData.ErrorId,
                        ErrorString = formData.ErrorString,
                        ErrorGroup = formData.ErrorGroup,
                        ErrorLogThreshold = formData.ErrorLogThreshold,
                        ErrorColor = formData.ErrorColor
                    });
                }

                _db.SaveChanges();
            }
            mainModel.ErrorDefinations = mainModel.GetErrorDefinations();
            return View(mainModel);
        }

        public ErrorDefination GetSpecificError(int ErrorId)
        {
            MainModel mainModel = new MainModel(_db);
            ErrorDefination retrun_val = new ErrorDefination();

            retrun_val = mainModel.GetErrorDefinationsWithId(ErrorId);

            return(retrun_val);
        }

        public IActionResult WayPoints(IFormFile xmlFile)
        {
            MainModel mainModel = new MainModel(_db);
            mainModel.WayPoints = mainModel.GetWayPoint();
            if (xmlFile != null)
            {
                try
                {
                    foreach (WayPoint item in mainModel.WayPoints)
                        _db.WayPoints.Remove(item);
                    using (var stream = xmlFile.OpenReadStream())
                    {
                        XDocument xDoc = XDocument.Load(stream);
                        foreach (var XElement in xDoc.Descendants("segment"))
                        {
                            List<WayPoint> wayPoints = new List<WayPoint>();
                            int id = Convert.ToInt32(XElement.Element("id").Value);
                            int counter = 0;
                            foreach (var pts in XElement.Descendants("sp"))
                            {
                                WayPoint wayPoint = new WayPoint();
                                wayPoint.WayPointX = Convert.ToDouble(pts.Element("x").Value.ToString().Replace(".", ","));
                                wayPoint.WayPointY = Convert.ToDouble(pts.Element("y").Value.ToString().Replace(".", ","));
                                wayPoint.WayPointId = id;
                                wayPoint.WayPointLength = counter;
                                wayPoints.Add(wayPoint);
                                counter++;
                            }
                            if(Math.Round(wayPoints[0].WayPointX, 1) == Math.Round(wayPoints[wayPoints.Count - 1].WayPointX, 1) || Math.Round(wayPoints[0].WayPointY, 1) == Math.Round(wayPoints[(wayPoints.Count - 1)].WayPointY, 1))
                            {
                                wayPoints[0].WayPointLength = 2;
                                wayPoints[wayPoints.Count - 1].WayPointLength = 2;

                                _db.WayPoints.Add(wayPoints[0]);
                                _db.WayPoints.Add(wayPoints[wayPoints.Count - 1]);
                            } else
                            {
                                _db.WayPoints.AddRange(wayPoints);
                            }



                        }
                        _db.SaveChanges();
                    }
                }
                catch {}
            }
            return View(mainModel);
        }

        public IActionResult SymbolicPoints(IFormFile xmlFile)
        {
            MainModel mainModel = new MainModel(_db);
            mainModel.SymbolicPoints = mainModel.GetSymbolicPoint();
            if (xmlFile != null)
            {
                try
                {
                    
                    foreach (SymbolicPoint item in mainModel.SymbolicPoints)
                        _db.SymbolicPoints.Remove(item);

                    using (var stream = xmlFile.OpenReadStream())
                    {
                        XDocument xDoc = XDocument.Load(stream);
                        foreach (var XElement in xDoc.Descendants("symbolic_point"))
                        {
                            SymbolicPoint symbolicPoint = new SymbolicPoint();
                            symbolicPoint.SymbolicPointId = Convert.ToInt32(XElement.Element("id").Value);
                            symbolicPoint.SymbolicPointX = Convert.ToDouble(XElement.Element("x").Value.ToString().Replace(".",","));
                            symbolicPoint.SymbolicPointY = Convert.ToDouble(XElement.Element("y").Value.ToString().Replace(".", ","));
                            symbolicPoint.SymbolicPointName = XElement.Element("name").Value.ToString();
                            _db.SymbolicPoints.Add(symbolicPoint);
                        }

                        _db.SaveChanges();

                        // Reload the symbolic points list and return a success message
                        var updatedPoints = _db.SymbolicPoints.ToList();
                        //return Json(new { success = true, message = "Database upload successful!", points = updatedPoints });
                    }
                }
                catch (Exception ex)
                {
                    // Log the exception for debugging purposes
                    Console.WriteLine(ex.ToString());

                    // Get the inner exception if available
                    string innerMessage = ex.InnerException != null ? ex.InnerException.Message : "";

                    //return Json(new { success = false, message = "An error occurred: " + innerMessage });
                }
            }
            mainModel.SymbolicPoints.Clear();
            mainModel.SymbolicPoints = mainModel.GetSymbolicPoint();
            return View(mainModel);
        }

        public IActionResult Agv(Agvinfo formData)
        {
            MainModel mainModel = new MainModel(_db);
            if (formData.AgvName != null)
            {
                Agvinfo agvinfo = _db.Agvinfos.Where(k => k.AgvId == formData.AgvId).FirstOrDefault();
                if (agvinfo != null)
                {
                    if (formData.AgvName == "delete")
                    {
                        _db.Agvinfos.Remove(agvinfo);
                    }
                    else
                    {
                        agvinfo.AgvName = formData.AgvName;
                        agvinfo.AgvGroupName = formData.AgvGroupName;
                        agvinfo.AgvCode = formData.AgvCode;
                        agvinfo.AgvAvalibility = formData.AgvAvalibility;
                    }
                }
                else
                {
                    Agvinfo newAgv = new Agvinfo { AgvId = formData.AgvId, AgvName = formData.AgvName, AgvGroupName = formData.AgvGroupName, AgvCode = formData.AgvCode, AgvAvalibility = formData.AgvAvalibility };
                    _db.Agvinfos.Add(newAgv);
                }
                _db.SaveChanges();
            }
            mainModel.Agvinfos = mainModel.GetAgvinfos();
            return View(mainModel);
        }
    }
}
