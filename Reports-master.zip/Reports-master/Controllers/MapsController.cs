﻿using DocumentFormat.OpenXml.Bibliography;
using DocumentFormat.OpenXml.Drawing.Charts;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Logging;
using Reports.Db;
using Reports.Models;
using System.Drawing;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.Json.Serialization;

namespace Reports.Controllers
{
    public class Department
    {
        public int age { get; set; }
        public string name { get; set; }
        public string car { get; set; }
    }
    public class MapsController : Controller
    {
        public dbContext _db;
        public MapsController(dbContext db)
        {
            _db = db;
        }

        [HttpPost]
        public List<Polygon> deletePolygon(string polygonName)
        {
            List<Polygon> poligonsList = _db.Polygons.Where(k => k.PolygonName == polygonName).ToList();
            if (poligonsList.Count != 0)
                _db.Polygons.RemoveRange(poligonsList);

            _db.SaveChanges();
            return _db.Polygons.ToList();
        }

        [HttpPost]
        public List<Polygon> savePolygon(List<Polygon> formData)
        {
            List<Polygon> poligonsList = _db.Polygons.Where(k => k.PolygonTypeId == formData[0].PolygonTypeId && k.PolygonZoneId == formData[0].PolygonZoneId).ToList();
            if(poligonsList.Count != 0)
                _db.Polygons.RemoveRange(poligonsList);

            _db.Polygons.AddRange(formData);
            _db.SaveChanges();
            return _db.Polygons.ToList();
        }
        

        public IActionResult MapEdit()
        {
            MainModel mainModel = new MainModel(_db);
            mainModel.SymbolicPoints = mainModel.GetSymbolicPoint();
            mainModel.Polygons = mainModel.GetPolygons();
            mainModel.WayPoints = mainModel.GetWayPoint();
            mainModel.Stations = mainModel.GetStation();
            mainModel.Supermarkets = mainModel.GetSupermarket();
            return View(mainModel);
        }
        public List<ErrorMapSpecial> GetSpecificErrors(string theDay, int[] error_id_list)
        {
            List<ErrorMapSpecial> errorMapSpecials = new List<ErrorMapSpecial>();
            List<Error> allErrors = new List<Error>();
            if (theDay != null)
            {
                string[] days = theDay.Split("-");
                foreach (string day in days)
                {
                    DateTime subDt = Convert.ToDateTime(day);
                    List<Error> subErrors = _db.Errors.Where(k => k.TrackBeginTime.Day == subDt.Day && k.TrackBeginTime.Month == subDt.Month && k.TrackBeginTime.Year == subDt.Year && k.TrackEndTime.Day == subDt.Day && k.TrackEndTime.Month == subDt.Month && k.TrackEndTime.Year == subDt.Year).ToList();
                    allErrors.AddRange(subErrors);
                }
            }

            List<ErrorDefination> errorDefinations = _db.ErrorDefinations.ToList();

            foreach (Error item in allErrors)
            {
                if(error_id_list.Contains(item.ErrorId))
                {
                    ErrorMapSpecial errorMapSpecial = new ErrorMapSpecial();
                    if (errorDefinations.Any(k => k.ErrorId == item.ErrorId))
                    {
                        ErrorDefination temp = errorDefinations.FirstOrDefault(k => k.ErrorId == item.ErrorId);
                        if ((item.TrackEndTime - item.TrackBeginTime).TotalSeconds > temp.ErrorLogThreshold)
                        {
                            errorMapSpecial.ErrorId = item.ErrorId;
                            errorMapSpecial.MachineId = item.MachineId;
                            errorMapSpecial.ErrorString = temp.ErrorString;
                            errorMapSpecial.PosX = item.PosX;
                            errorMapSpecial.PosY = item.PosY;
                            errorMapSpecial.TrackBeginTime = item.TrackBeginTime;
                            errorMapSpecial.TrackEndTime = item.TrackEndTime;
                            errorMapSpecial.TrackDuration = (item.TrackEndTime - item.TrackBeginTime).TotalSeconds;
                            errorMapSpecial.ErrorColor = temp.ErrorColor.ToString("X6");
                            errorMapSpecials.Add(errorMapSpecial);
                        } 
                    } else
                    {
                        errorMapSpecial.ErrorId = item.ErrorId;
                        errorMapSpecial.MachineId = item.MachineId;
                        errorMapSpecial.ErrorString = "Unknown Error";
                        errorMapSpecial.PosX = item.PosX;
                        errorMapSpecial.PosY = item.PosY;
                        errorMapSpecial.TrackBeginTime = item.TrackBeginTime;
                        errorMapSpecial.TrackEndTime = item.TrackEndTime;
                        errorMapSpecial.TrackDuration = (item.TrackEndTime - item.TrackBeginTime).TotalSeconds;
                        errorMapSpecials.Add(errorMapSpecial);
                    }

                }
            }
            return errorMapSpecials;
        }

        public List<errorList> GetDayErrorMap(string theDay)
        {
            List<errorList> ErrorLists = new List<errorList>();
            List<ErrorMapSpecial> errorMapSpecials = new List<ErrorMapSpecial>();
            List<Error> allErrors = new List<Error>();
            if (theDay != null)
            {
                string[] days = theDay.Split("-");
                foreach (string day in days)
                {
                    DateTime subDt = Convert.ToDateTime(day);
                    List<Error> subErrors = _db.Errors.Where(k => k.TrackBeginTime.Day == subDt.Day && k.TrackBeginTime.Month == subDt.Month && k.TrackBeginTime.Year == subDt.Year && k.TrackEndTime.Day == subDt.Day && k.TrackEndTime.Month == subDt.Month && k.TrackEndTime.Year == subDt.Year).ToList();
                    allErrors.AddRange(subErrors);
                }
            }

            List<ErrorDefination> errorDefinations = _db.ErrorDefinations.ToList();

            foreach (Error item in allErrors)
            {
                if (errorDefinations.Any(k => k.ErrorId == item.ErrorId))
                {
                    ErrorDefination temp = errorDefinations.FirstOrDefault(k => k.ErrorId == item.ErrorId);
                    if((item.TrackEndTime - item.TrackBeginTime).TotalSeconds > temp.ErrorLogThreshold)
                    {
                        errorMapSpecials.Add(new ErrorMapSpecial
                        {
                            ErrorId = item.ErrorId,
                            ErrorString = temp.ErrorString,
                            PosX = item.PosX,
                            PosY = item.PosY,
                            TrackBeginTime = item.TrackBeginTime,
                            TrackEndTime = item.TrackEndTime,
                            TrackDuration = (item.TrackEndTime - item.TrackBeginTime).TotalSeconds,
                        });
                    }
                } else
                {
                    errorMapSpecials.Add(new ErrorMapSpecial
                    {
                        ErrorId = item.ErrorId,
                        ErrorString = "Açıklama Yok",
                        PosX = item.PosX,
                        PosY = item.PosY,
                        TrackBeginTime = item.TrackBeginTime,
                        TrackEndTime = item.TrackEndTime,
                        TrackDuration = (item.TrackEndTime - item.TrackBeginTime).TotalSeconds,
                    });
                }
            }

            foreach (ErrorMapSpecial item in errorMapSpecials)
            {
                if (ErrorLists.Any(k => k.ErrorId == item.ErrorId))
                {
                    errorList temp = ErrorLists.FirstOrDefault(k=> k.ErrorId == item.ErrorId);
                    temp.ErrorCount++;
                    temp.ErrorTotalDuration += item.TrackDuration;
                } else
                {
                    ErrorLists.Add(new errorList {
                        ErrorId = item.ErrorId,
                        ErrorString = item.ErrorString,
                        ErrorCount = 1,
                        ErrorTotalDuration = item.TrackDuration,
                    });
                }
            }

            return ErrorLists;

        }


        public IActionResult ErrorMap()
        {
            MapModel mapModel = new MapModel();
            mapModel.SymbolicPoints = _db.SymbolicPoints.ToList();
            mapModel.Polygons = _db.Polygons.ToList();
            mapModel.WayPoints = _db.WayPoints.ToList();



            return View(mapModel);

            //MainModel mainModel = new MainModel(_db);
            //mainModel.SymbolicPoints = mainModel.GetSymbolicPoint();
            //mainModel.Errors = mainModel.GetError();
            //mainModel.ErrorDefinations = mainModel.GetErrorDefinations();
            //return View(mainModel);
        }
    }
}
















//MapModel mapModel = new MapModel();
//List<Error> allErrors = new List<Error>();
//if (theDay != null)
//{
//    string[] days = theDay.Split("-");
//    foreach (string day in days)
//    {
//        DateTime subDt = Convert.ToDateTime(day);
//        List<Error> subErrors = _db.Errors.Where(k => k.TrackBeginTime.Day == subDt.Day && k.TrackBeginTime.Month == subDt.Month && k.TrackBeginTime.Year == subDt.Year && k.TrackEndTime.Day == subDt.Day && k.TrackEndTime.Month == subDt.Month && k.TrackEndTime.Year == subDt.Year).ToList();
//        allErrors.AddRange(subErrors);
//    }
//}
//List<ErrorDefination> errorDefinations = _db.ErrorDefinations.ToList();
//foreach (Error item in allErrors)
//{
//    ErrorMapSpecial subMapModel = new ErrorMapSpecial();
//    subMapModel.ErrorId = item.ErrorId;
//    subMapModel.PosX = item.PosX;
//    subMapModel.PosY = item.PosY;
//    subMapModel.MachineId = item.MachineId;
//    subMapModel.TrackBeginTime = item.TrackBeginTime;
//    subMapModel.TrackEndTime = item.TrackEndTime;
//    subMapModel.TrackDuration = (item.TrackEndTime - item.TrackBeginTime).TotalSeconds;

//    if (errorDefinations.Any(k => k.ErrorId == item.ErrorId))
//    {
//        ErrorDefination temp = errorDefinations.FirstOrDefault(k => k.ErrorId == item.ErrorId);
//        subMapModel.ErrorColor = temp.ErrorColor;
//    }
//    else
//        subMapModel.ErrorColor = 261322;


//    mapModel.errorMapSpecials.Add(subMapModel);

//    if (mapModel.errorList.Any(k => k.ErrorId == item.ErrorId))
//    {
//        errorList temp = mapModel.errorList.FirstOrDefault(k => k.ErrorId == item.ErrorId);
//        temp.ErrorCount++;
//        temp.ErrorTotalDuration += subMapModel.TrackDuration;
//    }
//    else
//    {
//        errorList temp = new errorList();
//        temp.ErrorId = item.ErrorId;
//        if (errorDefinations.Any(k => k.ErrorId == item.ErrorId))
//        {
//            ErrorDefination errorDefinationTemp = errorDefinations.FirstOrDefault(k => k.ErrorId == item.ErrorId);
//            temp.ErrorString = errorDefinationTemp.ErrorString;
//        }
//        else
//            temp.ErrorString = "Açıklama Yok";
//        temp.ErrorColor = subMapModel.ErrorColor;
//        temp.ErrorCount = 1;
//        temp.ErrorTotalDuration = subMapModel.TrackDuration;
//        mapModel.errorList.Add(temp);
//    }
//}



//mapModel.SymbolicPoints = _db.SymbolicPoints.ToList();
//return mapModel;