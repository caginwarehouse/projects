﻿using Microsoft.AspNetCore.Mvc;
using Reports.Models;
using Reports.Db;
using Microsoft.SqlServer.Server;

namespace Reports.Controllers
{
    public class FieldDefinations : Controller
    {
        public dbContext _db;
        public FieldDefinations(dbContext db)
        {
            _db = db;
        }
        public IActionResult Station(Station formData)
        {
            MainModel mainModel = new MainModel(_db);
            if (formData.StationName != null)
            {
                Station station = _db.Stations.Where(k => k.StationId == formData.StationId).FirstOrDefault();
                if (station != null)
                {
                    if (formData.StationName == "delete")
                    {
                        _db.Stations.Remove(station);
                    }
                    else
                    {
                        station.StationName = formData.StationName;
                        station.StationSymbolicPointId = formData.StationSymbolicPointId;
                        station.StationGroupName = formData.StationGroupName;
                        StationGroup stationGroup = _db.StationGroups.Where(k => k.StationGroupName == formData.StationGroupName).FirstOrDefault();
                        station.StationGroupId = stationGroup.StationGroupId;
                    }
                }
                else
                {
                    Station stationAdd = new Station
                    {
                        StationName = formData.StationName,
                        StationSymbolicPointId = formData.StationSymbolicPointId,
                        StationGroupName = formData.StationGroupName
                    };
                    StationGroup stationGroup = _db.StationGroups.Where(k => k.StationGroupName == formData.StationGroupName).FirstOrDefault();
                    stationAdd.StationGroupId = stationGroup.StationGroupId;
                    _db.Stations.Add(stationAdd);
                }
                _db.SaveChanges();
            }
            mainModel.Stations = mainModel.GetStation();
            mainModel.StationGroups = mainModel.GetStationGroup();
            return View(mainModel);
        }
        public IActionResult StationGroup(StationGroup formData)
        {
            MainModel mainModel = new MainModel(_db);
            if (formData.StationGroupName != null)
            {
                StationGroup stationgroup = _db.StationGroups.Where(k => k.StationGroupId == formData.StationGroupId).FirstOrDefault();
                if (stationgroup != null)
                {
                    if (formData.StationGroupName == "delete")
                    {
                        _db.StationGroups.Remove(stationgroup);
                    }
                    else
                    {
                        stationgroup.StationGroupName = formData.StationGroupName;
                        stationgroup.SupermarketId = formData.SupermarketId;
                    }
                }
                else
                {
                    StationGroup stationgroupAdd = new StationGroup { StationGroupName = formData.StationGroupName, SupermarketId = formData.SupermarketId};
                    _db.StationGroups.Add(stationgroupAdd);
                }
                _db.SaveChanges();
            }
            mainModel.StationGroups = mainModel.GetStationGroup();
            mainModel.Supermarkets = mainModel.GetSupermarket();
            return View(mainModel);
        }
        public IActionResult Supermarket(Supermarket formData)
        {
            MainModel mainModel = new MainModel(_db);
            if (formData.SupermarketName != null)
            {
                Supermarket supermarket = _db.Supermarkets.Where(k => k.SupermarketId == formData.SupermarketId).FirstOrDefault();
                if (supermarket != null)
                {
                    if (formData.SupermarketName == "delete")
                    {
                        _db.Supermarkets.Remove(supermarket);
                    }
                    else
                    {
                        supermarket.SupermarketName = formData.SupermarketName;
                        supermarket.SupermarketSymbolicPoint = formData.SupermarketSymbolicPoint;
                        supermarket.SupermarketSymbolicPrePoint = formData.SupermarketSymbolicPrePoint;
                    }
                }
                else
                {
                    Supermarket supermarketAdd = new Supermarket { SupermarketName = formData.SupermarketName, SupermarketSymbolicPoint = formData.SupermarketSymbolicPoint, SupermarketSymbolicPrePoint = formData.SupermarketSymbolicPrePoint };
                    _db.Supermarkets.Add(supermarketAdd);
                }
                _db.SaveChanges();
            }
            mainModel.Supermarkets = mainModel.GetSupermarket();
            return View(mainModel);
        }
    }
}
