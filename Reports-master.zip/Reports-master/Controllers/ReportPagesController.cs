﻿using Microsoft.AspNetCore.Mvc;
using Reports.Db;
using Reports.Models;
using System.Data;
using ClosedXML.Excel;
using static System.Collections.Specialized.BitVector32;

namespace Reports.Controllers
{
    public class ReportPagesController : Controller
    {

        public dbContext _db;
        public ReportPagesController(dbContext db)
        {
            _db = db;
        }

        [Serializable]
        public class CycleTimeReport
        {
            public List<string> Dates { get; set; } = new List<string>();
            public List<string> Agv_Types { get; set; } = new List<string>();
            public List<string> Agv_Speeds { get; set; } = new List<string>();
            public List<string> Station_Types { get; set; } = new List<string>();
            public List<string> Station_Group_Types { get; set; } = new List<string>();
            public List<string> Station_Times { get; set; } = new List<string>();
        }

        //public FileResult Export(string theDay)
        //{

        //    //DateTime dt;
        //    //List<string> theDayList = new List<string>();
        //    //theDayList.AddRange(theDay.Split(','));
        //    //MainModel datab = new MainModel(_db);
        //    //datab.Deliveries = datab.GetDeliveries();
        //    //if (theDayList == null)
        //    //    dt = DateTime.Today.AddDays(0);

        //    //string contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        //    //string fileName = "AgvReport.xlsx";

        //    //using (var workbook = new XLWorkbook())
        //    //{
        //    //    IXLWorksheet worksheet = workbook.Worksheets.Add("Deliveries");

        //    //    worksheet.ColumnWidth = 12;

        //    //    var dataTable = new DataTable();
        //    //    dataTable.Columns.Add("Id", typeof(string));
        //    //    dataTable.Columns.Add("MachineId", typeof(string));
        //    //    dataTable.Columns.Add("SuperMarketId", typeof(string));
        //    //    dataTable.Columns.Add("TargetId", typeof(string));
        //    //    dataTable.Columns.Add("TakePointId", typeof(string));

        //    //    worksheet.Column(6).Width = 18;
        //    //    worksheet.Column(7).Width = 18;
        //    //    worksheet.Column(8).Width = 18;
        //    //    worksheet.Column(9).Width = 18;
        //    //    worksheet.Column(10).Width = 18;
        //    //    worksheet.Column(11).Width = 18;
        //    //    worksheet.Column(12).Width = 18;
        //    //    worksheet.Column(13).Width = 18;

        //    //    dataTable.Columns.Add("RequestTime", typeof(string));
        //    //    dataTable.Columns.Add("ResponseTime", typeof(string));
        //    //    dataTable.Columns.Add("PreReleaseTime", typeof(string));
        //    //    dataTable.Columns.Add("DropTime", typeof(string));
        //    //    dataTable.Columns.Add("ToMarketTime", typeof(string));
        //    //    dataTable.Columns.Add("AtSuperMarketTime", typeof(string));
        //    //    dataTable.Columns.Add("AtPoleTime", typeof(string));
        //    //    dataTable.Columns.Add("AverageCycleTime", typeof(string));

        //    //    foreach (string itemDate in theDayList)
        //    //    {
        //    //        dt = Convert.ToDateTime(itemDate);
        //    //        List<Delivery> model = datab.Deliveries.Where(k => k.RequestTime.Day == dt.Day && k.RequestTime.Month == dt.Month && k.RequestTime.Year == dt.Year).ToList();
        //    //        foreach (Delivery item in model)
        //    //        {
        //    //            dataTable.Rows.Add(item.DeliveryId, item.MachineId, item.SupermarketId, item.DeliveredTargetId, item.TakePointId, item.RequestTime, item.ResponseTime, item.PrereleasePointTime, item.DropTime, item.ToMarketTime, item.AtSupermarketTime, item.AtPoleTime, item.AvgCycleSpeed);
        //    //        }
        //    //    }

        //    //    worksheet.Cell("A2").InsertTable(dataTable);

        //    //    using (var stream = new MemoryStream())
        //    //    {
        //    //        workbook.SaveAs(stream);
        //    //        byte[] content = stream.ToArray();
        //    //        return File(content, "application/octet-stream", fileName);
        //    //    }

        //    //}
        //    return;
        //}

        public CycleTimeReport getToday()
        {
            CycleTimeReport cycleTimeReport = new CycleTimeReport();
            //cycleTimeReport = GetCycleTimeReport(DateTime.Today.AddDays(-1).ToString());
            return cycleTimeReport;
        }

        public CycleTimeReport getRange(string fromDay, string toDay)
        {
            CycleTimeReport cycleTimeReport = new CycleTimeReport();

            //DateTime one_Date = Convert.ToDateTime(fromDay);
            //DateTime two_Date = Convert.ToDateTime(toDay);

            //string rangeDays = new string("");

            //int difference = DateTime.Compare(one_Date, two_Date);
            //if (difference > 0)
            //{
            //    for (DateTime i = two_Date; i <= one_Date; i = i.AddDays(1))
            //    {
            //        string subDay = String.Format("{0}.{1}.{2}", i.Day.ToString(), i.Month.ToString(), i.Year.ToString());
            //        if (i == one_Date)
            //            rangeDays += subDay;
            //        else
            //            rangeDays += subDay + "-";
            //    }
            //}
            //else
            //{
            //    for (DateTime i = one_Date; i <= two_Date; i = i.AddDays(1))
            //    {
            //        string subDay = String.Format("{0}.{1}.{2}", i.Day.ToString(), i.Month.ToString(), i.Year.ToString());
            //        if (i == two_Date)
            //            rangeDays += subDay;
            //        else
            //            rangeDays += subDay + "-";
            //    }
            //}
            //cycleTimeReport = GetCycleTimeReport(rangeDays);
            return cycleTimeReport;
        }

        public CycleTimeReport getMonth()
        {
            CycleTimeReport cycleTimeReport = new CycleTimeReport();
            //string DaysofMonth = new string("");
            //for (int i = 1; i <= DateTime.DaysInMonth(DateTime.Today.AddDays(-1).Year, DateTime.Today.AddDays(-1).Month); i++)
            //{
            //    string subDay = String.Format("{0}.{1}.{2}", i, DateTime.Today.AddDays(-1).Month, DateTime.Today.AddDays(-1).Year);
            //    if (i == DateTime.DaysInMonth(DateTime.Today.AddDays(-1).Year, DateTime.Today.AddDays(-1).Month))
            //        DaysofMonth += subDay;
            //    else
            //        DaysofMonth += subDay + "-";
            //}
            //cycleTimeReport = GetCycleTimeReport(DaysofMonth);

            return cycleTimeReport;
        }

        public CycleTimeReport GetCycleTimeReport(string theDay)
        {
            CycleTimeReport cycleTimeReport = new CycleTimeReport();

            //List<DateTime> dtList = new List<DateTime>();
            //List<int> dayList = new List<int>();
            //List<Delivery> deliveryData = new List<Delivery>();
            //double StationSumSpeed = 0.0;
            //uint StationSpeedTick = 0;

            //string[] days = theDay.Split("-");
            //foreach (string day in days)
            //{
            //    DateTime subDt = Convert.ToDateTime(day);
            //    cycleTimeReport.Dates.Add(subDt.Date.ToString("dd.MM.yyyy"));
            //    dtList.Add(subDt);
            //    List<Delivery> subDeliveryData = _db.Deliveries.Where(k => k.RequestTime.Day == subDt.Day && k.RequestTime.Month == subDt.Month && k.RequestTime.Year == subDt.Year).ToList();
            //    foreach (Delivery item in subDeliveryData)
            //        if (item.AtPoleTime.HasValue)
            //            if (item.AtPoleTime.Value.Day != subDt.Day && item.AtPoleTime.Value.Month != subDt.Month && item.AtPoleTime.Value.Year != subDt.Year)
            //                subDeliveryData.Remove(item);

            //    deliveryData.AddRange(subDeliveryData);
            //}

            //List<int> StationsFromDeliveryData = new List<int>();
            //if (deliveryData.Count > 0)
            //    foreach (Delivery item in deliveryData)
            //        if (!StationsFromDeliveryData.Contains((int)item.DeliveredTargetId))
            //            StationsFromDeliveryData.Add((int)item.DeliveredTargetId);

            //if (deliveryData.Count > 0)
            //{
            //    foreach (int item in StationsFromDeliveryData)
            //    {
            //        StationSumSpeed = 0.0;
            //        StationSpeedTick = 0;
            //        Station stationData = _db.Stations.Where(k => k.StationSymbolicPointId == item).FirstOrDefault();
            //        if (stationData != null)
            //        {
            //            string stationStr = stationData.StationName + " (" + stationData.StationSymbolicPointId + ")";
            //            cycleTimeReport.Station_Types.Add(stationStr);
            //            cycleTimeReport.Station_Group_Types.Add(stationData.StationGroupName);
            //        }
            //        List<Delivery> deliveryDataJustForOneId = deliveryData.FindAll(k => k.DeliveredTargetId == item).ToList();
            //        TimeSpan? ts;
            //        foreach (Delivery itemDeliveriesForOneId in deliveryDataJustForOneId)
            //        {
            //            if (itemDeliveriesForOneId.AtSupermarketTime != null)
            //            {
            //                ts = itemDeliveriesForOneId.AtSupermarketTime - itemDeliveriesForOneId.RequestTime;
            //                StationSumSpeed += ts.Value.TotalMinutes;
            //                StationSpeedTick++;
            //            }
            //        }
            //        cycleTimeReport.Station_Times.Add(Math.Round(StationSumSpeed / StationSpeedTick, 2).ToString());
            //    }
            //}

            //double agvSumSpeed = 0.00;
            //int agvSpeedTick = 0;
            //List<Agvgroup> agvGroupList = _db.Agvgroups.ToList();
            //foreach (Agvgroup item in agvGroupList)
            //{
            //    agvSumSpeed = 0.00;
            //    agvSpeedTick = 0;
            //    cycleTimeReport.Agv_Types.Add(item.AgvGroupName);
            //    List<Agvinfo> agvInfos = _db.Agvinfos.Where(k => k.AgvGroupName == item.AgvGroupName).ToList();
            //    foreach (Agvinfo itemAgv in agvInfos)
            //    {
            //        List<Delivery> deliveryInfo = deliveryData.FindAll(k => k.MachineId == itemAgv.AgvId).ToList();
            //        foreach (Delivery delivery in deliveryInfo)
            //        {
            //            agvSumSpeed += (double)delivery.AvgCycleSpeed;
            //            agvSpeedTick++;
            //        }
            //    }
            //    cycleTimeReport.Agv_Speeds.Add(Math.Round(agvSumSpeed / agvSpeedTick, 2).ToString());
            //}

            return cycleTimeReport;
        }

        [HttpGet]
        public IActionResult CycleTimeReportFunc()
        {
            CycleTimeModel cycleTimeModel = new CycleTimeModel();

            //CycleTimeReport cycleReportModelDay = new CycleTimeReport();
            //cycleReportModelDay = GetCycleTimeReport(DateTime.Today.AddDays(-1).ToString());
            //cycleTimeModel.first_dates = cycleReportModelDay.Dates;
            //cycleTimeModel.Agv_Types = cycleReportModelDay.Agv_Types;
            //cycleTimeModel.first_Agv_Speeds = cycleReportModelDay.Agv_Speeds;
            //cycleTimeModel.first_Station_Types = cycleReportModelDay.Station_Types;
            //cycleTimeModel.first_Station_Group_Types = cycleReportModelDay.Station_Group_Types;
            //cycleTimeModel.first_Station_Times = cycleReportModelDay.Station_Times;

            //string DaysofMonth = new string("");
            //for (int i = 1; i <= DateTime.DaysInMonth(DateTime.Today.AddDays(-1).Year, DateTime.Today.AddDays(-1).Month); i++)
            //{
            //    string subDay = String.Format("{0}.{1}.{2}", i, DateTime.Today.AddDays(-1).Month, DateTime.Today.AddDays(-1).Year);
            //    if (i == DateTime.DaysInMonth(DateTime.Today.AddDays(-1).Year, DateTime.Today.AddDays(-1).Month))
            //        DaysofMonth += subDay;
            //    else
            //        DaysofMonth += subDay + "-";
            //}

            //CycleTimeReport cycleReportModelMonth = new CycleTimeReport();
            //cycleReportModelMonth = GetCycleTimeReport(DaysofMonth);
            //cycleTimeModel.second_dates = cycleReportModelMonth.Dates;
            //cycleTimeModel.second_Agv_Speeds = cycleReportModelMonth.Agv_Speeds;
            //cycleTimeModel.second_Station_Types = cycleReportModelMonth.Station_Types;
            //cycleTimeModel.second_Station_Group_Types = cycleReportModelMonth.Station_Group_Types;
            //cycleTimeModel.second_Station_Times = cycleReportModelMonth.Station_Times;

            return View(cycleTimeModel);
        }

        static bool PointInsidePolygon((double x, double y) point, List<(double x, double y)> polygon)
        {
            double x = point.x, y = point.y;
            int n = polygon.Count;
            bool inside = false;

            double p1x = polygon[0].x, p1y = polygon[0].y;
            for (int i = 0; i < n + 1; i++)
            {
                double p2x = polygon[i % n].x, p2y = polygon[i % n].y;
                if (y > Math.Min(p1y, p2y))
                {
                    if (y <= Math.Max(p1y, p2y))
                    {
                        if (x <= Math.Max(p1x, p2x))
                        {
                            if (p1y != p2y)
                            {
                                double xIntersect = (y - p1y) * (p2x - p1x) / (p2y - p1y) + p1x;
                                if (p1x == p2x || x <= xIntersect)
                                {
                                    inside = !inside;
                                }
                            }
                        }
                    }
                }
                p1x = p2x;
                p1y = p2y;
            }

            return inside;
        }

        public IActionResult SupermarketReport()
        {
            SupermarketModel supermarketModel = new SupermarketModel();
            List<Supermarket> supermarkets = new List<Supermarket>();

            List<Polygon> polygons = new List<Polygon>();
            polygons = _db.Polygons.Where(k => k.PolygonTypeId == 2).ToList();
            List<(double, double)> polygonBorders = new List<(double, double)>();
            foreach (var PolygonCounter in polygons.GroupBy(k => k.PolygonName))
            {

            }
            return View();
        }


        public IActionResult StationReport()
        {
            StationReportModel stationReportModel = new StationReportModel();

            stationReportModel.definations = _db.ErrorDefinations.ToList();
            stationReportModel.stationGroups = _db.StationGroups.ToList();
            stationReportModel.Stations = _db.Stations.ToList();

            Dictionary<string, List<Error>> errorsInZones = new Dictionary<string, List<Error>>();

            DateTime dt = DateTime.Today.AddDays(-1);
            List<Error> errorData = new List<Error>();
            //errorData = _db.Errors.Where(k => k.TrackBeginTime.Day == dt.Day && k.TrackBeginTime.Month == dt.Month && k.TrackBeginTime.Year == dt.Year).ToList();
            errorData = _db.Errors.ToList();
            List<Polygon> polygons = new List<Polygon>();
            polygons = _db.Polygons.Where(k => k.PolygonTypeId == 1).ToList();
            List<(double, double)> polygonBorders = new List<(double, double)>();
            foreach (var PolygonCounter in polygons.GroupBy(k=> k.PolygonName))
            {
                polygonBorders.Clear();
                foreach (var item in PolygonCounter)
                {
                    double pointX = Convert.ToDouble(item.PolygonPointX.ToString().Replace(".",","));
                    double pointY = Convert.ToDouble(item.PolygonPointY.ToString().Replace(".", ","));
                    polygonBorders.Add((pointY, pointX));
                }

                List<Error> tempErrorList = new List<Error>();
                foreach (var errorItem in errorData)
                {
                    bool ret = PointInsidePolygon((errorItem.PosX,  errorItem.PosY), polygonBorders);
                    if (ret)
                        tempErrorList.Add(errorItem);
                }
                errorsInZones.Add(PolygonCounter.Key, tempErrorList);
            }

            foreach (KeyValuePair<string, List<Error>> item in errorsInZones)
            {
                List<errorDetail> errorDetails = new List<errorDetail>();
                foreach (Error item2 in item.Value)
                {
                    var match = errorDetails.FirstOrDefault(k => k.ErrorId == item2.ErrorId);

                    if (match != null)
                    {
                        match.ErrorDuration += (item2.TrackEndTime - item2.TrackBeginTime).TotalSeconds;
                        match.ErrorCount++;
                    } else
                    {
                        errorDetail tempErrorDetail = new errorDetail();
                        tempErrorDetail.ErrorId = item2.ErrorId;
                        tempErrorDetail.ErrorCount = 1;
                        tempErrorDetail.ErrorDuration = (item2.TrackEndTime - item2.TrackBeginTime).TotalSeconds;

                        var tempErrorDefination = stationReportModel.definations.FirstOrDefault(k => k.ErrorId == item2.ErrorId);
                        if (tempErrorDefination != null)
                        {
                            tempErrorDetail.ErrorMessage = tempErrorDefination.ErrorString;
                            tempErrorDetail.ErrorGroup = tempErrorDefination.ErrorGroup;
                        }
                        else
                        {
                            tempErrorDetail.ErrorMessage = "Not_Shortlisted";
                            tempErrorDetail.ErrorGroup = "Not_Grouped";
                        }
                        errorDetails.Add(tempErrorDetail);
                    }
                }
                stationReportModel.errorsInZones.Add(item.Key, errorDetails);
            }


            return View(stationReportModel);
        }
    }
}
