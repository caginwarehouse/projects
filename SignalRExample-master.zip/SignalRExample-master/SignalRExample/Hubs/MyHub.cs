﻿using System;
using Microsoft.AspNetCore.SignalR;

namespace SignalRExample.Hubs
{

    public class MyHub : Hub
    {
        public async Task SendMessage(double posX, double posY) //message client dan gelene mesaj
        {
            await Clients.All.SendAsync("ReceiveMessage", posX, posY);
        }
    }
}
