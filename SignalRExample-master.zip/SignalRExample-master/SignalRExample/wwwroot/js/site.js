﻿"use strict";

let bounds = [
    [0, 0], // padding
    [60, 125], // image dimensions
];

let map = L.map("map", {
    crs: L.CRS.Simple,
    maxZoom: 5,
    minZoom: 3,
    maxBounds: bounds,
});


// method fitBounds sets a map view
// that contains the given geographical bounds with the
// maximum zoom level possible.
map.fitBounds(bounds);

const popupOptions = {
    // className: "test",
    // closeButton: false
};

for (let x in symbolicPoints) {
    for (let item in symbolicPoints[x]) {
        console.log(symbolicPoints[x][item])
        L.circle([(symbolicPoints[x][1] - 30), (symbolicPoints[x][0] - 90)], { radius: 0.05 }).addTo(map).bindPopup(String(symbolicPoints[x][2]), popupOptions);
    }
}



const connection = new signalR.HubConnectionBuilder()
    .withUrl("/myhub")
    .configureLogging(signalR.LogLevel.Information)
    .build();

async function start() {
    try {
        await connection.start();
        console.log("SignalR Connected.");

        connection.on("ReceiveMessage", function (posX, posY) {
            if (posX > 0) {
                L.circle([posY - 30, posX-90], 0.5, { color: 'red', fillColor: '#f03', fillOpacity: 1 }).addTo(map);
                console.log("X->", posX)
                console.log("Y->", posY)

            }
        });

    } catch (err) {
        console.log(err);
        setTimeout(start, 5000);
    }
};

connection.onclose(async () => {
    //await start();
});

// Start the connection.
start();



//connection.start().then(function () {
//    document.getElementById("sendButton").disabled = false;
//}).catch(function (err) {
//    return console.error(err.toString());
//});

//document.getElementById("sendButton").addEventListener("click", function (event) {
//    var user = document.getElementById("userInput").value;
//    var message = document.getElementById("messageInput").value;
//    connection.invoke("SendMessage", user, message).catch(function (err) {
//        return console.error(err.toString());
//    });
//    event.preventDefault();
//});