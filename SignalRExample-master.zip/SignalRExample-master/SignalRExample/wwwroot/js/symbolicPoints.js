
var symbolicPoints = {
    point: [119, 36.8, "112"],
    point1: [121.49, 36.8, "115"],
}


// localStorage.setItem(key, 2);

// // get key
// console.log( localStorage.test ); // 2

// remove key
// delete localStorage.test;

// localStorage.setItem(test, 5);
// console.log(localStorage.getItem(test, 5)); 