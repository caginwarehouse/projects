﻿using Microsoft.AspNet.SignalR.Messaging;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Logging;
using SignalRExample;
using SignalRExample.Hubs;
using System.Net.Sockets;

namespace SignalRExample
{
   
   

    public class BackgroundUpdater : IHostedService
    {
        private readonly ILogger<BackgroundUpdater> logger;
        private readonly IHubContext<MyHub> _hubContext;

        private TcpClient client = new TcpClient();
        public BackgroundUpdater(ILogger<BackgroundUpdater> logger, IHubContext<MyHub> hubContext)
        {
            this.logger = logger;
            this._hubContext = hubContext;
        }

        public Task StartAsync(CancellationToken cancellationToken)
        {
            Task.Run(async () =>
            {
                while (!cancellationToken.IsCancellationRequested)
                {
                    
                    await Task.Delay(new TimeSpan(0, 0, 5)); // 5 second delay


                    
                    logger.LogInformation("Connecting....");
                    client.Connect("10.114.0.47", 8015); // BOLU
                    logger.LogInformation("Connected!");
                    client.ReceiveBufferSize = 1048576;
                    NetworkStream stream = client.GetStream();

                    //ProductionStatus productionStatus = new ProductionStatus();
                    //ErrorMsgs errorMsgs = new ErrorMsgs();

                    int buffer_pointer = 0;
                    int read_count = 0;
                    int available_amount = 0;
                    int message_id = 0;
                    int remainBufferPointer = 0;
                    int message_length = 0;

                    //0-> X
                    //1-> Y
                    //2-> H
                    //string position_heading_state;

                    byte[] receiveBuffer = new byte[client.ReceiveBufferSize];
                    byte[] remainReceiveBuffer = new byte[client.ReceiveBufferSize];
                    while (!cancellationToken.IsCancellationRequested)
                    {
                        while (client.Available < 300)
                        {
                            System.Threading.Thread.Sleep(1000);
                        }
                        available_amount = client.Available;
                        //Console.WriteLine("Readed {0:D} Bytes.", available_amount);
                        read_count = stream.Read(receiveBuffer, 0, available_amount);
                        buffer_pointer = 0;
                        if (remainBufferPointer > 0)
                        {
                            // add receiveBuffer to end of the remainReceiveBuffer 
                            Buffer.BlockCopy(receiveBuffer, 0, remainReceiveBuffer, remainBufferPointer, read_count);
                            // move all data from remainReceiveBuffer to receiveBuffer
                            Buffer.BlockCopy(remainReceiveBuffer, 0, receiveBuffer, 0, read_count + remainBufferPointer);
                            // clear remain buffer pointer
                            read_count += remainBufferPointer;
                            remainBufferPointer = 0;
                        }

                        // Chunk process
                        while ((read_count - buffer_pointer) > 0)
                        {
                            if ((read_count - buffer_pointer) < 9) // check frame existence
                            {
                                remainBufferPointer = (read_count - buffer_pointer);
                                Buffer.BlockCopy(receiveBuffer, buffer_pointer, remainReceiveBuffer, 0, remainBufferPointer);
                                buffer_pointer = read_count;
                                break;
                            }

                            if (BitConverter.ToUInt16(receiveBuffer, buffer_pointer + 7) > (read_count - buffer_pointer - 9)) //message exist check
                            {
                                remainBufferPointer = (read_count - buffer_pointer);
                                Buffer.BlockCopy(receiveBuffer, buffer_pointer, remainReceiveBuffer, 0, remainBufferPointer);
                                buffer_pointer = read_count;
                                break;
                            }
                            message_id = BitConverter.ToUInt16(receiveBuffer, buffer_pointer);

                            message_length = (BitConverter.ToUInt16(receiveBuffer, buffer_pointer + 7)); //take message length before pass frame
                            buffer_pointer += 9; // PASS FRAME


                            //MESSAGE PARSING SECTION
                            switch (message_id)
                            {
                                case 310:
                                    //logger.LogInformation("Passed {0:D} Message!", message_id);
                                    //position_heading_state = BitConverter.ToDouble(receiveBuffer, buffer_pointer + 2);
                                    //position_heading_state[1] = BitConverter.ToDouble(receiveBuffer, buffer_pointer + 10);
                                    //position_heading_state[2] = BitConverter.ToDouble(receiveBuffer, buffer_pointer + 18);
                                    await _hubContext.Clients.All.SendAsync("ReceiveMessage", BitConverter.ToDouble(receiveBuffer, buffer_pointer + 2), BitConverter.ToDouble(receiveBuffer, buffer_pointer + 10));

                                    break;
                                case 309:
                                    //logger.LogInformation("Passed {0:D} Message!", message_id);
                                    //Task_309(receiveBuffer, buffer_pointer, ref errorMsgs);
                                    break;
                                case 313:
                                    //logger.LogInformation("Passed {0:D} Message!", message_id);
                                    //Task_313(receiveBuffer, buffer_pointer, ref productionStatus, ref tracking_agvs);
                                    break;
                                default:
                                    //logger.LogInformation("Passed {0:D} Message!", message_id);
                                    continue;
                            }


                            buffer_pointer += message_length; // pass to other message
                        }
                    }
                    














                }
            }
            );
            //throw new NotImplementedException();
            
            return Task.CompletedTask;
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            client.Close();
            //throw new NotImplementedException();
            return Task.CompletedTask;
        }
    }
}
