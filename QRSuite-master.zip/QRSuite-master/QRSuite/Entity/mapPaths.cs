﻿using System.ComponentModel.DataAnnotations;

namespace QRSuite.Entity
{
    public class mapPaths
    {
        [Key]
        public int PathDbId { get; set; }
        public int PathFromId { get; set; }
        public double PathFromX { get; set; }
        public double PathFromY { get; set; }
        public int PathToId { get; set; }
        public double PathToX { get; set; }
        public double PathToY { get; set; }
        public double PathVelocity { get; set; }
    }
}
