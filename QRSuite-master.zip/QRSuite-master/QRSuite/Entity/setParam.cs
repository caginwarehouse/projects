﻿using System.ComponentModel.DataAnnotations;

namespace QRSuite.Entity
{
    public class setParam
    {
        [Key]
        public int paramId { get; set; }
        public string paramName { get; set; } = string.Empty;
        public string ValueString { get; set; } = string.Empty;
    }
}
