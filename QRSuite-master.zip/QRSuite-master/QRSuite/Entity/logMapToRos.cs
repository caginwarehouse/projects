﻿using System.ComponentModel.DataAnnotations;

namespace QRSuite.Entity
{
    public class logMapToRos
    {
        [Key]
        public int MtRId { get; set; }
        public int MtRAgvId { get; set; }
        public string MtRAgvName { get; set; } = string.Empty;
        public string MtRAgvIp { get; set; } = string.Empty;
        public int MtRMapId { get; set; }
        public string MtRMapName { get; set; } = string.Empty;
        public DateTime MtRTimestamp { get; set; }
    }
}
