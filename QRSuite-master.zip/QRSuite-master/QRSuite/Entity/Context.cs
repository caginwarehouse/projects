﻿using Microsoft.EntityFrameworkCore;

namespace QRSuite.Entity
{
    
    public class Context : DbContext
    {
        public Context(DbContextOptions options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<setParam>().HasData(
                new setParam
                {
                    paramId = 1,
                    paramName = "ForwardSpeed",
                    ValueString = "0.5",
                },
                new setParam
                {
                    paramId = 2,
                    paramName = "BackwardSpeed",
                    ValueString = "0.5",
                },
                new setParam
                {
                    paramId = 3,
                    paramName = "TurnLeftSpeed",
                    ValueString = "0.3",
                },
                new setParam
                {
                    paramId = 4,
                    paramName = "TurnRightSpeed",
                    ValueString = "0.3",
                },
                new setParam
                {
                    paramId = 5,
                    paramName = "PivotTolerance",
                    ValueString = "5",
                },
                new setParam
                {
                    paramId = 6,
                    paramName = "XPositioningTolarance",
                    ValueString = "30",
                },
                new setParam
                {
                    paramId = 7,
                    paramName = "YPositioningTolarance",
                    ValueString = "30",
                }
            );
        }

        //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        //{
        //    optionsBuilder.UseSqlServer("Server=.;Database=MyDatabase;Trusted_Connection=True;Encrypt=False;");
        //}

        public DbSet<agvInfo> agvInfo { get; set; }
        public DbSet<mdsLines> mdsLines { get; set; }
        public virtual DbSet<mdsMaterial> mdsMaterial { get; set; }
        public DbSet<mdsRequest> mdsRequest { get; set; }
        public DbSet<mdsStation> mdsStation { get; set; }
        public DbSet<mdsSupermarket> mdsSupermarket { get; set; }
        public DbSet<mapInfo> mapInfo { get; set; }
        public DbSet<mapPoints> mapPoints { get; set; }
        public DbSet<mapPaths> mapPaths { get; set; }
        public DbSet<setMail> setMail { get; set; }
        public DbSet<logOrderToRos> logOrderToRos { get; set; }
        public DbSet<logMapToRos> logMapToRos { get; set; }
        public DbSet<agvCharge> agvCharge { get; set; }
        public DbSet<setParam> setParams { get; set; }
        public DbSet<liveOrders> liveOrders { get; set; }
    }

}
