﻿using System.ComponentModel.DataAnnotations;

namespace QRSuite.Entity
{
    public class mdsStation
    {
        [Key]
        public int StationId { get; set; }
        public string StationName { get; set; } = string.Empty;
        public int StationIdPoint { get; set; }
        public int StationLineId { get; set; }
        public string StationLineName { get; set; } = string.Empty;
    }
}
