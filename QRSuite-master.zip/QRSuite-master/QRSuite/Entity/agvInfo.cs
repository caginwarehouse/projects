﻿using System.ComponentModel.DataAnnotations;

namespace QRSuite.Entity
{
    public class agvInfo
    {
        [Key]
        public int AgvDbId { get; set; }
        public int AgvId { get; set; }
        public string AgvName { get; set; } = string.Empty;
        public string AgvIP { get; set; } = string.Empty;
        public int AgvTier { get; set; }
    }
}
