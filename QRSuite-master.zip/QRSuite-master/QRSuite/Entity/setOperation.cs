﻿using System.ComponentModel.DataAnnotations;

namespace QRSuite.Entity
{
    public class setOperation
    {
        [Key]
        public int OpId { get; set; }
        public string OpCommand { get; set; } = string.Empty;
        public bool OpNextPoint { get; set; } = false;
        public bool OpAngle { get; set; } = false;
        public bool OpDistance { get; set; } = false;
        public bool OpValue { get; set; } = false;
        public bool OpVelocity { get; set; } = false;
    }
}
