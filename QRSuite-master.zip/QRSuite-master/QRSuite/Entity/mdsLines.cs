﻿using System.ComponentModel.DataAnnotations;

namespace QRSuite.Entity
{
    public class mdsLines
    {
        [Key]
        public int station_group_id { get; set; }
        public string station_group_name { get; set; } = String.Empty;
        public int supermarket_id { get; set; }
    }
}
