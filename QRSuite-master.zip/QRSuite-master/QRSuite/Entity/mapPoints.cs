﻿using System.ComponentModel.DataAnnotations;

namespace QRSuite.Entity
{
    public class mapPoints
    {
        [Key]
        public int PointDbId { get; set; }
        public int PointId { get; set; }
        public double PointX { get; set; }
        public double PointY { get; set; }
        public int PointRelease { get; set; }
        public int PointCosAngleOffset { get; set; }
        public int PointACosAngleOffset { get; set; }
        public int PointSinAngleOffset { get; set; }
        public int PointASinAngleOffset { get; set; }
        public string PointOperation { get; set; } = string.Empty;
        public string PointSafetyMode { get; set; } = string.Empty;
    }
}
