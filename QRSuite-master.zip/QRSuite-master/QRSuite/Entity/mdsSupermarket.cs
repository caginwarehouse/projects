﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace QRSuite.Entity
{
    public class mdsSupermarket
    {
        [Key]
        public int SupermarketId { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string SupermarketName { get; set; } = string.Empty;
        public int SupermarketNamePoint { get; set; }
    }
}
