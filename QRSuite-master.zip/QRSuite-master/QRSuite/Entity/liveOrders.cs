﻿using System.ComponentModel.DataAnnotations;

namespace QRSuite.Entity
{
    public class liveOrders
    {
        [Key]
        public int livePoId { get; set; }
        public int livePoThreatId { get; set; }
        public int PoDepartureQrId { get; set; }
        public int PoDestinationQrId { get; set; }
        public string PoOrderSource { get; set; } = string.Empty;
        public int PoOrderCount { get; set; }
        public bool PoHasLoop { get; set; }
        public int PoAgvId { get; set; }
        public string PoAgvName { get; set; } = string.Empty;
        public string PoAgvIP { get; set; } = string.Empty;
        public DateTime PoBeginTimestamp { get; set; }
    }
}
