﻿using System.ComponentModel.DataAnnotations;

namespace QRSuite.Entity
{
    public class mdsMaterial
    {
        [Key]
        public int MaterialId { get; set; } = 0;
        public string MaterialName { get; set; } = string.Empty;
        public int MaterialSupermarketId { get; set; } = 0;
        public string MaterialSupermarketName { get; set; } = string.Empty;
        public int MaterialLineId { get; set; } = 0;
        public string MaterialLineName { get; set; } = string.Empty;
        public int MaterialStationId { get; set; } = 0;
        public string MaterialStationName { get; set; } = string.Empty;
    }
}
