﻿using System.ComponentModel.DataAnnotations;

namespace QRSuite.Entity
{
    public class agvCharge
    {
        [Key]
        public int DbId { get; set; }
        public int Id { get; set; }
        public int QRPointId { get; set; }
        public int QRPointPreId { get; set; }
    }
}
