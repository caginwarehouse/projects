﻿using System.ComponentModel.DataAnnotations;

namespace QRSuite.Entity
{
    public class setMultiOperation
    {
        [Key]
        public int MoPId { get; set; }
        public int MoPSetId { get; set; }
        public string MoPSetName { get; set; } = string.Empty;
        public int MoPSetSubId { get; set; }
        public string MoPCommand { get; set; } = string.Empty;
        public int MoPNextPoint { get; set; }
        public float MoPAngle { get; set; }
        public float MoPDistance { get; set; }
        public int MoPValue { get; set; }
        public float MoPVelocity { get; set; }
    }
}
