﻿using System.ComponentModel.DataAnnotations;

namespace QRSuite.Entity
{
    public class mapInfo
    {
        [Key]
        public int mapVersionId { get; set; } = 0;
        public string mapName { get; set; } = "NoData";
        public long mapFileSize { get; set; } = 0;
        public DateTime mapTimestamp { get; set; }
        public int mapLockCount { get; set; } = 0;
        public string serverIp { get; set; } = String.Empty;
    }
}
