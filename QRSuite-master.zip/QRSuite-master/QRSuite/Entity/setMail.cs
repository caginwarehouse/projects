﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace QRSuite.Entity
{
    public class setMail
    {
        [Key]
        public int MailId { get; set; }
        public string MailAddress { get; set; } = string.Empty;
        public string MailDomain { get; set; } = string.Empty;
    }
}
