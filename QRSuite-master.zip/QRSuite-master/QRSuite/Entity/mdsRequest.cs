﻿using System.ComponentModel.DataAnnotations;

namespace QRSuite.Entity
{
    public class mdsRequest
    {
        [Key]
        public int RequestId { get; set; }
        public string RequestMaterialName { get; set; } = string.Empty;
        public int RequestMaterialId { get; set; }
        public int RequestSupermarketId { get; set; }
        public string RequestSupermarketName { get; set; } = string.Empty;
        public int RequestLineId { get; set; }
        public string RequestLineName { get; set; } = string.Empty;
        public int RequestStationId { get; set; }
        public string RequestStationName { get; set; } = string.Empty;
        public DateTime RequestTime { get; set; }
        public DateTime ResponseTime { get; set; }
        public int RequestStatus { get; set; }
    }
}
