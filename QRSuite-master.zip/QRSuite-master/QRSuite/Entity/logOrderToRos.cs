﻿using System.ComponentModel.DataAnnotations;

namespace QRSuite.Entity
{
    public class logOrderToRos
    {
        [Key]
        public int PoDbId { get; set; }
        public int PoDepartureQrId { get; set; }
        public int PoDestinationQrId { get; set; }
        public string PoOrderSource { get; set; } = string.Empty;
        public int PoOrderCount { get; set; }
        public bool PoHasLoop { get; set; }
        public bool PoOrderStatus { get; set;}
        public int PoAgvId { get; set;}
        public string PoAgvName { get; set;} = string.Empty;
        public string PoAgvIP { get; set;} = string.Empty;
        public DateTime PoBeginTimestamp { get; set; }
        public DateTime PoEndTimestamp { get; set; }

    }
}
