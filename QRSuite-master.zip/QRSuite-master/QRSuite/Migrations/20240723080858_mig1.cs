﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace QRSuite.Migrations
{
    /// <inheritdoc />
    public partial class mig1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "agvCharge",
                columns: table => new
                {
                    DbId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Id = table.Column<int>(type: "int", nullable: false),
                    QRPointId = table.Column<int>(type: "int", nullable: false),
                    QRPointPreId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_agvCharge", x => x.DbId);
                });

            migrationBuilder.CreateTable(
                name: "agvInfo",
                columns: table => new
                {
                    AgvDbId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AgvId = table.Column<int>(type: "int", nullable: false),
                    AgvName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    AgvIP = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    AgvTier = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_agvInfo", x => x.AgvDbId);
                });

            migrationBuilder.CreateTable(
                name: "liveOrders",
                columns: table => new
                {
                    livePoId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    livePoThreatId = table.Column<int>(type: "int", nullable: false),
                    PoDepartureQrId = table.Column<int>(type: "int", nullable: false),
                    PoDestinationQrId = table.Column<int>(type: "int", nullable: false),
                    PoOrderSource = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PoOrderCount = table.Column<int>(type: "int", nullable: false),
                    PoHasLoop = table.Column<bool>(type: "bit", nullable: false),
                    PoAgvId = table.Column<int>(type: "int", nullable: false),
                    PoAgvName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PoAgvIP = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PoBeginTimestamp = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_liveOrders", x => x.livePoId);
                });

            migrationBuilder.CreateTable(
                name: "logMapToRos",
                columns: table => new
                {
                    MtRId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MtRAgvId = table.Column<int>(type: "int", nullable: false),
                    MtRAgvName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    MtRAgvIp = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    MtRMapId = table.Column<int>(type: "int", nullable: false),
                    MtRMapName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    MtRTimestamp = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_logMapToRos", x => x.MtRId);
                });

            migrationBuilder.CreateTable(
                name: "logOrderToRos",
                columns: table => new
                {
                    PoDbId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PoDepartureQrId = table.Column<int>(type: "int", nullable: false),
                    PoDestinationQrId = table.Column<int>(type: "int", nullable: false),
                    PoOrderSource = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PoOrderCount = table.Column<int>(type: "int", nullable: false),
                    PoHasLoop = table.Column<bool>(type: "bit", nullable: false),
                    PoOrderStatus = table.Column<bool>(type: "bit", nullable: false),
                    PoAgvId = table.Column<int>(type: "int", nullable: false),
                    PoAgvName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PoAgvIP = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PoBeginTimestamp = table.Column<DateTime>(type: "datetime2", nullable: false),
                    PoEndTimestamp = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_logOrderToRos", x => x.PoDbId);
                });

            migrationBuilder.CreateTable(
                name: "mapInfo",
                columns: table => new
                {
                    mapVersionId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    mapName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    mapFileSize = table.Column<long>(type: "bigint", nullable: false),
                    mapTimestamp = table.Column<DateTime>(type: "datetime2", nullable: false),
                    mapLockCount = table.Column<int>(type: "int", nullable: false),
                    serverIp = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_mapInfo", x => x.mapVersionId);
                });

            migrationBuilder.CreateTable(
                name: "mapPaths",
                columns: table => new
                {
                    PathDbId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PathFromId = table.Column<int>(type: "int", nullable: false),
                    PathFromX = table.Column<double>(type: "float", nullable: false),
                    PathFromY = table.Column<double>(type: "float", nullable: false),
                    PathToId = table.Column<int>(type: "int", nullable: false),
                    PathToX = table.Column<double>(type: "float", nullable: false),
                    PathToY = table.Column<double>(type: "float", nullable: false),
                    PathVelocity = table.Column<double>(type: "float", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_mapPaths", x => x.PathDbId);
                });

            migrationBuilder.CreateTable(
                name: "mapPoints",
                columns: table => new
                {
                    PointDbId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PointId = table.Column<int>(type: "int", nullable: false),
                    PointX = table.Column<double>(type: "float", nullable: false),
                    PointY = table.Column<double>(type: "float", nullable: false),
                    PointRelease = table.Column<int>(type: "int", nullable: false),
                    PointCosAngleOffset = table.Column<int>(type: "int", nullable: false),
                    PointACosAngleOffset = table.Column<int>(type: "int", nullable: false),
                    PointSinAngleOffset = table.Column<int>(type: "int", nullable: false),
                    PointASinAngleOffset = table.Column<int>(type: "int", nullable: false),
                    PointOperation = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PointSafetyMode = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_mapPoints", x => x.PointDbId);
                });

            migrationBuilder.CreateTable(
                name: "mdsLines",
                columns: table => new
                {
                    station_group_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    station_group_name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    supermarket_id = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_mdsLines", x => x.station_group_id);
                });

            migrationBuilder.CreateTable(
                name: "mdsMaterial",
                columns: table => new
                {
                    MaterialId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MaterialName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    MaterialSupermarketId = table.Column<int>(type: "int", nullable: false),
                    MaterialSupermarketName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    MaterialLineId = table.Column<int>(type: "int", nullable: false),
                    MaterialLineName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    MaterialStationId = table.Column<int>(type: "int", nullable: false),
                    MaterialStationName = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_mdsMaterial", x => x.MaterialId);
                });

            migrationBuilder.CreateTable(
                name: "mdsRequest",
                columns: table => new
                {
                    RequestId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RequestMaterialName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    RequestMaterialId = table.Column<int>(type: "int", nullable: false),
                    RequestSupermarketId = table.Column<int>(type: "int", nullable: false),
                    RequestSupermarketName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    RequestLineId = table.Column<int>(type: "int", nullable: false),
                    RequestLineName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    RequestStationId = table.Column<int>(type: "int", nullable: false),
                    RequestStationName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    RequestTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ResponseTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    RequestStatus = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_mdsRequest", x => x.RequestId);
                });

            migrationBuilder.CreateTable(
                name: "mdsStation",
                columns: table => new
                {
                    StationId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StationName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StationIdPoint = table.Column<int>(type: "int", nullable: false),
                    StationLineId = table.Column<int>(type: "int", nullable: false),
                    StationLineName = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_mdsStation", x => x.StationId);
                });

            migrationBuilder.CreateTable(
                name: "mdsSupermarket",
                columns: table => new
                {
                    SupermarketId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SupermarketName = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    SupermarketNamePoint = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_mdsSupermarket", x => x.SupermarketId);
                });

            migrationBuilder.CreateTable(
                name: "setMail",
                columns: table => new
                {
                    MailId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MailAddress = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    MailDomain = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_setMail", x => x.MailId);
                });

            migrationBuilder.CreateTable(
                name: "setParams",
                columns: table => new
                {
                    paramId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    paramName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ValueString = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_setParams", x => x.paramId);
                });

            migrationBuilder.InsertData(
                table: "setParams",
                columns: new[] { "paramId", "ValueString", "paramName" },
                values: new object[,]
                {
                    { 1, "0.5", "ForwardSpeed" },
                    { 2, "0.5", "BackwardSpeed" },
                    { 3, "0.3", "TurnLeftSpeed" },
                    { 4, "0.3", "TurnRightSpeed" },
                    { 5, "5", "PivotTolerance" },
                    { 6, "30", "XPositioningTolarance" },
                    { 7, "30", "YPositioningTolarance" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "agvCharge");

            migrationBuilder.DropTable(
                name: "agvInfo");

            migrationBuilder.DropTable(
                name: "liveOrders");

            migrationBuilder.DropTable(
                name: "logMapToRos");

            migrationBuilder.DropTable(
                name: "logOrderToRos");

            migrationBuilder.DropTable(
                name: "mapInfo");

            migrationBuilder.DropTable(
                name: "mapPaths");

            migrationBuilder.DropTable(
                name: "mapPoints");

            migrationBuilder.DropTable(
                name: "mdsLines");

            migrationBuilder.DropTable(
                name: "mdsMaterial");

            migrationBuilder.DropTable(
                name: "mdsRequest");

            migrationBuilder.DropTable(
                name: "mdsStation");

            migrationBuilder.DropTable(
                name: "mdsSupermarket");

            migrationBuilder.DropTable(
                name: "setMail");

            migrationBuilder.DropTable(
                name: "setParams");
        }
    }
}
