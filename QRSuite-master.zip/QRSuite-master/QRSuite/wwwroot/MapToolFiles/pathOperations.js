
function find_path()
{

    if(paths.length < 1)
    {
        document.getElementById("alert-body").innerText = "There is no path in system!";
        const toastLiveExample = document.getElementById('liveToast');
        const toastBootstrap = bootstrap.Toast.getOrCreateInstance(toastLiveExample);
        toastBootstrap.show()
        return;
    }

    const foundIndex = paths.findIndex(k => k.pathFromId == document.getElementById("path_info_from").value || k.pathToId == document.getElementById("path_info_to").value);
    if (foundIndex !== -1) {
        document.getElementById("alert-body").innerText = "Path found!";
        const toastLiveExample = document.getElementById('liveToast');
        const toastBootstrap = bootstrap.Toast.getOrCreateInstance(toastLiveExample);
        toastBootstrap.show()

        document.getElementById("pathEditSave").disabled = false;
        document.getElementById("pathEditDelete").disabled = false;
        document.getElementById("speed_set_select").disabled = false;
        document.getElementById("speed_set_select").value = paths[foundIndex]["pathVelocity"];
        return;
    } else {
        document.getElementById("alert-body").innerText = "Path not found!";
        const toastLiveExample = document.getElementById('liveToast');
        const toastBootstrap = bootstrap.Toast.getOrCreateInstance(toastLiveExample);
        toastBootstrap.show()
    }
}

function editPath()
{
    const foundIndex = paths.findIndex(k => k.pathFromId == document.getElementById("path_info_from").value || k.pathToId == document.getElementById("path_info_to").value);
    if (foundIndex !== -1) {
        paths[foundIndex]["pathVelocity"] = document.getElementById("speed_set_select").value;
        resetPathCard();
        return;
    }
}

function deletePath()
{

    const foundIndex = paths.findIndex(k => k.pathFromId == document.getElementById("path_info_from").value || k.pathToId == document.getElementById("path_info_to").value);
    if (foundIndex !== -1) {
        paths.splice(foundIndex, 1);
        loadPaths();

        document.getElementById("alert-body").innerText = "Path deleted!";
        const toastLiveExample = document.getElementById('liveToast');
        const toastBootstrap = bootstrap.Toast.getOrCreateInstance(toastLiveExample);
        toastBootstrap.show();
        resetPathCard();
        return;
    }
    document.getElementById("alert-body").innerText = "Path not found!";
    const toastLiveExample = document.getElementById('liveToast');
    const toastBootstrap = bootstrap.Toast.getOrCreateInstance(toastLiveExample);
    toastBootstrap.show();

    resetPathCard();
}

function resetPathCard()
{
    //reset Path Info
    document.getElementById("pathEditSave").disabled = true;
    document.getElementById("pathEditDelete").disabled = true;
    document.getElementById("speed_set_select").disabled = true;
    document.getElementById("speed_set_select").value = 10;
}
