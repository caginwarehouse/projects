function set_origin_visible()
{
    if(document.getElementById("Origin").checked)
    {
        if (map.hasLayer(groupOrigin)) {
            map.removeLayer(groupOrigin);
        }
    } else
    {
        groupOrigin.addTo(map);
    }
}

function set_shelf_visible() {
    if (document.getElementById("Shelf").checked) {
        if (map.hasLayer(groupShelf)) {
            map.removeLayer(groupShelf);
        }
    } else {
        groupShelf.addTo(map);
    }
}

function set_point_visible()
{
    if(document.getElementById("Points").checked)
    {
        if (map.hasLayer(groupPoints)) {
            map.removeLayer(groupPoints);
        }
        if (map.hasLayer(groupPointIds)) {
            map.removeLayer(groupPointIds);
        }
    } else
    {
        groupPoints.addTo(map);
        groupPointIds.addTo(map);
    }
}

function set_path_visible()
{
    if(document.getElementById("Paths").checked)
    {
        if (map.hasLayer(groupPoints)) {
            map.removeLayer(groupPaths);
        }
    } else
    {
        groupPaths.addTo(map);
    }
}

function goPoint()
{
    for(let i=0;i < points.length; i++)
    {
        if(parseInt(points[i]["id"]) == document.getElementById("goPointInput").value)
        {
            map.setView([parseFloat(points[i]["x"]), parseFloat(points[i]["y"])], 7);
            return;
        }
    }
    document.getElementById("alert-body").innerText = "Point not found!";
    const toastLiveExample = document.getElementById('liveToast');
    const toastBootstrap = bootstrap.Toast.getOrCreateInstance(toastLiveExample);
    toastBootstrap.show()
    return;
}