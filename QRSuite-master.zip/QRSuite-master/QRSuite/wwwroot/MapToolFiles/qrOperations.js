









function deleteQr()
{
    if(document.getElementById("label_qr_id").innerText == "Unselected")
        return;
    for(let i=0;i < points.length; i++)
    {
        if(points[i]["pointId"] == document.getElementById("label_qr_id").innerText)
        {
            points.splice(i, 1); 

            let deleted_qr_id = parseInt(document.getElementById("label_qr_id").innerText);
            loadPoints();

            const indicesToRemove = [];

            for (let i = 0; i < paths.length; i++) {
                if (paths[i].pathFromId == deleted_qr_id || paths[i].pathToId == deleted_qr_id) {
                    indicesToRemove.push(i);
                }
            }

            for (let i = indicesToRemove.length - 1; i >= 0; i--) {
                paths.splice(indicesToRemove[i], 1);
            }
            loadPaths();

            document.getElementById("alert-body").innerText = "QR deleted!";
            const toastLiveExample = document.getElementById('liveToast');
            const toastBootstrap = bootstrap.Toast.getOrCreateInstance(toastLiveExample);
            toastBootstrap.show()
            return;
        }
    }
}




