function load_operations_to_select()
{
    document.getElementById("qr_operation_select").innerHTML = "";
    var selected_value = document.getElementById("qr_operation_type").value;
    console.log(selected_value);
    if(selected_value == "Lift")
    {
        var element1 = document.createElement("option");
        element1.value = "LiftUp";
        element1.innerText = "LiftUp";
        document.getElementById("qr_operation_select").appendChild(element1);

        var element2 = document.createElement("option");
        element2.value = "LiftDown";
        element2.innerText = "LiftDown";
        document.getElementById("qr_operation_select").appendChild(element2);
    } else if(selected_value == "Conveyor")
    {
        var element1 = document.createElement("option");
        element1.value = "Give";
        element1.innerText = "Give";
        document.getElementById("qr_operation_select").appendChild(element1);

        var element2 = document.createElement("option");
        element2.value = "Take";
        element2.innerText = "Take";
        document.getElementById("qr_operation_select").appendChild(element2);

        var element3 = document.createElement("option");
        element3.value = "GiveTake";
        element3.innerText = "GiveTake";
        document.getElementById("qr_operation_select").appendChild(element3);

        var element4 = document.createElement("option");
        element4.value = "ConditiallyGiveTake";
        element4.innerText = "ConditiallyGiveTake";
        document.getElementById("qr_operation_select").appendChild(element4);
    }
    else if(selected_value == "Trig")
    {
        var element1 = document.createElement("option");
        element1.value = "MDSTrig";
        element1.innerText = "MDSTrig";
        document.getElementById("qr_operation_select").appendChild(element1);

        var element2 = document.createElement("option");
        element2.value = "ButtonTrig";
        element2.innerText = "ButtonTrig";
        document.getElementById("qr_operation_select").appendChild(element2);
    }
    else if(selected_value == "Lock")
    {
        if(lock_count == 0)
        {
            var element = document.createElement("option");
            element.value = "NoLock";
            element.innerText = "NoLock";
            document.getElementById("qr_operation_select").appendChild(element);
            return;
        }
        for(let i=1; i <= lock_count; i++)
        {
            var elementTake = document.createElement("option");
            elementTake.value = "TakeKey-"+i;
            elementTake.innerText = "TakeKey-" + i;
            document.getElementById("qr_operation_select").appendChild(elementTake);

            var elementDrop = document.createElement("option");
            elementDrop.value = "DropKey-" + i;
            elementDrop.innerText = "DropKey-" + i;
            document.getElementById("qr_operation_select").appendChild(elementDrop);
        }
    }
    else if(selected_value == "Charge")
    {
        var element1 = document.createElement("option");
        element1.value = "HandsFree";
        element1.innerText = "HandsFree";
        document.getElementById("qr_operation_select").appendChild(element1);

        var element2 = document.createElement("option");
        element2.value = "Manuel";
        element2.innerText = "Manuel";
        document.getElementById("qr_operation_select").appendChild(element2);
    }
    else if(selected_value == "NoOperation")
    {
        var element1 = document.createElement("option");
        element1.value = "NoOperation";
        element1.innerText = "NoOperation";
        document.getElementById("qr_operation_select").appendChild(element1);
    }
}