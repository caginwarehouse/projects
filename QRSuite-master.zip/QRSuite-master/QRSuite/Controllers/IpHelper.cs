﻿using System.Net;
using System.Net.NetworkInformation;

namespace QRSuite.Controllers
{
    public class IpHelper
    {
        public static string GetMachineIp()
        {
            string localIp = "";

            // Network arayüzleri üzerinde döngü yapın
            foreach (NetworkInterface networkInterface in NetworkInterface.GetAllNetworkInterfaces())
            {
                // Sadece aktif ve IPV4 ağ arayüzleri için
                if (networkInterface.OperationalStatus == OperationalStatus.Up &&
                    networkInterface.NetworkInterfaceType == NetworkInterfaceType.Ethernet &&
                    networkInterface.GetIPProperties().UnicastAddresses.Any(ip => ip.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)) // Add 'System.Net.Sockets'
                {
                    // İlk uygun IP adresini alın
                    localIp = networkInterface.GetIPProperties().UnicastAddresses.First(ip => ip.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork).Address.ToString();
                    break;
                }
            }

            return localIp;
        }
    }
}
