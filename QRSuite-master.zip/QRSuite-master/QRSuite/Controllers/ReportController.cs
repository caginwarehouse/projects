﻿using Microsoft.AspNetCore.Mvc;
using QRSuite.Entity;
using QRSuite.Models;

namespace QRSuite.Controllers
{
    public class ReportController : Controller
    {
        public Context _db;
        public ReportController(Context db)
        {
            _db = db;
        }

        public IActionResult DeliveryReport()
        {
            DeliveryReportModel deliveryReport = new DeliveryReportModel();

            //create supermarkets
            List<mdsSupermarket> mdsSupermarketList = new List<mdsSupermarket>();
            mdsSupermarketList = _db.mdsSupermarket.ToList();
            foreach (var item in mdsSupermarketList)
            {
                deliveryReport.deliveryInfo.Add(item, new supermarketDeliveryInfo
                {
                    deliveryCount = 0,
                    loadDuration = TimeSpan.Zero
                });
            }


            List<mdsRequest> requests = new List<mdsRequest>();
            requests = _db.mdsRequest.Where(k => k.RequestTime.Date == DateTime.Today).ToList();
            foreach (var item in requests)
            {
                mdsSupermarket? _mdsSupermarket = mdsSupermarketList.FindLast(k => k.SupermarketId == item.RequestSupermarketId);
                if (_mdsSupermarket != null)
                    if (deliveryReport.deliveryInfo.ContainsKey(_mdsSupermarket))
                    {
                        deliveryReport.deliveryInfo[_mdsSupermarket].deliveryCount++;
                        deliveryReport.deliveryInfo[_mdsSupermarket].loadDuration += (item.ResponseTime - item.RequestTime);
                    }

            }
            return View(deliveryReport);
        }
    }
}
