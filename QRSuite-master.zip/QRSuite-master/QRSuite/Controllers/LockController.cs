﻿using Microsoft.AspNetCore.Mvc;

namespace QRSuite.Controllers
{
    public class LockController : Controller
    {
        //false -> free
        //true  -> holded
        private static Dictionary<int, bool> locks = new Dictionary<int, bool>();

        public static void setLocks()
        {
            for (int i = 0; i < 200; i++)
            {
                locks.Add(i, false);
            }
        }

        public bool LockManager(int lockId, bool takeDrop)
        {
            if(takeDrop) //take key
            {
                if (locks[lockId] == false)
                {
                    locks[lockId] = true;
                    return true;
                } else
                {
                    return false;
                }
            } else //drop key
            {
                locks[lockId] = false;
                return true;
            }
        }

        public static Dictionary<int, bool> getLockStatus()
        {
            return locks;
        }

        public static void dropLock(int lockId)
        {
            locks[lockId] = false;
        }
    }
}
