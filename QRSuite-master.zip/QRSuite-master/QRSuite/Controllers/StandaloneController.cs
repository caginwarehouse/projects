﻿using Humanizer;
using Microsoft.AspNetCore.Authentication.OAuth.Claims;
using Microsoft.AspNetCore.Mvc;
using QRSuite.Controllers.DriveLogic;
using QRSuite.Controllers.RosTools;
using QRSuite.Entity;
using QRSuite.Models;
using System.Globalization;
using System.Net.WebSockets;
using System.Xml.Linq;

namespace QRSuite.Controllers
{
    public class StandaloneController : Controller
    {
        public Context _db;
        public StandaloneController(Context db)
        {
            _db = db;
        }
        public IActionResult MonitorTool()
        {
            MonitorToolModel model = new MonitorToolModel();
            model.agvInfos = _db.agvInfo.ToList();
            model.mapPaths = _db.mapPaths.ToList();
            model.mapPoints = _db.mapPoints.ToList();
            model.setParams = _db.setParams.ToList();
            model.agvCharges = _db.agvCharge.ToList();
            return View(model);
        }

        public IActionResult ProductionOrders(string theDay)
        {
            MainModel mainModel = new MainModel(_db);
            if(theDay != null)
            {
                //DateTime day = Convert.ToDateTime(theDay);
                DateTime day = DateTime.ParseExact(theDay, "dd/MM/yyyy", null);
                mainModel.PoOrders = _db.logOrderToRos.Where(k => k.PoBeginTimestamp.Date == day.Date).ToList();
            }
            return View(mainModel);
        }

        public IActionResult DriveTool()
        {
            MonitorToolModel model = new MonitorToolModel();
            model.agvInfos = _db.agvInfo.ToList();
            model.mapPaths = _db.mapPaths.ToList();
            model.mapPoints = _db.mapPoints.ToList();
            return View(model);
        }

        public IActionResult DriveToolPhone()
        {
            MonitorToolModel model = new MonitorToolModel();
            model.agvInfos = _db.agvInfo.ToList();
            model.mapPaths = _db.mapPaths.ToList();
            model.mapPoints = _db.mapPoints.ToList();
            return View(model);
        }

        public bool sendXmlFile(IFormFile xmlFile, string manuelIpInput)
        {
            orderFile orderFile = new orderFile();

            if (xmlFile != null)
            {
                if (xmlFile.ContentType != "text/xml")
                {
                    return false;
                }
                int orderSetsCount = 0;
                //Dictionary<int, List<orderSet>> tempOrderSets = new Dictionary<int, List<orderSet>>();
                using (var stream = xmlFile.OpenReadStream())
                {
                    XDocument xDoc = XDocument.Load(stream);

                    foreach (var XElement in xDoc.Descendants("head"))
                    {
                        orderFile.hasError = Convert.ToBoolean(XElement.Element("hasError").Value);
                        orderFile.hasLoop = Convert.ToBoolean(XElement.Element("hasLoop").Value);
                        orderFile.beginLoopId = Convert.ToInt32(XElement.Element("beginLoopId").Value);
                        orderFile.endLoopId = Convert.ToInt32(XElement.Element("endLoopId").Value);
                        orderFile.departureQrId = Convert.ToInt32(XElement.Element("departureQrId").Value);
                    }
                    foreach (var XElement in xDoc.Descendants("orderSets"))
                    {
                        List<orderSet> tempOrderSetList = new List<orderSet>();
                        foreach (var orderElement in XElement.Descendants("orderItem"))
                        {
                            string str = orderElement.Element("velocity").Value.ToString();

                            double velocity_value = 0;
                            if (orderElement.Element("velocity").Value.Contains("."))
                            {
                                velocity_value = Convert.ToDouble(orderElement.Element("velocity").Value.Replace('.', ','));
                            } else
                            {
                                velocity_value = Convert.ToDouble(orderElement.Element("velocity").Value);
                            }

                            //double velo = Convert.ToDouble(orderElement.Element("velocity").Value.);
                            orderSet tempOrderSet = new orderSet
                            {
                                orderId = Convert.ToInt32(orderElement.Element("orderId").Value.ToString()),
                                command = orderElement.Element("command").Value.ToString(),
                                nextPoint = Convert.ToInt32(orderElement.Element("nextPoint").Value),
                                angle = Convert.ToDouble(orderElement.Element("angle").Value.ToString()),
                                distance = Convert.ToDouble(orderElement.Element("distance").Value.ToString()),
                                lockId = Convert.ToInt32(orderElement.Element("lockId").Value.ToString()),
                                velocity = velocity_value
                            };
                            tempOrderSetList.Add(tempOrderSet);
                        }
                        orderFile.orderSets.Add(orderSetsCount, tempOrderSetList);
                        orderSetsCount++;
                    }
                }

                

                agvInfo? _agvInfo = _db.agvInfo.Where(k => k.AgvIP == manuelIpInput).FirstOrDefault();
                if(_agvInfo != null)
                {
                    logOrderToRos orderToRos = new logOrderToRos
                    {
                        PoDepartureQrId = orderFile.departureQrId,
                        PoDestinationQrId = -1,
                        PoOrderSource = "ManuelOrder",
                        PoOrderCount = orderFile.orderSets.Count,
                        PoHasLoop = orderFile.hasLoop,
                        PoOrderStatus = orderFile.hasError,
                        PoAgvId = _agvInfo.AgvId,
                        PoAgvName = _agvInfo.AgvName,
                        PoAgvIP = _agvInfo.AgvIP,
                        PoBeginTimestamp = DateTime.Now,
                    };
                    _db.logOrderToRos.Add(orderToRos);
                    _db.SaveChanges();

                } else { return false; }
                OrderToRos.UploadOrderToRos(orderFile, manuelIpInput);
                return true;
            }
            return false;
        }

        public List<int> sendCharge(int from, int dockId, string ip)
        {
            List<mapPoints> points = new List<mapPoints>();
            List<mapPaths> paths = new List<mapPaths>();
            points = _db.mapPoints.ToList();
            paths = _db.mapPaths.ToList();
            List<int> retRoutePoints = new List<int>();
            agvInfo? _agvInfo = _db.agvInfo.Where(k => k.AgvIP == ip).FirstOrDefault();
            if (_agvInfo == null)
            {
                retRoutePoints.Add(-1);
                return retRoutePoints;
            }
            int pivot_tolerance = Convert.ToInt32(_db.setParams.Where(k => k.paramName == "PivotTolerance").First().ValueString);
            agvCharge _agvCharge = _db.agvCharge.Where(k => k.Id == dockId).FirstOrDefault();
            if(_agvCharge == null)
            {
                retRoutePoints.Add(-1);
                return retRoutePoints;
            }

            orderFile orderFile = DriveLogic_Main.chargeOrder(points, paths, from, _agvCharge.QRPointPreId, _agvCharge.QRPointId, pivot_tolerance);
            OrderToRos.UploadOrderToRos(orderFile, ip);

            logOrderToRos orderToRos = new logOrderToRos
            {
                PoDepartureQrId = orderFile.departureQrId,
                PoDestinationQrId = _agvCharge.QRPointId,
                PoOrderSource = "ChargeOrder",
                PoOrderCount = orderFile.orderSets.Count,
                PoHasLoop = orderFile.hasLoop,
                PoOrderStatus = orderFile.hasError,
                PoAgvId = _agvInfo.AgvId,
                PoAgvName = _agvInfo.AgvName,
                PoAgvIP = _agvInfo.AgvIP,
                PoBeginTimestamp = DateTime.Now,
                PoEndTimestamp = DateTime.Now,
            };
            _db.logOrderToRos.Add(orderToRos);
            _db.SaveChanges();
            return retRoutePoints;
        }

        public List<int> sendOrderToRos(int from, int to, string ip)
        {
            List<mapPoints> points = new List<mapPoints>();
            List<mapPaths> paths = new List<mapPaths>();
            points = _db.mapPoints.ToList();
            paths = _db.mapPaths.ToList();

            List<int> retRoutePoints = new List<int>();
            agvInfo? _agvInfo = _db.agvInfo.Where(k => k.AgvIP == ip).FirstOrDefault();
            if(_agvInfo == null)
            {
                retRoutePoints.Add(-1);
                return retRoutePoints;
            }
            int pivot_tolerance = Convert.ToInt32(_db.setParams.Where(k => k.paramName == "PivotTolerance").First().ValueString);
            orderFile orderFile = DriveLogic_Main.driveLogicMain(points, paths, from, to, pivot_tolerance);
            if(orderFile.hasError)
            {
                retRoutePoints.Add(-1);
            }
            else
            {
                retRoutePoints.Add(from);
                foreach (var item in orderFile.orderSets)
                {
                    foreach (var item2 in item.Value)
                    {
                        if(item2.command == "move")
                        {
                            retRoutePoints.Add(item2.nextPoint);
                        }
                    }
                }

            }

            OrderToRos.UploadOrderToRos(orderFile, ip);

            logOrderToRos orderToRos = new logOrderToRos
            {
                PoDepartureQrId = orderFile.departureQrId,
                PoDestinationQrId = to,
                PoOrderSource = "MonitorTool",
                PoOrderCount = orderFile.orderSets.Count,
                PoHasLoop = orderFile.hasLoop,
                PoOrderStatus = orderFile.hasError,
                PoAgvId = _agvInfo.AgvId,
                PoAgvName = _agvInfo.AgvName,
                PoAgvIP = _agvInfo.AgvIP,
                PoBeginTimestamp = DateTime.Now,
                PoEndTimestamp = DateTime.Now,
            };
            _db.logOrderToRos.Add(orderToRos);
            _db.SaveChanges();

            return retRoutePoints;
        }

        public IActionResult LockManager()
        {
            LockManagerModel lockManagerModel = new LockManagerModel();
            lockManagerModel.lockValues = LockController.getLockStatus();
            return View(lockManagerModel);
        }

        public void FreeLock(int lockId)
        {
            LockController.dropLock(lockId);
            return;
        }

    }
}
