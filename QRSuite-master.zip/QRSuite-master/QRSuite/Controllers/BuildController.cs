﻿using Microsoft.AspNetCore.Mvc;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using QRSuite.Models;
using System.Globalization;
using QRSuite.Entity;
using Microsoft.EntityFrameworkCore;
using Microsoft.SqlServer.Server;
using System.Net.NetworkInformation;
using Microsoft.Extensions.Hosting;
using System.Linq;
using Humanizer;
using System.Collections.Generic;
using Microsoft.AspNetCore.Routing;
using QRSuite.Controllers.DriveLogic;
using QRSuite.Controllers.CommandTools;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json;
using QRSuite.Controllers.RosTools;
using System.Net.Sockets;

namespace QRSuite.Controllers
{
    public class BuildController : Controller
    {
        public Context _db;
        public BuildController(Context db)
        {
            _db = db;
        }

        public string Simulate(List<mapPoints> points, List<mapPaths> paths, int from, int to)
        {
            int pivot_tolerance = Convert.ToInt32(_db.setParams.Where(k => k.paramName == "PivotTolerance").First().ValueString);
            orderFile orderFile = DriveLogic_Main.driveLogicMain(points, paths, from, to, pivot_tolerance);

            var jsonSettings = new JsonSerializerSettings { ContractResolver = new CamelCasePropertyNamesContractResolver() };
            string jsonResponse = JsonConvert.SerializeObject(orderFile, jsonSettings);

            return jsonResponse;
        }

        //Simulation Tool page controller
        public IActionResult SimulationTool(IFormFile xmlFile)
        {
            MapModel mapModel = new MapModel();
            if (xmlFile != null)
            {
                if(xmlFile.ContentType != "text/xml")
                {
                    return View(mapModel);
                }
                List<mapPoints> mapPoints = new List<mapPoints>();
                List<mapPaths> mapPaths = new List<mapPaths>();

                using (var stream = xmlFile.OpenReadStream())
                {
                    XDocument xDoc = XDocument.Load(stream);
                    foreach (var XElement in xDoc.Descendants("mapinfo"))
                    {
                        mapModel.MapName = XElement.Element("Mapname").Value.ToString();
                        mapModel.DefaultSpeed = Convert.ToInt32(XElement.Element("Defaultspeed").Value);
                        mapModel.MapLock = Convert.ToInt32(XElement.Element("Lockcount").Value);
                    }

                    foreach (var XElement in xDoc.Descendants("points"))
                    {
                        foreach (var pts in XElement.Descendants("PointElement"))
                        {
                            mapPoints tempPoint = new mapPoints();
                            tempPoint.PointId = Convert.ToInt32(pts.Element("Id").Value);
                            tempPoint.PointX = Convert.ToDouble(pts.Element("X").Value, CultureInfo.InvariantCulture);
                            tempPoint.PointY = Convert.ToDouble(pts.Element("Y").Value, CultureInfo.InvariantCulture);
                            tempPoint.PointCosAngleOffset = Convert.ToInt32(pts.Element("pointcosAngle").Value);
                            tempPoint.PointACosAngleOffset = Convert.ToInt32(pts.Element("pointAcosAngle").Value);
                            tempPoint.PointSinAngleOffset = Convert.ToInt32(pts.Element("pointsinAngle").Value);
                            tempPoint.PointASinAngleOffset = Convert.ToInt32(pts.Element("pointAsinAngle").Value);
                            tempPoint.PointRelease = Convert.ToInt32(pts.Element("Release").Value);
                            tempPoint.PointOperation = pts.Element("Operation").Value.ToString();
                            tempPoint.PointSafetyMode = pts.Element("Safetymode").Value.ToString();
                            mapPoints.Add(tempPoint);
                        }
                    }

                    foreach (var XElement in xDoc.Descendants("paths"))
                    {
                        foreach (var pts in XElement.Descendants("PathElement"))
                        {
                            mapPaths tempPath = new mapPaths();
                            tempPath.PathFromId = Convert.ToInt32(pts.Element("FromId").Value);
                            tempPath.PathFromX = Convert.ToDouble(pts.Element("FromY").Value, CultureInfo.InvariantCulture);
                            tempPath.PathFromY = Convert.ToDouble(pts.Element("FromX").Value, CultureInfo.InvariantCulture);

                            tempPath.PathToId = Convert.ToInt32(pts.Element("ToId").Value);
                            tempPath.PathToX = Convert.ToDouble(pts.Element("ToY").Value, CultureInfo.InvariantCulture);
                            tempPath.PathToY = Convert.ToDouble(pts.Element("ToX").Value, CultureInfo.InvariantCulture);

                            tempPath.PathVelocity = Convert.ToInt32(pts.Element("speed").Value);
                            mapPaths.Add(tempPath);
                        }
                    }
                }

                mapModel.MapPoints.AddRange(mapPoints);
                mapModel.MapPaths.AddRange(mapPaths);
            }
            return View(mapModel);
        }



        //Map Tool page controller
        public IActionResult MapTool(IFormFile xmlFile,int from_db)
        {
            MapModel mapModel = new MapModel();

            if (xmlFile != null)
            {
                if (xmlFile.ContentType != "text/xml")
                {
                    return View(mapModel);
                }

                List<mapPoints> mapPoints = new List<mapPoints>();
                List<mapPaths> mapPaths = new List<mapPaths>();

                using (var stream = xmlFile.OpenReadStream())
                {
                    XDocument xDoc = XDocument.Load(stream);
                    foreach (var XElement in xDoc.Descendants("mapinfo"))
                    {
                        mapModel.MapName = XElement.Element("Mapname").Value.ToString();
                        mapModel.DefaultSpeed = Convert.ToInt32(XElement.Element("Defaultspeed").Value);
                        mapModel.MapLock = Convert.ToInt32(XElement.Element("Lockcount").Value);
                    }

                    foreach (var XElement in xDoc.Descendants("points"))
                    {
                        foreach (var pts in XElement.Descendants("PointElement"))
                        {
                            mapPoints tempPoint = new mapPoints();
                            tempPoint.PointId = Convert.ToInt32(pts.Element("Id").Value);
                            tempPoint.PointY = Convert.ToDouble(pts.Element("X").Value, CultureInfo.InvariantCulture);
                            tempPoint.PointX = Convert.ToDouble(pts.Element("Y").Value, CultureInfo.InvariantCulture);
                            tempPoint.PointCosAngleOffset = Convert.ToInt32(pts.Element("pointcosAngle").Value);
                            tempPoint.PointACosAngleOffset = Convert.ToInt32(pts.Element("pointAcosAngle").Value);
                            tempPoint.PointSinAngleOffset = Convert.ToInt32(pts.Element("pointsinAngle").Value);
                            tempPoint.PointASinAngleOffset = Convert.ToInt32(pts.Element("pointAsinAngle").Value);
                            tempPoint.PointRelease = Convert.ToInt32(pts.Element("Release").Value);
                            tempPoint.PointOperation = pts.Element("Operation").Value.ToString();
                            tempPoint.PointSafetyMode = pts.Element("Safetymode").Value.ToString();
                            mapPoints.Add(tempPoint);
                        }
                    }

                    foreach (var XElement in xDoc.Descendants("paths"))
                    {
                        foreach (var pts in XElement.Descendants("PathElement"))
                        {
                            mapPaths tempPath = new mapPaths();
                            tempPath.PathFromId = Convert.ToInt32(pts.Element("FromId").Value);
                            tempPath.PathFromX = Convert.ToDouble(pts.Element("FromY").Value, CultureInfo.InvariantCulture);
                            tempPath.PathFromY = Convert.ToDouble(pts.Element("FromX").Value, CultureInfo.InvariantCulture);
                            tempPath.PathToX = Convert.ToDouble(pts.Element("ToY").Value, CultureInfo.InvariantCulture);
                            tempPath.PathToY = Convert.ToDouble(pts.Element("ToX").Value, CultureInfo.InvariantCulture);
                            
                            tempPath.PathToId = Convert.ToInt32(pts.Element("ToId").Value);

                            tempPath.PathVelocity = Convert.ToInt32(pts.Element("speed").Value);
                            mapPaths.Add(tempPath);
                        }
                    }
                }

                mapModel.MapPoints.AddRange(mapPoints);
                mapModel.MapPaths.AddRange(mapPaths);
            } else if(from_db == 1 && xmlFile == null)
            {
                mapInfo? _mapInfo = _db.mapInfo.OrderBy(k => k.mapVersionId).LastOrDefault();

                List<mapPoints> _mapPoints = new List<mapPoints>();
                List<mapPaths> _mapPaths = new List<mapPaths>();
                _mapPoints = _db.mapPoints.ToList();
                _mapPaths = _db.mapPaths.ToList();

                if (_mapInfo != null)
                {
                    mapModel.MapName = _mapInfo.mapName;
                    mapModel.MapLock = _mapInfo.mapLockCount;
                    mapModel.MapPaths.AddRange(_mapPaths);

                    foreach (mapPoints item in _mapPoints)
                    {
                        mapPoints tempMapPoints = new mapPoints();
                        tempMapPoints = item;
                        double tempX = item.PointX;
                        double tempY = item.PointY;

                        tempMapPoints.PointX = tempY;
                        tempMapPoints.PointY = tempX;
                        mapModel.MapPoints.Add(tempMapPoints);
                    }
                }

            }
            return View(mapModel);
        }

        
        public ActionResult RosTool_Direction()
        {
            List<logMapToRos> logMapToRos = new List<logMapToRos>();
            logMapToRos = _db.logMapToRos.ToList();
            _db.logMapToRos.RemoveRange(logMapToRos);
            _db.SaveChanges();

            List<agvInfo> ret_agvInfo = new List<agvInfo>();
            RosTools.MapToRos rosTool = new MapToRos(_db);
            ret_agvInfo = rosTool.UploadMapToAgv();
            mapInfo? _mapInfo = _db.mapInfo.OrderByDescending(k => k.mapVersionId).FirstOrDefault();
            foreach (var item in ret_agvInfo)
            {
                logMapToRos logMapToRos1 = new logMapToRos
                {
                    MtRAgvId = item.AgvId,
                    MtRAgvIp = item.AgvIP,
                    MtRAgvName = item.AgvName,
                    MtRMapId = _mapInfo.mapVersionId,
                    MtRMapName = _mapInfo.mapName,
                };
                _db.logMapToRos.Add(logMapToRos1);
            }
            _db.SaveChanges();
            return RedirectToAction("DbSettings", "Build");
        }

        //DbSettings page controller
        public IActionResult DbSettings(IFormFile xmlFile)
        {
            DbSettingsModel dbSettings = new DbSettingsModel();
            mapInfo? map_info = new mapInfo();
            List<mapPoints> map_points = new List<mapPoints>();
            List<mapPaths> map_paths = new List<mapPaths>();

            if (xmlFile != null)
            {

                using (var stream = xmlFile.OpenReadStream())
                {
                    //delete points first
                    map_points = _db.mapPoints.ToList();
                    _db.mapPoints.RemoveRange(map_points);

                    //delete paths first
                    map_paths = _db.mapPaths.ToList();
                    _db.mapPaths.RemoveRange(map_paths);

                    _db.SaveChanges();
                    map_points.Clear();
                    map_paths.Clear();

                    XDocument xDoc = XDocument.Load(stream);
                    foreach (var XElement in xDoc.Descendants("mapinfo"))
                    {
                        map_info.mapName = XElement.Element("Mapname").Value.ToString();
                        map_info.mapLockCount = (int)Convert.ToUInt32(XElement.Element("Lockcount").Value);
                    }
                    map_info.mapFileSize = xmlFile.Length;
                    map_info.mapTimestamp = DateTime.Now;
                    map_info.serverIp = IpHelper.GetMachineIp();
                    _db.mapInfo.Add(map_info);

                    //points
                    foreach (var XElement in xDoc.Descendants("points"))
                    {
                        foreach (var pts in XElement.Descendants("PointElement"))
                        {
                            mapPoints tempPoint = new mapPoints();
                            tempPoint.PointId = Convert.ToInt32(pts.Element("Id").Value);
                            tempPoint.PointX = Convert.ToDouble(pts.Element("X").Value, CultureInfo.InvariantCulture);
                            tempPoint.PointY = Convert.ToDouble(pts.Element("Y").Value, CultureInfo.InvariantCulture);
                            tempPoint.PointCosAngleOffset = Convert.ToInt32(pts.Element("pointcosAngle").Value);
                            tempPoint.PointACosAngleOffset = Convert.ToInt32(pts.Element("pointAcosAngle").Value);
                            tempPoint.PointSinAngleOffset = Convert.ToInt32(pts.Element("pointsinAngle").Value);
                            tempPoint.PointASinAngleOffset = Convert.ToInt32(pts.Element("pointAsinAngle").Value);
                            tempPoint.PointRelease = Convert.ToInt32(pts.Element("Release").Value);
                            tempPoint.PointOperation = pts.Element("Operation").Value.ToString();
                            tempPoint.PointSafetyMode = pts.Element("Safetymode").Value.ToString();
                            map_points.Add(tempPoint);
                        }
                    }
                    _db.mapPoints.AddRange(map_points);

                    //paths
                    foreach (var XElement in xDoc.Descendants("paths"))
                    {
                        foreach (var pts in XElement.Descendants("PathElement"))
                        {
                            mapPaths tempPath = new mapPaths();
                            tempPath.PathFromId = Convert.ToInt32(pts.Element("FromId").Value);
                            tempPath.PathFromX = Convert.ToDouble(pts.Element("FromY").Value, CultureInfo.InvariantCulture);
                            tempPath.PathFromY = Convert.ToDouble(pts.Element("FromX").Value, CultureInfo.InvariantCulture);

                            tempPath.PathToId = Convert.ToInt32(pts.Element("ToId").Value);
                            tempPath.PathToX = Convert.ToDouble(pts.Element("ToY").Value, CultureInfo.InvariantCulture);
                            tempPath.PathToY = Convert.ToDouble(pts.Element("ToX").Value, CultureInfo.InvariantCulture);

                            tempPath.PathVelocity = Convert.ToInt32(pts.Element("speed").Value);
                            map_paths.Add(tempPath);
                        }
                    }
                    _db.mapPaths.AddRange(map_paths);

                    _db.SaveChanges();
                }
            }

            mapInfo tempInfo = _db.mapInfo.OrderByDescending(k => k.mapVersionId).FirstOrDefault();
            if (tempInfo != null)
            {
                map_info = tempInfo;
                dbSettings.mapPointCount = _db.mapPoints.Count();
                dbSettings.mapPathCount = _db.mapPaths.Count();
            }

            dbSettings.agvInfos = _db.agvInfo.ToList();
            dbSettings.mails = _db.setMail.ToList();
            dbSettings.logMapToRos = _db.logMapToRos.ToList();

            dbSettings.mapInfos = map_info;
            return View(dbSettings);
        }




        //agv Operations

        public ActionResult agvDelete(int id)
        {
            try
            {
                agvInfo? temp_agvInfo = _db.agvInfo.Where(k => k.AgvId == id).FirstOrDefault();
                if (temp_agvInfo != null)
                {
                    _db.agvInfo.Remove(temp_agvInfo);
                    _db.SaveChanges();
                }
            }catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return RedirectToAction("DbSettings","Build");
        }

        public bool sendPing(string ip)
        {
            bool ret = false;
            int timeout = 1000;
            Ping pingSender = new Ping();
            PingOptions options = new PingOptions();
            // Use the default Ttl value which is 128, 
            // but change the fragmentation behavior.
            options.DontFragment = true;
            string data = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
            byte[] buffer = System.Text.Encoding.ASCII.GetBytes(data);
            try
            {
                PingReply reply = pingSender.Send(ip, timeout, buffer, options);
                if (reply.Status == IPStatus.Success)
                {
                    Console.WriteLine("Ping successful.");
                    Console.WriteLine("Address: {0}", reply.Address.ToString());
                    Console.WriteLine("Roundtrip time: {0} ms", reply.RoundtripTime);
                    Console.WriteLine("Time to live: {0}", reply.Options.Ttl);
                    Console.WriteLine("Don't fragment: {0}", reply.Options.DontFragment);
                    Console.WriteLine("Buffer size: {0}", reply.Buffer.Length);
                    ret = true;
                }
                else
                {
                    Console.WriteLine("Ping failed: {0}", reply.Status.ToString());
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: {0}", ex.Message);
            }
            return ret;
        }

        public ActionResult agvSave(agvInfo formData)
        {
            agvInfo? temp_agvInfo = _db.agvInfo.Where(k => k.AgvId == formData.AgvId).FirstOrDefault();
            if (temp_agvInfo != null)
            {
                temp_agvInfo.AgvTier = formData.AgvTier;
                temp_agvInfo.AgvIP = formData.AgvIP;
                temp_agvInfo.AgvName = formData.AgvName;
            }
            else
            {
                agvInfo new_agvInfo = new agvInfo
                {
                    AgvId = formData.AgvId,
                    AgvIP = formData.AgvIP,
                    AgvName = formData.AgvName,
                    AgvTier = formData.AgvTier,
                };
                _db.agvInfo.Add(new_agvInfo);   
            }
            _db.SaveChanges();
            return RedirectToAction("DbSettings", "Build");
        }





        //mail Operations

        public ActionResult saveMail(string mailAddress)
        {
            _db.setMail.Add( new setMail { MailAddress = mailAddress });
            _db.SaveChanges();
            return RedirectToAction("DbSettings", "Build");
        }

        public ActionResult deleteMail(int id)
        {
            setMail? setMail = _db.setMail.Where(k => k.MailId == id).FirstOrDefault();
            if(setMail != null)
            {
                _db.setMail.Remove(setMail);
                _db.SaveChanges();
            }
            return RedirectToAction("DbSettings", "Build");
        }
    }
}
