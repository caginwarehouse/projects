﻿using QRSuite.Entity;
using QRSuite.Models;

namespace QRSuite.Controllers.CheckTools
{
    public class ChargeCheck
    {
        public Context _db;
        public ChargeCheck(Context db)
        {
            _db = db;
        }
        public static void checkChargeSlots()
        {

        }
    }
}
