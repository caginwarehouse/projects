﻿using QRSuite.Entity;

namespace QRSuite.Controllers.RosTools
{
    public class MapToRos
    {
        public Context _db;
        public MapToRos(Context db)
        {
            _db = db;
        }

        public List<agvInfo> UploadMapToAgv()
        {
            List<agvInfo> ret_agvList = new List<agvInfo>();

            List<agvInfo> agvInfos = new List<agvInfo>();
            List<mapPaths> mapPaths = new List<mapPaths>();
            List<mapPoints> mapPoints = new List<mapPoints>();
            agvInfos = _db.agvInfo.ToList();
            mapPaths = _db.mapPaths.ToList();
            mapPoints = _db.mapPoints.ToList();
            string mapNameValue = "Null";
            int mapIdValue = -1;
            string serverIp = "Null";
            mapInfo? mapName = _db.mapInfo.OrderByDescending(k => k.mapVersionId).FirstOrDefault();
            if(mapName != null)
            {
                mapNameValue = mapName.mapName;
                mapIdValue = mapName.mapVersionId;
                serverIp = mapName.serverIp;
            }
            var client = new Ros_Client();
            client.MapToXml(mapPaths, mapPoints, mapNameValue, mapIdValue, serverIp);
            foreach (var item in agvInfos)
            {
                if (client.ConnectToRos(item.AgvIP))
                {
                    client.UpdateMap();
                    client.Close();
                    ret_agvList.Add(item);
                }
                else
                {
                    continue;
                }
            }

            return ret_agvList;
        }
    }
}
