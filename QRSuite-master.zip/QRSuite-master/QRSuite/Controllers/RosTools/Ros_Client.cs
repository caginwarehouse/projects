﻿using Newtonsoft.Json;
using QRSuite.Entity;
using QRSuite.Models;
using System.Xml;
using System.Xml.Linq;
using WebSocketSharp;

namespace QRSuite.Controllers.RosTools
{
    public class Ros_Client
    {
        private WebSocket rosSocket;
        private string xml_Map;
        private string xml_Order;

        public Ros_Client()
        {
            xml_Map = String.Empty;
            xml_Order = String.Empty;
        }

        public void ConvertToXml(orderFile orderFile)
        {
            using (var stringWriter = new StringWriter())
            {
                using (var xmlWriter = XmlWriter.Create(stringWriter, new XmlWriterSettings { Indent = true }))
                {
                    xmlWriter.WriteStartElement("root");

                    xmlWriter.WriteStartElement("head");
                    // Serialize orderFile properties
                    xmlWriter.WriteElementString("hasError", orderFile.hasError.ToString());
                    xmlWriter.WriteElementString("hasLoop", orderFile.hasLoop.ToString());
                    xmlWriter.WriteElementString("beginLoopId", orderFile.beginLoopId.ToString());
                    xmlWriter.WriteElementString("endLoopId", orderFile.endLoopId.ToString());
                    xmlWriter.WriteElementString("departureQrId", orderFile.departureQrId.ToString());
                    xmlWriter.WriteEndElement();


                    // Serialize orderSets
                    xmlWriter.WriteStartElement("orderSets");
                    foreach (var kvp in orderFile.orderSets)
                    {
                        xmlWriter.WriteStartElement("orderSet");
                        xmlWriter.WriteAttributeString("id", kvp.Key.ToString());

                        foreach (var orderSet in kvp.Value)
                        {
                            xmlWriter.WriteStartElement("orderItem");
                            xmlWriter.WriteElementString("orderId", orderSet.orderId.ToString());
                            xmlWriter.WriteElementString("command", orderSet.command);
                            xmlWriter.WriteElementString("nextPoint", orderSet.nextPoint.ToString());
                            xmlWriter.WriteElementString("angle", orderSet.angle.ToString());
                            xmlWriter.WriteElementString("distance", orderSet.distance.ToString());
                            xmlWriter.WriteElementString("lockId", orderSet.lockId.ToString());
                            xmlWriter.WriteElementString("velocity", orderSet.velocity.ToString().Replace(',','.'));
                            xmlWriter.WriteEndElement(); // order
                        }
                        xmlWriter.WriteEndElement(); // orderSet
                    }
                    xmlWriter.WriteEndElement(); // orderSets

                    xmlWriter.WriteEndElement(); // orderFile
                    xmlWriter.Flush();

                    xml_Order = stringWriter.ToString();
                }
            }
        }

        public void MapToXml(List<mapPaths> mapPaths, List<mapPoints> mapPoints, string mapName, int mapId, string serverIp)
        {
            XElement root = new XElement("root");
            root.Add(new XElement("mapinfo",
                 new XElement("MapName", mapName),
                 new XElement("MapId", mapId),
                 new XElement("ServerIp", serverIp)
                 ));

            XElement pointElement = new XElement("points");
            foreach (var item in mapPoints)
            {
                pointElement.Add(new XElement("PointElement",
                    new XElement("Id", item.PointId),
                    new XElement("X", item.PointX),
                    new XElement("Y", item.PointY),
                    new XElement("Release", item.PointRelease),
                    new XElement("Operation", item.PointOperation),
                    new XElement("Safetymode", item.PointSafetyMode)
                ));
            }
            root.Add(pointElement);

            XElement pathElement = new XElement("paths");
            foreach (var item in mapPaths)
            {
                pathElement.Add(new XElement("PathElement",
                    new XElement("FromId", item.PathFromId),
                    new XElement("FromX", item.PathFromX),
                    new XElement("FromY", item.PathFromY),
                    new XElement("ToId", item.PathToId),
                    new XElement("ToX", item.PathToX),
                    new XElement("ToY", item.PathToY),
                    new XElement("speed", item.PathVelocity)
                ));
            }
            root.Add(pathElement);

            xml_Map = root.ToString();
        }

        public bool ConnectToRos(string ip)
        {
            bool retFlag = false;
            try
            {
                string ws_ip = "ws://" + ip + ":9090";
                rosSocket = new WebSocket(ws_ip);
                rosSocket.Connect();
                if(rosSocket.IsAlive)
                {
                    retFlag = true;
                }
            } catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return retFlag;
        }

        public void UpdateMap()
        {
            var serviceCall = new
            {
                op = "call_service",
                service = "/qr_comm/get_map",
                args = new
                {
                    file_name = "qr_robot",
                    xml_content = xml_Map
                },
                id = "call_service:/qr_comm/get_map"
            };

            // Serialize the request to JSON
            string jsonRequest = JsonConvert.SerializeObject(serviceCall);

            // Send the request
            rosSocket.Send(jsonRequest);
        }

        public void SendOrder()
        {
            var serviceCall = new
            {
                op = "call_service",
                service = "/qr_comm/get_orders",
                args = new
                {
                    file_name = "qr_robot",
                    xml_content = xml_Order
                },
                id = "call_service:/qr_comm/get_orders"
            };

            // Serialize the request to JSON
            string jsonRequest = JsonConvert.SerializeObject(serviceCall);
            // Send the request
            rosSocket.Send(jsonRequest);
        }

        public void Close()
        {
            rosSocket.Close();
        }
    }
}
