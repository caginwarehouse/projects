﻿using QRSuite.Entity;
using QRSuite.Models;
using System.Xml;

namespace QRSuite.Controllers.RosTools
{
    public class OrderToRos
    {
        public Context _db;
        public OrderToRos(Context db)
        {
            _db = db;
        }
      
        public static bool UploadOrderToRos(orderFile order, string ip)
        {
            var client = new Ros_Client();

            if (client.ConnectToRos(ip))
            {
                client.ConvertToXml(order);
                client.SendOrder(); 
                client.Close();
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
