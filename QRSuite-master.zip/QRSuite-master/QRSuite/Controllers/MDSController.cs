﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using QRSuite.Entity;

namespace QRSuite.Controllers
{
    public class MDSController : Controller
    {
        public Context _db;
        public MDSController(Context db)
        {
            _db = db;
        }
        public IActionResult RequestScreen()
        {
            return View();
        }
        public IActionResult SupplyScreen()
        {
            return View();
        }

        public IActionResult SupermarketDefination()
        {
            return View();
        }

        public IActionResult StationDefination()
        {
            return View();
        }

        public IActionResult MaterialDefination()
        {
            return View();
        }

        public ActionResult supermarketEdit(mdsSupermarket data)
        {
            if(data.SupermarketId == 0)
            {
                _db.mdsSupermarket.Add(data);
            } else if (data.SupermarketId > 0 && data.SupermarketName == "delete")
            {
                _db.mdsSupermarket.Remove(data);
            } else
            {
                mdsSupermarket? _mdsSupermarket = _db.mdsSupermarket.Where(k => k.SupermarketId == data.SupermarketId).FirstOrDefault();
                if(_mdsSupermarket != null)
                {
                    _mdsSupermarket.SupermarketName = data.SupermarketName;
                    _mdsSupermarket.SupermarketNamePoint = data.SupermarketNamePoint;
                }
            }
            _db.SaveChanges();

            return RedirectToAction("Index", "Home");
        }

        public ActionResult stationGroupEdit(mdsLines data)
        {
            if (data.station_group_id == 0)
            {
                _db.mdsLines.Add(data);
            }
            else if (data.station_group_id > 0 && data.station_group_name == "delete")
            {
                _db.mdsLines.Remove(data);
            }
            else
            {
                mdsLines? _mdsLine = _db.mdsLines.Where(k => k.station_group_id == data.station_group_id).FirstOrDefault();
                if (_mdsLine != null)
                {
                    _mdsLine.station_group_name = data.station_group_name;
                    _mdsLine.supermarket_id = data.supermarket_id;
                }
            }
            _db.SaveChanges();

            return RedirectToAction("Index", "Home");
        }

        public ActionResult stationEdit(mdsStation data)
        {
            mdsLines? _mdsLine = _db.mdsLines.Where(k => k.station_group_id == data.StationLineId).FirstOrDefault();
            if(_mdsLine != null)
            {
                data.StationLineName = _mdsLine.station_group_name;
            }
            if (data.StationId == 0)
            {
                _db.mdsStation.Add(data);
            }
            else if (data.StationId > 0 && data.StationName == "delete")
            {
                _db.mdsStation.Remove(data);
            }
            else
            {
                mdsStation? _mdsStation = _db.mdsStation.Where(k => k.StationId == data.StationId).FirstOrDefault();
                if (_mdsStation != null)
                {
                    _mdsStation.StationName = data.StationName;
                    _mdsStation.StationIdPoint = data.StationIdPoint;
                    _mdsStation.StationLineId = data.StationLineId;
                    _mdsStation.StationLineName = data.StationLineName;
                }
            }
            _db.SaveChanges();

            return RedirectToAction("Index", "Home");
        }

        public ActionResult materialEdit(mdsMaterial data)
        {
            mdsSupermarket? _mdsSupermarket = _db.mdsSupermarket.Where(k => k.SupermarketId == data.MaterialSupermarketId).FirstOrDefault();
            if (_mdsSupermarket != null)
            {
                data.MaterialSupermarketName = _mdsSupermarket.SupermarketName;
            }
            mdsLines? _mdsLine = _db.mdsLines.Where(k => k.station_group_id == data.MaterialLineId).FirstOrDefault();
            if (_mdsLine != null)
            {
                data.MaterialLineName = _mdsLine.station_group_name;
            }
            mdsStation? _mdsStation = _db.mdsStation.Where(k => k.StationId == data.MaterialStationId).FirstOrDefault();
            if (_mdsStation != null)
            {
                data.MaterialStationName = _mdsStation.StationName;
            }

            if (data.MaterialId == 0)
            {
                _db.mdsMaterial.Add(data);
            }
            else if (data.MaterialId > 0 && data.MaterialName == "delete")
            {
                _db.mdsMaterial.Remove(data);
            }
            else
            {
                mdsMaterial? _mdsMaterial = _db.mdsMaterial.Where(k => k.MaterialId == data.MaterialId).FirstOrDefault();
                if (_mdsMaterial != null)
                {
                    _mdsMaterial.MaterialName = data.MaterialName;
                    _mdsMaterial.MaterialSupermarketId = data.MaterialSupermarketId;
                    _mdsMaterial.MaterialSupermarketName = data.MaterialSupermarketName;
                    _mdsMaterial.MaterialLineId = data.MaterialLineId;
                    _mdsMaterial.MaterialLineName = data.MaterialLineName;
                    _mdsMaterial.MaterialStationId = data.MaterialStationId;
                    _mdsMaterial.MaterialStationName = data.MaterialStationName;
                }
            }
            _db.SaveChanges();

            return RedirectToAction("Index", "Home");
        }

        public ActionResult chargeEdit(agvCharge data)
        {
            if (data.DbId == 0)
            {
                _db.agvCharge.Add(data);
            }
            else if (data.DbId > 0 && data.Id == -1)
            {
                _db.agvCharge.Remove(data);
            }
            else
            {
                agvCharge? _agvCharge = _db.agvCharge.Where(k => k.DbId == data.DbId).FirstOrDefault();
                if (_agvCharge != null)
                {
                    _agvCharge.QRPointId = data.QRPointId;
                    _agvCharge.QRPointPreId = data.QRPointPreId;
                }
            }
            _db.SaveChanges();

            return RedirectToAction("Index", "Home");
        }

        public ActionResult agvEdit(agvInfo data)
        {

            if (data.AgvDbId == 0)
            {
                _db.agvInfo.Add(data);
            }
            else if (data.AgvDbId > 0 && data.AgvName == "delete")
            {
                _db.agvInfo.Remove(data);
            }
            else
            {
                agvInfo? _agvInfo = _db.agvInfo.Where(k => k.AgvDbId == data.AgvDbId).FirstOrDefault();
                if (_agvInfo != null)
                {
                    _agvInfo.AgvId = data.AgvId;
                    _agvInfo.AgvName = data.AgvName;
                    _agvInfo.AgvIP = data.AgvIP;
                    _agvInfo.AgvTier = data.AgvTier;
                }
            }
            _db.SaveChanges();

            return RedirectToAction("Index", "Home");
        }

        public ActionResult mailEdit(setMail data)
        {

            if (data.MailId == 0)
            {
                _db.setMail.Add(data);
            }
            else if (data.MailId > 0 && data.MailAddress == "delete")
            {
                _db.setMail.Remove(data);
            }
            _db.SaveChanges();

            return RedirectToAction("Index", "Home");
        }

    }
}
