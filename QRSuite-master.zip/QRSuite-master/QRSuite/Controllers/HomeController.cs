using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using QRSuite.Entity;
using QRSuite.Models;
using System.Diagnostics;

namespace QRSuite.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        public Context _db;
        public static bool connectionCheck = false;

        public HomeController(Context db, ILogger<HomeController> logger)
        {
            _db = db;
            _logger = logger;
        }

        public bool dbConnectionCheck()
        {
            connectionCheck = _db.Database.CanConnect();
            return connectionCheck;
        }

        public IActionResult Index()
        {
            MainModel mainModel = new QRSuite.Models.MainModel(_db);
            mainModel.mails = mainModel.getMails();
            mainModel.agvInfos = mainModel.getAgvInfos();
            mainModel.agvCharges = mainModel.getAgvCharges();
            mainModel.mapPoints = mainModel.getMapPoints();
            mainModel.mdsSupermarkets = mainModel.getSupermarkets();
            mainModel.mdsMaterials = mainModel.getMaterials();
            mainModel.mdsLines = mainModel.getLines();
            mainModel.mdsStations = mainModel.getStations();
            mainModel.setParams = mainModel.getSetParams();
            mainModel.PoOrders = mainModel.getOrderToRosThisYear();
            mainModel.PoOrdersQ1 = mainModel.getOrderToRosQ1();
            mainModel.PoOrdersQ2 = mainModel.getOrderToRosQ2();
            mainModel.PoOrdersQ3 = mainModel.getOrderToRosQ3();
            mainModel.PoOrdersQ4 = mainModel.getOrderToRosQ4();
            return View(mainModel);
        }

        public ActionResult setParam(int id,  string value)
        {
            setParam? param = _db.setParams.Where(k => k.paramId == id).FirstOrDefault();
            if(param != null)
            {
                param.ValueString = value;
            }
            _db.SaveChanges();
            return RedirectToAction("Index", "Home");
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
