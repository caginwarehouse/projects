﻿using QRSuite.Models;

namespace QRSuite.Controllers.CommandTools
{
    public class Add_Command
    {
        public static void addMove(ref List<orderSet> orderSetModel, ref int order_counter, double distance, int nextPoint, double velocity)
        {
            order_counter++;
            orderSet orderItem = new orderSet
            {
                orderId = order_counter,
                command = "move",
                distance = distance,
                nextPoint = nextPoint,
                velocity = velocity,
            };
            orderSetModel.Add(orderItem);
        }


        public static void addPivot(ref List<orderSet> orderSetModel, ref int order_counter, double angle)
        {
            order_counter++;
            orderSet orderItem = new orderSet
            {
                orderId = order_counter,
                command = "pivot",
                angle = angle,
            };
            orderSetModel.Add(orderItem);
        }

        public static void addOperation(ref List<orderSet> orderSetModel, ref int order_counter, string operation)
        {
            order_counter++;
            orderSet orderItem = new orderSet
            {
                orderId = order_counter,
                command = operation.ToLower(),
            };
            orderSetModel.Add(orderItem);
        }

        public static void addLock(ref List<orderSet> orderSetModel, ref int order_counter, string operation, int lockId)
        {
            order_counter++;
            orderSet orderItem = new orderSet
            {
                orderId = order_counter,
                command = operation.ToLower(),
                lockId = lockId
            };
            orderSetModel.Add(orderItem);
        }
    }
}
