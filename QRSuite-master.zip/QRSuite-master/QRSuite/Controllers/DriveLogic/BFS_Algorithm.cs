﻿namespace QRSuite.Controllers.DriveLogic
{
    public class BFS_Algorithm
    {
        public static List<int> BFSFindAlgorithm(Dictionary<int, List<int>> graph, int from, int to)
        {
            // Kuyruk ve ziyaret edilenler kümesi
            var queue = new Queue<Tuple<int, List<int>>>();
            var visited = new HashSet<int>();

            // Başlangıç düğümünü kuyruğa ekle
            queue.Enqueue(Tuple.Create(from, new List<int>() { from }));

            while (queue.Count > 0)
            {
                // Kuyruğun başındaki düğümü çıkar
                var current = queue.Dequeue();
                var node = current.Item1;
                var path = current.Item2;

                // Hedef düğüm bulundu mu?
                if (node == to)
                {
                    return path;
                }

                // Komşuları ziyaret et
                visited.Add(node);
                foreach (var neighbor in graph[node])
                {
                    if (!visited.Contains(neighbor))
                    {
                        var newPath = new List<int>(path);
                        newPath.Add(neighbor);
                        queue.Enqueue(Tuple.Create(neighbor, newPath));
                    }
                }
            }

            return null;
        }
    }
}
