﻿using QRSuite.Entity;
using QRSuite.Models;
using System.Reflection.Metadata;

namespace QRSuite.Controllers.DriveLogic
{
    public class Loop_Calculator
    {
        public static void CalculateLoop (ref orderFile OrderFile, List<mapPoints> points, int from, int to)
        {

            OrderFile.departureQrId = from;
            OrderFile.routePoints.AddRange([from, to]);

            while (true)
            {
                mapPoints? to_Point = points.Where(k => k.PointId == to).FirstOrDefault();
                if (to_Point != null)
                {
                    if (to_Point.PointRelease != 0)
                    {
                        if (OrderFile.routePoints.Contains(to_Point.PointRelease))
                        {
                            OrderFile.hasLoop = true;
                            OrderFile.endLoopId = OrderFile.routePoints.Count - 1;
                            OrderFile.routePoints.Add(to_Point.PointRelease);
                            OrderFile.beginLoopId = OrderFile.routePoints.IndexOf(to_Point.PointRelease);
                            break;
                        } else
                        {
                            OrderFile.routePoints.Add(to_Point.PointRelease);
                            to = to_Point.PointRelease;
                            continue;
                        }
                    }
                    else
                    {
                        break;
                    }
                }
            }

        }

    }
}
