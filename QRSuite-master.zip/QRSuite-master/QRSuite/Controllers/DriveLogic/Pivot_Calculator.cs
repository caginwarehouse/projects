﻿using QRSuite.Entity;
using QRSuite.Models;

namespace QRSuite.Controllers.DriveLogic
{
    public class Pivot_Calculator
    {
        public static double getPivotAngle(mapPoints firstPoint, mapPoints secondPoint)
        {
            if (firstPoint.PointY == secondPoint.PointY)
            {
                if (firstPoint.PointX < secondPoint.PointX)
                {
                    return 270 + firstPoint.PointSinAngleOffset;
                }
                else
                {
                    return 90 + firstPoint.PointASinAngleOffset;
                }
            }
            else if (firstPoint.PointX == secondPoint.PointX)
            {
                if (firstPoint.PointY < secondPoint.PointY)
                {
                    if (firstPoint.PointCosAngleOffset < 0)
                    {
                        return 360 + firstPoint.PointCosAngleOffset;
                    }
                    else
                    {
                        return 0 + firstPoint.PointCosAngleOffset;
                        }

                    }
                else
                {
                    return 180 + firstPoint.PointACosAngleOffset;
                }
            }
            return -1;
        }
    }
}
