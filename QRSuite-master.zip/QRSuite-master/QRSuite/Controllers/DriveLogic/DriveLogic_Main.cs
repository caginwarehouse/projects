﻿using Newtonsoft.Json.Serialization;
using Newtonsoft.Json;
using QRSuite.Controllers.CommandTools;
using QRSuite.Models;
using QRSuite.Entity;
using static System.Net.Mime.MediaTypeNames;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Humanizer;

namespace QRSuite.Controllers.DriveLogic
{
    public class DriveLogic_Main
    {
        public static orderFile chargeOrder(List<mapPoints> points, List<mapPaths> paths, int from, int chargePreQrId, int chargeQrId, int pivot_tolerance)
        {
            orderFile returnOrderFile = new orderFile();

            if (points.Count < 2 || paths.Count < 1 || from == chargePreQrId || from == chargeQrId || chargePreQrId == chargeQrId)
                return returnOrderFile;
            Loop_Calculator.CalculateLoop(ref returnOrderFile, points, from, chargeQrId);
            Route_Calculator route_Calculator = new Route_Calculator(points, paths);
            for (int i = 0; i < returnOrderFile.routePoints.Count - 1; i++)
            {
                List<orderSet> orderSetModel = new List<orderSet>();
                int order_counter = 0;
                List<mapPoints> route = route_Calculator.RoutePlanner(returnOrderFile.routePoints[i], returnOrderFile.routePoints[i + 1]);
                if (route.Count == 0)
                {
                    returnOrderFile.hasError = true;
                    var jsonSettings2 = new JsonSerializerSettings { ContractResolver = new CamelCasePropertyNamesContractResolver() };
                    string jsonResponse2 = JsonConvert.SerializeObject(returnOrderFile, jsonSettings2);
                    return returnOrderFile;
                }

                double distance = 0.0;
                double initial_pivot_angle = Pivot_Calculator.getPivotAngle(route[0], route[1]);
                //first pivot
                Add_Command.addPivot(ref orderSetModel, ref order_counter, initial_pivot_angle);

                for (int j = 0; j < route.Count - 1; j++)
                {
                    double tempPivotAngle = Pivot_Calculator.getPivotAngle(route[j], route[j + 1]);
                    double angle_difference = Math.Abs(tempPivotAngle - initial_pivot_angle);

                    if (angle_difference > 180)
                    {
                        angle_difference = 360 - angle_difference;
                    }

                    //check pivot  angle
                    if (angle_difference > pivot_tolerance)
                    {
                        initial_pivot_angle = tempPivotAngle;
                        Add_Command.addPivot(ref orderSetModel, ref order_counter, tempPivotAngle);
                    }

                    //check lock
                    if (route[j].PointOperation.Contains("Key"))
                    {
                        string[] lockOp = route[j].PointOperation.Split('-');
                        Add_Command.addLock(ref orderSetModel, ref order_counter, lockOp[0], Convert.ToInt32(lockOp[1]));
                    }

                    //move command
                    if (route[j].PointX == route[j + 1].PointX)
                    {
                        distance = Math.Abs(route[j + 1].PointY - route[j].PointY);
                    }
                    else
                    {
                        distance = Math.Abs(route[j + 1].PointX - route[j].PointX);
                    }
                    mapPaths? path = paths.Find(k => k.PathFromId == route[j].PointId && k.PathToId == route[j + 1].PointId);
                    double _velocity = -1;
                    if (path != null)
                    {
                        _velocity = path.PathVelocity / 10;
                    }
                    Add_Command.addMove(ref orderSetModel, ref order_counter, distance, route[j + 1].PointId, _velocity);

                    //After the last move
                    if (route[j + 1].PointId == chargePreQrId)
                    {
                        if(angle_difference == 180)
                        {
                            Add_Command.addPivot(ref orderSetModel, ref order_counter, 0);
                        } else if(angle_difference == 0)
                        {
                            Add_Command.addPivot(ref orderSetModel, ref order_counter, 180);
                        } else if (angle_difference == 90)
                        {
                            Add_Command.addPivot(ref orderSetModel, ref order_counter, 270);
                        } else if (angle_difference == 270)
                        {
                            Add_Command.addPivot(ref orderSetModel, ref order_counter, 90);
                        }

                        Add_Command.addMove(ref orderSetModel, ref order_counter, distance, route[j + 2].PointId, _velocity * -1);
                        break;
                    }
                }
                returnOrderFile.orderSets.Add(i, orderSetModel);
            }
            return returnOrderFile;
        }




        public static orderFile driveLogicMain(List<mapPoints> points, List<mapPaths> paths, int from, int to, int pivot_tolerance)
        {
            orderFile returnOrderFile = new orderFile();
            ////point array check
            if (points.Count < 2 || paths.Count < 1 || from == to)
                return returnOrderFile;

            Loop_Calculator.CalculateLoop(ref returnOrderFile, points, from, to);
            Route_Calculator route_Calculator = new Route_Calculator(points, paths);

            for (int i = 0; i < returnOrderFile.routePoints.Count - 1; i++)
            {
                List<orderSet> orderSetModel = new List<orderSet>();
                int order_counter = 0;
                //route points as MapPoint
                List<mapPoints> route = route_Calculator.RoutePlanner(returnOrderFile.routePoints[i], returnOrderFile.routePoints[i + 1]);
                if (route.Count == 0)
                {
                    returnOrderFile.hasError = true;
                    var jsonSettings2 = new JsonSerializerSettings { ContractResolver = new CamelCasePropertyNamesContractResolver() };
                    string jsonResponse2 = JsonConvert.SerializeObject(returnOrderFile, jsonSettings2);
                    return returnOrderFile;
                }

                double distance = 0.0;
                double initial_pivot_angle = Pivot_Calculator.getPivotAngle(route[0], route[1]);

                //first pivot
                Add_Command.addPivot(ref orderSetModel, ref order_counter, initial_pivot_angle);
                for (int j = 0; j < route.Count - 1; j++)
                {
                    to = route[route.Count - 1].PointId;
                    double tempPivotAngle = Pivot_Calculator.getPivotAngle(route[j], route[j + 1]);
                    double angle_difference = Math.Abs(tempPivotAngle - initial_pivot_angle);

                    if (angle_difference > 180)
                    {
                        angle_difference = 360 - angle_difference;
                    }

                    //check pivot  angle
                    if (angle_difference > pivot_tolerance)
                    {
                        initial_pivot_angle = tempPivotAngle;
                        Add_Command.addPivot(ref orderSetModel, ref order_counter, tempPivotAngle);
                    }

                    //check lock
                    if (route[j].PointOperation.Contains("Key"))
                    {
                        string[] lockOp = route[j].PointOperation.Split('-');
                        Add_Command.addLock(ref orderSetModel, ref order_counter, lockOp[0], Convert.ToInt32(lockOp[1]));
                    }
                    
                    //move command
                    if (route[j].PointX == route[j + 1].PointX)
                    {
                        distance = Math.Abs(route[j + 1].PointY - route[j].PointY);
                    }
                    else
                    {
                        distance = Math.Abs(route[j + 1].PointX - route[j].PointX);
                    }
                    mapPaths? path = paths.Find(k => k.PathFromId == route[j].PointId && k.PathToId == route[j + 1].PointId);
                    double _velocity = -1;
                    if (path != null)
                    {
                        _velocity = path.PathVelocity / 10;
                    }
                    Add_Command.addMove(ref orderSetModel, ref order_counter, distance, route[j + 1].PointId, _velocity);

                    //After the last move
                    if (route[j + 1].PointId == to && route[j + 1].PointOperation != "NoOperation")
                    {
                        if (route[j + 1].PointOperation.Contains("Key") != true)
                        {
                            Add_Command.addOperation(ref orderSetModel, ref order_counter, route[j + 1].PointOperation);
                        }
                        else
                        {
                            string[] lockOp = route[j + 1].PointOperation.Split('-');
                            Add_Command.addLock(ref orderSetModel, ref order_counter, lockOp[0], Convert.ToInt32(lockOp[1]));
                        }
                    }
                }
                returnOrderFile.orderSets.Add(i, orderSetModel);
            }

            return returnOrderFile;
        }
    }
}
