﻿using QRSuite.Entity;
using QRSuite.Models;

namespace QRSuite.Controllers.DriveLogic
{
    public class Route_Calculator
    {
        protected List<mapPoints> points = new List<mapPoints>();
        protected List<mapPaths> paths = new List<mapPaths>();

        public Route_Calculator(List<mapPoints> points_input, List<mapPaths> paths_input)
        {
            points.AddRange(points_input);
            paths.AddRange(paths_input);
        }

        public List<mapPoints> RoutePlanner(int from, int to)
        {
            Dictionary<int, List<int>> graph = new Dictionary<int, List<int>>();
            List<mapPoints> returnPoints = new List<mapPoints>();
            //fill graph 
            foreach (mapPoints itemPoint in points)
            {
                List<int> tempList = new List<int>();
                paths.FindAll(k => k.PathFromId == itemPoint.PointId).ForEach(k =>
                {
                    tempList.Add(k.PathToId);
                });
                graph.Add(itemPoint.PointId, tempList);
            }

            List<int> route_Ints = BFS_Algorithm.BFSFindAlgorithm(graph, from, to);
            if(route_Ints == null)
            {
                return returnPoints;
            }
            foreach (int item in route_Ints)
            {
                mapPoints? tempPoint = points.Find(k => k.PointId == item);
                if(tempPoint != null)
                { returnPoints.Add(tempPoint); }
            }
            return returnPoints;
        }
    }
}
