﻿namespace QRSuite.Models
{
    public class ChargeSlotModel
    {
        public int DbId { get; set; }
        public int Id { get; set; }
        public int QRPointId { get; set; }
        public string SlotStatus { get; set; } = string.Empty;
        public int AgvId { get; set; }
        public int AgvName { get; set; }
        public string AgvIp { get; set; } = string.Empty;
    }
}
