﻿using QRSuite.Entity;

namespace QRSuite.Models
{
    //public class MapPoint
    //{
    //    public int Id { get; set; }
    //    public double X { get; set; }
    //    public double Y { get; set; }
    //    public int release { get; set; }
    //    public string operation { get; set; } = string.Empty;
    //    public string safetymode { get; set; } = string.Empty;
    //}
    //public class MapPath
    //{
    //    public string Id { get; set; } = string.Empty;
    //    public int FromId { get; set; }
    //    public double FromX { get; set; }
    //    public double FromY { get; set; }
    //    public int ToId { get; set; }
    //    public double ToX { get; set; }
    //    public double ToY { get; set; }
    //    public int Speed { get; set; }
    //    public int Lock { get; set; }
    //}
    public class MapModel
    {
        public string MapName { get; set; } = "default";
        public int MapLock { get; set; } = 0; 
        public int DefaultSpeed { get; set; } = 10; 
        public List<mapPoints> MapPoints { get; set; } = new List<mapPoints>();
        public List<mapPaths> MapPaths { get; set; } = new List<mapPaths>();
    }
}
