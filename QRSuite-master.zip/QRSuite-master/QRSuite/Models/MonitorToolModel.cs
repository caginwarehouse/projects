﻿using QRSuite.Entity;

namespace QRSuite.Models
{
    public class MonitorToolModel
    {
        public List<agvInfo> agvInfos = new List<agvInfo>();
        public List<mapPoints> mapPoints = new List<mapPoints>();
        public List<mapPaths> mapPaths = new List<mapPaths>();
        public List<setParam> setParams = new List<setParam>();
        public List<agvCharge> agvCharges = new List<agvCharge>();
    }
}
