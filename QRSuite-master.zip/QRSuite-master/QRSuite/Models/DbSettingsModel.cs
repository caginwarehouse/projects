﻿using QRSuite.Entity;

namespace QRSuite.Models
{
    public class DbSettingsModel
    {
        public mapInfo mapInfos = new mapInfo();

        public List<agvInfo> agvInfos = new List<agvInfo>();

        public List<setMail> mails = new List<setMail>();
        public List<logMapToRos> logMapToRos = new List<logMapToRos>();
        public int mapPointCount { get; set; }
        public int mapPathCount { get; set; }
    }
}
