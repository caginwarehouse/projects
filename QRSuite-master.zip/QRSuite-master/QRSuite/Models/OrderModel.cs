﻿namespace QRSuite.Models
{

    public class orderFile
    {
        public bool hasError { get; set; } = false;
        public bool hasLoop { get; set; } = false;
        public int beginLoopId { get; set; } = -1;
        public int endLoopId { get; set; } = -1;
        public int departureQrId { get; set; } = -1;

        public List<int> routePoints = new List<int>();

        public Dictionary<int, List<orderSet>> orderSets = new Dictionary<int, List<orderSet>>();
    }

    public class orderSet
    {
        public int orderId { get; set; } = 0;
        public string command { get; set; } = string.Empty;
        public int nextPoint { get; set; } = 0;
        public double angle { get; set; } = 0;
        public double distance { get; set; } = 0.00;
        public int lockId { get; set; } = 0;
        public double velocity { get; set; } = 0.0;
    }
}
