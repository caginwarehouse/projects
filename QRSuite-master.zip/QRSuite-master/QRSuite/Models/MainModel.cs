﻿using QRSuite.Entity;

namespace QRSuite.Models
{
    public class MainModel
    {
        public Context db;
        public MainModel(Context _db)
        {
            db = _db;
        }

        public List<logOrderToRos> PoOrders = new List<logOrderToRos>();

        public List<logOrderToRos> PoOrdersQ1 = new List<logOrderToRos>();
        public List<logOrderToRos> PoOrdersQ2 = new List<logOrderToRos>();
        public List<logOrderToRos> PoOrdersQ3 = new List<logOrderToRos>();
        public List<logOrderToRos> PoOrdersQ4 = new List<logOrderToRos>();

        
        
        public List<logMapToRos> logMapToRos = new List<logMapToRos>();
        public List<mapPoints> mapPoints = new List<mapPoints>();

        public List<mdsSupermarket> mdsSupermarkets = new List<mdsSupermarket>();
        public List<mdsMaterial> mdsMaterials = new List<mdsMaterial>();
        public List<mdsLines> mdsLines = new List<mdsLines>();
        public List<mdsStation> mdsStations = new List<mdsStation>();
        public List<agvCharge> agvCharges = new List<agvCharge>();

        public List<agvInfo> agvInfos = new List<agvInfo>();
        public List<setMail> mails = new List<setMail>();
        public List<setParam> setParams = new List<setParam>();



        public List<logOrderToRos> getOrderToRosThisYear()
        {
            DateTime dt = DateTime.Now;
            return db.logOrderToRos.Where(k => k.PoBeginTimestamp.Year == dt.Year).ToList();
        }

        public List<logOrderToRos> getOrderbyDate(DateTime dt)
        {
            return db.logOrderToRos.Where(k => k.PoBeginTimestamp.Date == dt.Date).ToList();
        }

        public List<logOrderToRos> getOrderToRosQ1()
        {
            DateTime dt = DateTime.Now;
            return db.logOrderToRos.Where(k => k.PoBeginTimestamp.Year == dt.Year && (k.PoBeginTimestamp.Month == 1 || k.PoBeginTimestamp.Month == 2 || k.PoBeginTimestamp.Month == 3)).ToList();
        }

        public List<logOrderToRos> getOrderToRosQ2()
        {
            DateTime dt = DateTime.Now;
            return db.logOrderToRos.Where(k => k.PoBeginTimestamp.Year == dt.Year && (k.PoBeginTimestamp.Month == 4 || k.PoBeginTimestamp.Month == 5 || k.PoBeginTimestamp.Month == 6)).ToList();
        }

        public List<logOrderToRos> getOrderToRosQ3()
        {
            DateTime dt = DateTime.Now;
            return db.logOrderToRos.Where(k => k.PoBeginTimestamp.Year == dt.Year && (k.PoBeginTimestamp.Month == 7 || k.PoBeginTimestamp.Month == 8 || k.PoBeginTimestamp.Month == 9)).ToList();
        }

        public List<logOrderToRos> getOrderToRosQ4()
        {
            DateTime dt = DateTime.Now;
            return db.logOrderToRos.Where(k => k.PoBeginTimestamp.Year == dt.Year && (k.PoBeginTimestamp.Month == 10 || k.PoBeginTimestamp.Month == 11 || k.PoBeginTimestamp.Month == 12)).ToList();
        }

        public List<logMapToRos> getMapToRos()
        {
            return db.logMapToRos.ToList();
        }

        public List<logOrderToRos> getOrders()
        {
            return db.logOrderToRos.ToList();
        }

        public List<mapPoints> getMapPoints()
        {
            return db.mapPoints.ToList();
        }

        public List<mdsSupermarket> getSupermarkets()
        {
            return db.mdsSupermarket.ToList();
        }
        public List<mdsMaterial> getMaterials()
        {
            return db.mdsMaterial.ToList();
        }
        public List<mdsLines> getLines()
        {
            return db.mdsLines.ToList();
        }
        public List<mdsStation> getStations()
        {
            return db.mdsStation.ToList();
        }

        public List<agvCharge> getAgvCharges()
        {
            return db.agvCharge.ToList();
        }
        public List<agvInfo> getAgvInfos()
        {
            return db.agvInfo.ToList();
        }
        public List<setMail> getMails()
        {
            return db.setMail.ToList();
        }

        public List<setParam> getSetParams()
        {
            return db.setParams.ToList();
        }
    }
}
