﻿namespace QRSuite.Models
{
    public class LockManagerModel
    {
        public Dictionary<int, bool> lockValues { get; set; } = new Dictionary<int, bool>();
    }
}
