﻿using QRSuite.Entity;

namespace QRSuite.Models
{
    public class supermarketDeliveryInfo
    {
        public int deliveryCount { get; set; } = 0;
        public TimeSpan loadDuration { get; set; } = TimeSpan.Zero;
    }
    public class DeliveryReportModel
    {
        public Dictionary<mdsSupermarket, supermarketDeliveryInfo> deliveryInfo = new Dictionary<mdsSupermarket, supermarketDeliveryInfo>();
    }
}
