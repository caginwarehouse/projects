﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace agv_delivery_tracker
{
    [Serializable]
    public class ErrorMsgs
    {
        public int pointer;
        public UInt16 NumberofErrors;
        public UInt16 NameStringLength;
        public string? Name;
        public UInt16 Id;
        public UInt16 Value;
    }

    [Serializable]
    public class ProductionStatus
    {
        public int pointer;
        public UInt16 numberOfProductionOrders;
        public UInt16 NameStringLength;
        public string? Name;
        public UInt32 Id;
        public Int32 TargetSymbol;
        public UInt16 AssignedToMachineId;
        public Int32 PickupSymbol;
        public Int32 ItemTypeToDeliver;
        public Byte CurrentStatus;
        public Byte ExecutionStatus;
    }

    public class agvinfo
    {
        /*Agv status possibilities
        0-> from supermarket to target
        1-> from target to supermarket
         */
        public int target { get; set; }
        public bool status { get; set; } = false;
        public DateTime toMarketTime { get; set; }
        public DateTime polePosTime { get; set; }
        public int supermarket { get; set; }
        public DateTime dropTime { get; set; }
    }

    class ProgramTools
    {

    }
}



//DEBUG STRINGS

////FRAME DEBUG
//Console.WriteLine("{0:D}, {1:D}", message_id, BitConverter.ToUInt16(receiveBuffer, buffer_pointer + 7));
//buffer_pointer += (BitConverter.ToUInt16(receiveBuffer, buffer_pointer + 7));
//buffer_pointer += 9; // pass frame

//flush receive buffer
//Buffer.BlockCopy(empty_array, 0, receiveBuffer, 0, client.ReceiveBufferSize);