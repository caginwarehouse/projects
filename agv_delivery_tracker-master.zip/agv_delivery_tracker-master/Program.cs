﻿using System.Net.Sockets;
using System.Buffers;
using System.Reflection.PortableExecutable;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using agv_delivery_tracker.Db;
using System.Text;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq.Expressions;

namespace agv_delivery_tracker
{
    class Program
    {
        static void tryConnect(ref TcpClient tcpClient)
        {
            try
            {
                //tcpClient.Connect("10.106.10.119", 8015); // ANKARA
                tcpClient.Connect("10.114.0.47", 8015); // BOLU
                //tcpClient.Connect("10.134.10.133", 8015); // Çayırova
                //tcpClient.Connect("127.0.0.1", 33477); // Local
            }
            catch (SocketException ex)
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.Write("Error : Connection Fail. Ex:");
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine(ex.ToString());
            }
            finally {
                if(!tcpClient.Connected)
                {
                    tcpClient.Close();
                    Thread.Sleep(5000);
                    tryConnect(ref tcpClient); //recursion
                }
                Console.ForegroundColor = ConsoleColor.DarkGreen;
                Console.WriteLine("Connected!");
                Console.ForegroundColor = ConsoleColor.White;
            }  
        }
        
        static void Main(string [] args)
        {
            TcpClient client = new TcpClient();
            Console.WriteLine("Connecting....");
            tryConnect(ref client);

            NetworkStream stream = client.GetStream();

            Dictionary<int, agvinfo> tracking_agvs = new Dictionary<int, agvinfo>();
            ProductionStatus productionStatus = new ProductionStatus();
            ErrorMsgs errorMsgs = new ErrorMsgs();

            int buffer_pointer = 0;
            int read_count = 0;
            int available_amount = 0;
            int message_id = 0;
            int remainBufferPointer = 0;
            int message_length = 0;
            
            byte[] receiveBuffer = new byte[client.ReceiveBufferSize];
            byte[] remainReceiveBuffer = new byte[client.ReceiveBufferSize];

            while (true)
            {
                while (client.Available < 300)
                {
                    System.Threading.Thread.Sleep(1000);
                    if(client.Available == 0)
                    {
                        if(!client.Connected)
                        {
                            client.Close();
                            Console.ForegroundColor = ConsoleColor.DarkYellow;
                            Console.WriteLine("Warning : Connection Problem. Trying connect again!");
                            Console.ForegroundColor = ConsoleColor.White;
                            tryConnect(ref client);
                            continue;
                        }
                        Console.ForegroundColor = ConsoleColor.DarkYellow;
                        Console.WriteLine("Warning : Navithor didn't send anything within 1 second!");
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                }
                available_amount = client.Available; 
                //Console.WriteLine("Readed {0:D} Bytes.", available_amount);
                read_count = stream.Read(receiveBuffer, 0, available_amount);
                buffer_pointer = 0;
                if (remainBufferPointer > 0)
                {
                    // add receiveBuffer to end of the remainReceiveBuffer 
                    Buffer.BlockCopy(receiveBuffer, 0, remainReceiveBuffer, remainBufferPointer, read_count);
                    // move all data from remainReceiveBuffer to receiveBuffer
                    Buffer.BlockCopy(remainReceiveBuffer, 0, receiveBuffer, 0, read_count + remainBufferPointer);
                    // clear remain buffer pointer
                    read_count += remainBufferPointer;
                    remainBufferPointer = 0;
                }

                // Chunk process
                while ((read_count - buffer_pointer) > 0)
                {
                    if ((read_count - buffer_pointer) < 9) // check frame existence
                    {
                        remainBufferPointer = (read_count - buffer_pointer);
                        Buffer.BlockCopy(receiveBuffer, buffer_pointer, remainReceiveBuffer, 0, remainBufferPointer);
                        buffer_pointer = read_count;
                        break;
                    }

                    if (BitConverter.ToUInt16(receiveBuffer, buffer_pointer + 7) > (read_count - buffer_pointer - 9)) //message exist check
                    {
                        remainBufferPointer = (read_count - buffer_pointer);
                        Buffer.BlockCopy(receiveBuffer, buffer_pointer, remainReceiveBuffer, 0, remainBufferPointer);
                        buffer_pointer = read_count;
                        break;
                    }

                    message_id = BitConverter.ToUInt16(receiveBuffer, buffer_pointer);
                    
                    message_length = (BitConverter.ToUInt16(receiveBuffer, buffer_pointer + 7)); //take message length before pass frame
                    buffer_pointer += 9; // PASS FRAME


                    //MESSAGE PARSING SECTION
                    switch (message_id)
                    {
                        case 310:
                            Console.WriteLine("Passed {0:D} Message!", message_id);
                            Task_310(receiveBuffer, buffer_pointer, ref tracking_agvs);
                            break;
                        case 309:
                            Console.WriteLine("Passed {0:D} Message!", message_id);
                            Task_309(receiveBuffer, buffer_pointer, ref errorMsgs);
                            break;
                        case 313:
                            Console.WriteLine("Passed {0:D} Message!", message_id);
                            Task_313(receiveBuffer, buffer_pointer, ref productionStatus, ref tracking_agvs);
                            break;
                        default:
                            Console.WriteLine("Passed {0:D} Message!", message_id);
                            continue;
                    }


                    buffer_pointer += message_length; // pass to other message
                }
            }
        }

        public static void Task_310(byte[] receiveBuffer, int buffer_pointer, ref Dictionary<int, agvinfo> tracking_agvs)
        {
            var db = new agv_delivery_tracker.Db.BoluRequestContext();
            var supermarket_points = db.Supermarkets.ToList();

            int machine_id = BitConverter.ToUInt16(receiveBuffer, buffer_pointer);
            //Console.WriteLine("Machine Id-> {0:D}", machine_id);
            //Console.WriteLine("Debug-> {0:D}; Last {4:D}, Target {3:D}, AtTargetPointStatus {1:D}, AtLastPointStatus {2:D}", machine_id, receiveBuffer[buffer_pointer + 57], receiveBuffer[buffer_pointer + 52], BitConverter.ToInt32(receiveBuffer, buffer_pointer + 53), BitConverter.ToInt32(receiveBuffer, buffer_pointer + 48));

                //Fill Array for tracking AGVs
                if (!tracking_agvs.ContainsKey(machine_id))
                {
                    //+48-> LastPoint -> 1(supermarket), +52 -> AtLastPoint , +57-> AtTargetPoint 
                    foreach (var item in supermarket_points)
                    {
                        if (BitConverter.ToInt32(receiveBuffer, buffer_pointer + 48) == item.SupermarketSymbolicPoint && receiveBuffer[buffer_pointer + 52] == 0x00 && BitConverter.ToInt32(receiveBuffer, buffer_pointer + 53) > 1)
                        {
                            tracking_agvs.Add(machine_id, new agvinfo() {   target = BitConverter.ToInt32(receiveBuffer, buffer_pointer + 53),
                                                                            status = false,
                                                                            supermarket = BitConverter.ToInt32(receiveBuffer, buffer_pointer + 48),
                                                                            dropTime = DateTime.MinValue,
                                                                            toMarketTime = DateTime.MinValue,
                                                                            polePosTime = DateTime.MinValue });
                            //Console.WriteLine("{0:D} is going to {1:D} target from {2:D} supermarket", machine_id, BitConverter.ToInt32(receiveBuffer, buffer_pointer + 53), BitConverter.ToInt32(receiveBuffer, buffer_pointer + 48));
                        }
                    }
                }
                else
                {
                    //+53-> TargetPoint -> 1(supermarket), +52 -> AtLastPoint , +57-> AtTargetPoint 
                    if (tracking_agvs[machine_id].status == false)
                    {
                        // TARGET adaptive oldu
                        if (BitConverter.ToInt32(receiveBuffer, buffer_pointer + 53) == tracking_agvs[machine_id].supermarket && receiveBuffer[buffer_pointer + 52] == 0x00 && receiveBuffer[buffer_pointer + 57] == 0x00)
                        {

                            Console.WriteLine("{0:D} delivered and going back to market from {1:D} target", machine_id, BitConverter.ToInt32(receiveBuffer, buffer_pointer + 48));
                            tracking_agvs[machine_id].status = true;
                            if (tracking_agvs[machine_id].dropTime == DateTime.MinValue)
                                tracking_agvs[machine_id].dropTime = DateTime.Now;
                            tracking_agvs[machine_id].toMarketTime = DateTime.Now;
                        }
                    }
                    else
                    {
                        //Console.WriteLine("Debug-> {0:D}; Target {3:D}, AtTargetPointStatus {1:D}, AtLastPointStatus {2:D}", machine_id, receiveBuffer[buffer_pointer + 57], receiveBuffer[buffer_pointer + 52], BitConverter.ToInt32(receiveBuffer, buffer_pointer + 53));


                        //pole position time    
                        if (receiveBuffer[buffer_pointer + 52] == 0x01 && receiveBuffer[buffer_pointer + 57] == 0x01)
                        {
                            tracking_agvs[machine_id].polePosTime = DateTime.Now;
                            Console.WriteLine("{0:D} reached supermarket", machine_id, BitConverter.ToInt32(receiveBuffer, buffer_pointer + 48));
                            //db write with timestamp
                            try
                            {
                                db.Deliveries.Add(new Delivery() { MachineId = machine_id, DeliveredTargetId = tracking_agvs[machine_id].target, DropTime = tracking_agvs[machine_id].dropTime, ToMarketTime = tracking_agvs[machine_id].toMarketTime, PolePosTime = tracking_agvs[machine_id].polePosTime });

                                db.SaveChanges();
                            }
                            catch (Exception e)
                            {
                                Console.ForegroundColor = ConsoleColor.DarkRed;
                                Console.Write("Error : Connection Fail. Ex:");
                                Console.ForegroundColor = ConsoleColor.White;
                                Console.WriteLine(e.GetType());
                                Console.WriteLine(e.Message);
                                Console.WriteLine(e.InnerException.Message);
                            }
                            tracking_agvs.Remove(machine_id);
                        }
                    }
                }
        }

        public static void Task_309(byte[] receiveBuffer, int buffer_pointer, ref ErrorMsgs errorMsgs)
        {

            errorMsgs.pointer = buffer_pointer;
            errorMsgs.NumberofErrors = BitConverter.ToUInt16(receiveBuffer, errorMsgs.pointer);
            errorMsgs.pointer += 2; // passed NumberofErrors !!!!
            //value 1 warning
            while (errorMsgs.NumberofErrors-- > 0)
            {
                errorMsgs.NameStringLength = BitConverter.ToUInt16(receiveBuffer, errorMsgs.pointer);
                errorMsgs.Name = Encoding.Default.GetString(receiveBuffer, errorMsgs.pointer + 2, errorMsgs.NameStringLength);
                errorMsgs.pointer += errorMsgs.NameStringLength + 2; // passed NameStringLength + Name !!!
                //other props
                errorMsgs.Id = BitConverter.ToUInt16(receiveBuffer, errorMsgs.pointer);
                errorMsgs.Value = BitConverter.ToUInt16(receiveBuffer, errorMsgs.pointer + 2);

                //Console.ForegroundColor = ConsoleColor.Red;
                //Console.WriteLine("-->{0:D}", errorMsgs.NumberofErrors);
                //Console.WriteLine("Msg->{0:D}, id->{1:D}, value->{2:D}", errorMsgs.Name, errorMsgs.Id, errorMsgs.Value);
                //Console.ForegroundColor = ConsoleColor.White;

                errorMsgs.pointer += 4;
            }
    }

        public static void Task_313(byte[] receiveBuffer, int buffer_pointer, ref ProductionStatus productionStatus, ref Dictionary<int, agvinfo> tracking_agvs)
        {
            productionStatus.pointer = buffer_pointer;
            productionStatus.numberOfProductionOrders = BitConverter.ToUInt16(receiveBuffer, productionStatus.pointer);
            productionStatus.pointer += 2;

            while (productionStatus.numberOfProductionOrders-- > 0)
            {
                productionStatus.NameStringLength = BitConverter.ToUInt16(receiveBuffer, productionStatus.pointer);
                productionStatus.Name = Encoding.Default.GetString(receiveBuffer, productionStatus.pointer + 2, productionStatus.NameStringLength);
                productionStatus.pointer += productionStatus.NameStringLength + 2; //pass NameLength + Name !!!
                // other props
                productionStatus.Id = BitConverter.ToUInt32(receiveBuffer, productionStatus.pointer);
                productionStatus.TargetSymbol = BitConverter.ToInt32(receiveBuffer, productionStatus.pointer + 4);
                productionStatus.AssignedToMachineId = BitConverter.ToUInt16(receiveBuffer, productionStatus.pointer + 8);
                productionStatus.PickupSymbol = BitConverter.ToInt32(receiveBuffer, productionStatus.pointer + 10);
                productionStatus.ItemTypeToDeliver = BitConverter.ToInt32(receiveBuffer, productionStatus.pointer + 14);
                productionStatus.CurrentStatus = receiveBuffer[productionStatus.pointer + 18];
                productionStatus.ExecutionStatus = receiveBuffer[productionStatus.pointer + 19];
                Console.WriteLine("Msg-> {0}, id->{1:D}, target->{2:D}, machine_id->{3:D}, CS->0x{4:X}, ES->0x{5:X}", productionStatus.Name, productionStatus.Id, productionStatus.TargetSymbol, productionStatus.AssignedToMachineId, productionStatus.CurrentStatus, productionStatus.ExecutionStatus);
                Console.WriteLine("MachineId-> {0:D}", productionStatus.AssignedToMachineId);
                if (tracking_agvs.ContainsKey(productionStatus.AssignedToMachineId) && !tracking_agvs[productionStatus.AssignedToMachineId].status)
                {
                    Console.ForegroundColor = ConsoleColor.DarkYellow;
                    Console.WriteLine("Msg-> {0}, id->{1:D}, target->{2:D}, machine_id->{3:D}, CS->0x{4:X}, ES->0x{5:X}", productionStatus.Name, productionStatus.Id, productionStatus.TargetSymbol, productionStatus.AssignedToMachineId, productionStatus.CurrentStatus, productionStatus.ExecutionStatus);
                    Console.ForegroundColor = ConsoleColor.White;
                    if (productionStatus.CurrentStatus == 0x03 && productionStatus.ExecutionStatus == 0x09 && tracking_agvs[productionStatus.AssignedToMachineId].dropTime == DateTime.MinValue)
                    {
                        tracking_agvs[productionStatus.AssignedToMachineId].dropTime = DateTime.Now;
                        Console.WriteLine("{0:D} dropped", productionStatus.AssignedToMachineId);
                    }
                }
                productionStatus.pointer += 20; // pass to other product status
            }
        }

    }
}