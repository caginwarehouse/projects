﻿using System;
using System.Collections.Generic;

namespace agv_delivery_tracker.Db;

public partial class Delivery
{
    public int DeliveryId { get; set; }

    public int MachineId { get; set; }

    public int DeliveredStationId { get; set; }

    public DateTime DeliveryTime { get; set; }
}
